import assert from 'node:assert/strict';
import test from 'node:test';
import { createBrochureDocument, joinBrochureSpread, readBrochureDocument, brochurePageObjects } from './brochureDocument.ts';
import { encodeDesignerSnapshot, decodeDesignerSnapshot } from './saveDesign.ts';
import { newWorkspaceDesign, saveWorkspaceRevision, approveWorkspaceDesign } from './designWorkspaceModel.ts';

function documentFor(name: string) {
  const document = createBrochureDocument(8, 210, 297, 3);
  for (const page of document.pages) {
    page.objects = [{ type: 'i-text', text: `${name} page ${page.number}`, left: 150, top: 200 }];
    page.thumbnail = `${name}-thumbnail-${page.number}`;
  }
  return document;
}
const snapshotFor = (document: ReturnType<typeof documentFor>) => encodeDesignerSnapshot({ brochureDocument: document, profileId: 'fogra39' });
const save = (document: ReturnType<typeof documentFor>) => ({ snapshot: snapshotFor(document), preview: document.pages[0].thumbnail!, pdf: new Blob(['local test pdf']), errors: [], warnings: [] });

test('workspace save and reopen retain every reader page, thumbnail, linked spread and profile', () => {
  const document = joinBrochureSpread(documentFor('A'), 2, 3, 2);
  const saved = saveWorkspaceRevision(newWorkspaceDesign(25), 0, save(document));
  const decoded = decodeDesignerSnapshot(structuredClone(saved.snapshot!));
  const reopened = readBrochureDocument(decoded)!;
  assert.deepEqual(reopened, document);
  assert.equal((decoded as { profileId: string }).profileId, 'fogra39');
  assert.equal(reopened.pages.length, 8);
  assert.deepEqual(reopened.pages.map(page => page.number), [1, 2, 3, 4, 5, 6, 7, 8]);
  for (let page = 1; page <= 8; page++) {
    assert.ok(brochurePageObjects(reopened, page, 2).some(object => object.text === `A page ${page}`));
  }
});

test('editing one spread preserves its facing page, remaining pages and the other approved brochure', () => {
  const a = joinBrochureSpread(documentFor('A'), 2, 3, 2), b = documentFor('B');
  const first = approveWorkspaceDesign(saveWorkspaceRevision(newWorkspaceDesign(25), 0, save(a)), 1);
  const second = approveWorkspaceDesign(saveWorkspaceRevision(newWorkspaceDesign(25), 0, save(b)), 1);
  const beforeSecond = structuredClone(second);
  const reopened = readBrochureDocument(decodeDesignerSnapshot(first.snapshot!))!;
  reopened.spreads[0].objects[0].text = 'A page 2 edited';
  const next = saveWorkspaceRevision(first, first.revision, save(reopened));
  assert.equal(next.revision, 2); assert.equal(next.approvedRevision, null);
  assert.deepEqual(second, beforeSecond);
  assert.equal(second.approvedRevision, 1);
  assert.equal(reopened.spreads[0].objects[1].text, 'A page 3');
  for (const page of [1, 4, 5, 6, 7, 8]) assert.deepEqual(reopened.pages[page - 1], a.pages[page - 1]);
  const unchanged = saveWorkspaceRevision(next, 2, save(reopened));
  assert.equal(unchanged.revision, 2);
});

test('original multipage PDF bytes survive encoded workspace storage and spread reopening', () => {
  const document = documentFor('PDF');
  const bytes = new Uint8Array([37, 80, 68, 70, 0, 128, 255]).buffer;
  document.pdfAssets = { source: { bytes, pageCount: 8, fileName: 'original.pdf' } };
  for (const page of document.pages) page.objects.push({ type: 'image', left: 100, top: 100,
    data: { kind: 'pdf_page_background', brochureBackgroundPage: page.number, brochurePdfAssetId: 'source', pageIndex: page.number - 1, totalPages: 8 } });
  const joined = joinBrochureSpread(document, 2, 3, 2);
  const saved = saveWorkspaceRevision(newWorkspaceDesign(), 0, save(joined));
  const reopened = readBrochureDocument(decodeDesignerSnapshot(structuredClone(saved.snapshot!)))!;
  assert.deepEqual(reopened.pdfAssets?.source.bytes, bytes);
  for (let page = 1; page <= 8; page++) {
    const source = brochurePageObjects(reopened, page, 2).find(object => (object.data as { brochureBackgroundPage?: number })?.brochureBackgroundPage === page)!;
    assert.ok(source);
    assert.deepEqual((source.data as { originalPdfBytes: ArrayBuffer }).originalPdfBytes, bytes);
  }
});
