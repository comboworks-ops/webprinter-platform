import test from 'node:test';
import assert from 'node:assert/strict';
import { newWorkspaceDesign, saveWorkspaceRevision, type DesignWorkspace } from './designWorkspaceModel.ts';
import { withWorkspaceApprovals, workspaceApproval, type WorkspaceApproval } from './workspaceApprovalModel.ts';
import { approveWorkspaceRecord, changeWorkspaceRecord } from './localWorkspaceTransaction.ts';

const workspace = (): DesignWorkspace => ({ version: 1, id: 'local-two-brochures', selectionKey: 'unchanged',
  checkout: { quantity: 100, productPrice: 944 }, designerParams: '', returnPath: '/', updatedAt: '2026-10-22T00:00:00.000Z',
  designs: [60, 40].map(quantity => ({ ...newWorkspaceDesign(quantity), revision: 1, approvedRevision: null,
    snapshot: { pages: 8 }, pdf: new Blob(['%PDF-fixture']), errors: [], warnings: [] })) });

function fixture(initial = workspace(), commitFails = false) {
  let base = initial;
  let approvals: WorkspaceApproval[] = [];
  const writes: { store: string; value: unknown }[] = [];
  const scopes: unknown[] = [];
  const request = <T>(result: T) => {
    const value: { result: T; onsuccess?: () => void } = { result };
    queueMicrotask(() => value.onsuccess?.()); return value;
  };
  const db = { transaction(scope) {
    scopes.push(scope);
    let pending: { store: string; value: unknown };
    const tx = { error: null, onabort: undefined as (() => void) | undefined, oncomplete: undefined as (() => void) | undefined,
      abort() { queueMicrotask(() => tx.onabort?.()); }, objectStore(name) { return {
      get: () => request(base), index: () => ({ getAll: () => request(approvals) }),
      put(value) {
        writes.push({ store: name, value }); pending = { store: name, value };
        const write: { onsuccess?: () => void } = {};
        queueMicrotask(() => {
          write.onsuccess?.();
          if (commitFails) { tx.error = new DOMException('', 'QuotaExceededError'); tx.onabort?.(); }
          else {
            if (pending.store === 'workspaces') base = pending.value as DesignWorkspace;
            else { const a = pending.value as WorkspaceApproval; approvals = [...approvals.filter(v => v.designId !== a.designId), a]; }
            tx.oncomplete?.();
          }
        }); return write;
      },
    }; } }; return tx;
  } } as unknown as IDBDatabase;
  return { db, writes, scopes, base: () => base, approvals: () => approvals,
    view: () => withWorkspaceApprovals(base, approvals) };
}

test('both approvals write only tiny revision receipts; artwork and selected price are untouched', async () => {
  const f = fixture(), original = f.base();
  for (const design of original.designs) await approveWorkspaceRecord(f.db, original.id, design.id, design.revision);
  assert.equal(f.base(), original);
  assert.equal(f.writes.length, 2);
  for (const write of f.writes) {
    assert.equal(write.store, 'approvals');
    assert.deepEqual(Object.keys(write.value).sort(), ['approvedAt', 'designId', 'revision', 'version', 'workspaceId']);
    assert.ok(JSON.stringify(write.value).length < 300);
  }
  assert.deepEqual(f.scopes, [['workspaces', 'approvals'], ['workspaces', 'approvals']]);
  assert.deepEqual(f.view().designs.map(d => d.approvedRevision), [1, 1]);
  assert.equal(f.view().checkout.productPrice, 944);
  assert.deepEqual(f.view().designs.map(d => d.quantity), [60, 40]);
});
test('editing one brochure invalidates only its receipt; reapproval leaves the other intact', async () => {
  const f = fixture(), w = f.base();
  for (const d of w.designs) await approveWorkspaceRecord(f.db, w.id, d.id, 1);
  await changeWorkspaceRecord(f.db, w.id, current => ({ ...current, designs: current.designs.map((d, i) => i === 0
    ? saveWorkspaceRevision(d, 1, { ...d, snapshot: { pages: 8, edit: 'page 2' } }) : d) }));
  assert.deepEqual(f.view().designs.map(d => d.approvedRevision), [null, 1]);
  const secondReceipt = f.approvals()[1];
  await assert.rejects(approveWorkspaceRecord(f.db, w.id, w.designs[0].id, 1), /Designet er ændret/);
  await approveWorkspaceRecord(f.db, w.id, w.designs[0].id, 2);
  assert.deepEqual(f.view().designs.map(d => d.approvedRevision), [2, 1]);
  assert.equal(f.approvals().find(a => a.designId === w.designs[1].id), secondReceipt);
});
test('commit failure cannot approve the view or alter the committed receipt', async () => {
  const f = fixture(workspace(), true), w = f.base();
  await assert.rejects(approveWorkspaceRecord(f.db, w.id, w.designs[0].id, 1), /commit\/QuotaExceededError/);
  assert.equal(f.approvals().length, 0);
  assert.equal(f.view().designs[0].approvedRevision, null);
});
test('legacy inline approvals stay readable; stale or other-workspace receipts cannot approve a revision', () => {
  const w = workspace(); w.designs[0].approvedRevision = 1;
  assert.equal(withWorkspaceApprovals(w, []).designs[0].approvedRevision, 1);
  const a = workspaceApproval(w, w.designs[0].id, 1);
  assert.equal(withWorkspaceApprovals(w, [{ ...a, workspaceId: 'other' }]).designs[1].approvedRevision, null);
  assert.equal(withWorkspaceApprovals(w, [{ ...a, revision: 0 }]).designs[0].approvedRevision, null);
  assert.equal(withWorkspaceApprovals(w, [{ ...a, revision: NaN }]).designs[0].approvedRevision, null);
});
test('missing, stale and invalid artwork reject before any approval write', async () => {
  const f = fixture(), w = f.base();
  await assert.rejects(approveWorkspaceRecord(f.db, w.id, 'missing', 1), /findes ikke/);
  await assert.rejects(approveWorkspaceRecord(f.db, w.id, w.designs[0].id, 0), /ændret/);
  for (const bad of [{ pdf: null }, { snapshot: null }, { errors: ['Bad print file'] }]) {
    const value = workspace(); Object.assign(value.designs[0], bad);
    const invalid = fixture(value);
    await assert.rejects(approveWorkspaceRecord(invalid.db, value.id, value.designs[0].id, 1), /gyldig tryk-PDF/);
    assert.equal(invalid.writes.length, 0);
  }
  assert.equal(f.writes.length, 0);
});
