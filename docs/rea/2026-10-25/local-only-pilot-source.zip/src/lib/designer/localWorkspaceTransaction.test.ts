import test from 'node:test';
import assert from 'node:assert/strict';
import { changeWorkspaceRecord, LocalWorkspaceSaveError } from './localWorkspaceTransaction.ts';
import { newWorkspaceDesign, approveWorkspaceDesign, type DesignWorkspace } from './designWorkspaceModel.ts';

const workspace = (): DesignWorkspace => ({ version: 1, id: 'fixture', selectionKey: 'fixture',
  checkout: { quantity: 100, productPrice: 944 }, designerParams: '', returnPath: '/', updatedAt: '',
  designs: [60, 40].map(quantity => ({ ...newWorkspaceDesign(quantity), revision: 2, approvedRevision: null,
    snapshot: { pages: 8 }, pdf: new Blob(['%PDF-fixture']), errors: [], warnings: [] })) });

// Event-driven transaction fixture: requests may succeed before the commit fails.
function database(initial = workspace(), fault?: 'commit' | 'read' | 'write' | 'clone') {
  let saved = initial;
  let tx;
  let pending;
  const nativeError = new DOMException('Private browser message must not enter diagnostics', fault === 'clone' ? 'DataCloneError' : 'QuotaExceededError');
  const db = { transaction: () => {
    tx = { error: null, abort() { queueMicrotask(() => tx.onabort?.()); }, objectStore: (name: string) => name === 'approvals' ? {
      index: () => ({ getAll: () => {
        const request: { result: unknown[]; onsuccess?: () => void } = { result: [] };
        queueMicrotask(() => request.onsuccess?.()); return request;
      } }),
    } : ({
      get: () => {
        const request: { result: DesignWorkspace; error: DOMException | null; onerror?: () => void; onsuccess?: () => void } = { result: saved, error: fault === 'read' ? nativeError : null };
        queueMicrotask(() => {
          if (fault === 'read') { request.onerror?.(); tx.error = nativeError; tx.onerror?.({ target: request }); tx.onabort?.(); }
          else request.onsuccess?.();
        });
        return request;
      },
      put: value => {
        if (fault === 'clone') throw nativeError;
        pending = value;
        const request: { error: DOMException | null; onerror?: () => void; onsuccess?: () => void } = { error: fault === 'write' ? nativeError : null };
        queueMicrotask(() => {
          if (fault === 'write') { request.onerror?.(); tx.error = nativeError; tx.onerror?.({ target: request }); tx.onabort?.(); }
          else {
            request.onsuccess?.();
            if (fault === 'commit') { tx.error = nativeError; tx.onabort?.(); }
            else { saved = pending; tx.oncomplete?.(); }
          }
        });
        return request;
      },
    }) };
    return tx;
  } } as unknown as IDBDatabase;
  return { db, saved: () => saved };
}
const approve = (w: DesignWorkspace) => ({ ...w, designs: w.designs.map((d, i) => i === 0 ? approveWorkspaceDesign(d, d.revision) : d) });

test('approval resolves after commit, preserving other design and matrix price', async () => {
  const fixture = database(), before = fixture.saved();
  const result = await changeWorkspaceRecord(fixture.db, 'fixture', approve);
  assert.equal(result, fixture.saved());
  assert.equal(result.designs[0].approvedRevision, 2);
  assert.equal(result.designs[1], before.designs[1]);
  assert.deepEqual(result.checkout, before.checkout);
});
for (const [fault, stage, code] of [['commit', 'commit', 'QuotaExceededError'], ['read', 'read', 'QuotaExceededError'],
  ['write', 'write', 'QuotaExceededError'], ['clone', 'write', 'DataCloneError']] as const) {
  test(`${fault} failure preserves committed record and reports the actual stage/code`, async () => {
    const fixture = database(workspace(), fault), before = fixture.saved();
    await assert.rejects(changeWorkspaceRecord(fixture.db, 'fixture', approve), error => {
      assert.ok(error instanceof LocalWorkspaceSaveError);
      assert.deepEqual(error.diagnostic, { stage, code });
      assert.match(error.message, new RegExp(`${stage}/${code}`));
      assert.doesNotMatch(error.message, /Private browser message/);
      return true;
    });
    assert.equal(fixture.saved(), before);
    assert.equal(fixture.saved().designs[0].approvedRevision, null);
  });
}
test('stale approval keeps its validation message and cannot commit', async () => {
  const fixture = database(), before = fixture.saved();
  await assert.rejects(changeWorkspaceRecord(fixture.db, 'fixture', w => ({ ...w,
    designs: w.designs.map(d => approveWorkspaceDesign(d, d.revision - 1)) })), /Designet er ændret/);
  assert.equal(fixture.saved(), before);
});
