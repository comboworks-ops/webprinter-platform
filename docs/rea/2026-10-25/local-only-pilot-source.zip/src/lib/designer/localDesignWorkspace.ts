import { newWorkspaceDesign, workspaceCheckout, workspaceSelectionKey, type DesignWorkspace } from './designWorkspaceModel.ts';
import type { SiteCheckoutState } from '../checkout/siteCheckoutSession.ts';
import { approveWorkspaceRecord, changeWorkspaceRecord, LocalWorkspaceSaveError, readWorkspaceRecord } from './localWorkspaceTransaction.ts';
import { WORKSPACE_APPROVAL_STORE, withWorkspaceApprovals, type WorkspaceApproval } from './workspaceApprovalModel.ts';

export function localDesignWorkspaceEnabled() {
  return import.meta.env.DEV && ['localhost', '127.0.0.1', '[::1]'].includes(window.location.hostname);
}
const STORE = 'workspaces';
function database(): Promise<IDBDatabase> {
  if (!localDesignWorkspaceEnabled()) return Promise.reject(new Error('Designarbejdspladsen er kun til lokal afprøvning.'));
  return new Promise((resolve, reject) => {
    let blocked = false;
    const request = indexedDB.open('webprinter-design-workspaces-v1', 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) db.createObjectStore(STORE, { keyPath: 'id' });
      if (!db.objectStoreNames.contains(WORKSPACE_APPROVAL_STORE)) {
        const approvals = db.createObjectStore(WORKSPACE_APPROVAL_STORE, { keyPath: ['workspaceId', 'designId'] });
        approvals.createIndex('workspaceId', 'workspaceId');
      }
    };
    request.onsuccess = () => {
      if (blocked) { request.result.close(); return; }
      request.result.onversionchange = () => request.result.close();
      resolve(request.result);
    };
    request.onblocked = () => { blocked = true; reject(new Error('En anden fane holder den lokale arbejdsplads åben. Behold dine designs og luk kun faner uden ugemte ændringer, før du prøver igen.')); };
    request.onerror = () => reject(new Error('Den lokale designarbejdsplads kunne ikke åbnes. Behold fanen åben.'));
  });
}
export async function listDesignWorkspaces(): Promise<DesignWorkspace[]> {
  const db = await database();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction([STORE, WORKSPACE_APPROVAL_STORE]);
      const request = tx.objectStore(STORE).getAll(), approvals = tx.objectStore(WORKSPACE_APPROVAL_STORE).getAll();
      tx.oncomplete = () => resolve(request.result.map((w: DesignWorkspace) => withWorkspaceApprovals(w, approvals.result as WorkspaceApproval[]))
        .sort((a: DesignWorkspace, b: DesignWorkspace) => b.updatedAt.localeCompare(a.updatedAt)));
      tx.onabort = () => reject(new LocalWorkspaceSaveError('read', tx.error));
    });
  } finally { db.close(); }
}
export async function readDesignWorkspace(id: string): Promise<DesignWorkspace> {
  const db = await database();
  try {
    return await new Promise((resolve, reject) => {
      const tx = db.transaction([STORE, WORKSPACE_APPROVAL_STORE]);
      let workspace: DesignWorkspace, failure: unknown;
      readWorkspaceRecord(tx, id, value => { workspace = value; }, error => { failure = error; });
      tx.oncomplete = () => failure ? reject(failure) : resolve(workspace);
      tx.onabort = () => reject(failure || new LocalWorkspaceSaveError('read', tx.error));
    });
  } finally { db.close(); }
}
export async function approveDesignWorkspace(id: string, designId: string, revision: number): Promise<DesignWorkspace> {
  const db = await database();
  try { return await approveWorkspaceRecord(db, id, designId, revision); }
  catch (error) {
    if (error instanceof LocalWorkspaceSaveError) console.warn('Local design approval failed', error.diagnostic);
    throw error;
  } finally { db.close(); }
}
/** Atomic read/modify/write keeps independent tabs and designs from overwriting one another. */
export async function changeDesignWorkspace(id: string, change: (workspace: DesignWorkspace) => DesignWorkspace): Promise<DesignWorkspace> {
  const db = await database();
  try {
    return await changeWorkspaceRecord(db, id, change);
  } catch (error) {
    if (error instanceof LocalWorkspaceSaveError) console.warn('Local design save failed', error.diagnostic);
    throw error;
  } finally { db.close(); }
}
export async function openDesignWorkspace(checkout: SiteCheckoutState, designerParams: string): Promise<DesignWorkspace> {
  if (!checkout.productId || !checkout.quantity || !checkout.checkoutTenantId) throw new Error('Vælg produkt, butik og antal i prismatricen først.');
  if (checkout.companyWorkingDesignId || checkout.apparelConfig) throw new Error('Denne lokale prøve understøtter endnu ikke virksomhedsskabeloner eller tekstiler. Brug den eksisterende designer.');
  const selectionKey = workspaceSelectionKey(checkout, designerParams);
  const id = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(selectionKey))))
    .map(byte => byte.toString(16).padStart(2, '0')).join('');
  const db = await database();
  try {
    return await new Promise((resolve, reject) => {
      const transaction = db.transaction(STORE, 'readwrite'), store = transaction.objectStore(STORE), request = store.get(id);
      let workspace: DesignWorkspace;
      request.onsuccess = () => {
        const existing = request.result as DesignWorkspace | undefined;
        workspace = { version: 1, id, selectionKey, checkout: workspaceCheckout(checkout), designerParams,
          returnPath: checkout.productReturnPath || `/produkt/${encodeURIComponent(checkout.productSlug || '')}`,
          designs: existing?.designs || [{ ...newWorkspaceDesign(checkout.quantity!), name: 'Design 1' }], updatedAt: new Date().toISOString() };
        store.put(workspace);
      };
      transaction.oncomplete = () => resolve(workspace);
      transaction.onerror = transaction.onabort = () => reject(new Error('Den lokale arbejdsplads kunne ikke gemmes.'));
    });
  } finally { db.close(); }
}
export function workspacePath(id: string, params?: string) {
  const context = new URLSearchParams(params);
  const query = new URLSearchParams({ workspace: id });
  for (const key of ['tenantId', 'force_domain']) if (context.get(key)) query.set(key, context.get(key)!);
  return `/design-workspace?${query}`;
}
export function workspaceDesignerPath(workspace: DesignWorkspace, designId: string) {
  const params = new URLSearchParams(workspace.designerParams);
  params.delete('designId');
  params.set('localWorkspace', workspace.id);
  params.set('localDesign', designId);
  params.set('returnTo', workspacePath(workspace.id, workspace.designerParams));
  params.set('backTo', workspacePath(workspace.id, workspace.designerParams));
  return `/designer?${params}`;
}
