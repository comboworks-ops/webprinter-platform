import { approveWorkspaceDesign, type DesignWorkspace } from './designWorkspaceModel.ts';

export const WORKSPACE_APPROVAL_STORE = 'approvals';
export interface WorkspaceApproval {
  version: 1;
  workspaceId: string;
  designId: string;
  revision: number;
  approvedAt: string;
}
export function workspaceApproval(workspace: DesignWorkspace, designId: string, revision: number): WorkspaceApproval {
  const design = workspace.designs.find(d => d.id === designId);
  if (!design) throw new Error('Designet findes ikke længere. Åbn arbejdspladsen igen.');
  approveWorkspaceDesign(design, revision);
  return { version: 1, workspaceId: workspace.id, designId, revision, approvedAt: new Date().toISOString() };
}
/** Existing inline approvals remain readable; a separate stale receipt can never approve a new revision. */
export function withWorkspaceApprovals(workspace: DesignWorkspace, approvals: WorkspaceApproval[]): DesignWorkspace {
  const relevant = approvals.filter(a => a.version === 1 && a.workspaceId === workspace.id);
  return { ...workspace, designs: workspace.designs.map(design => {
    const approval = relevant.find(a => a.designId === design.id);
    if (!approval) return design;
    return { ...design, approvedRevision: Number.isSafeInteger(approval.revision) && approval.revision === design.revision ? design.revision : null };
  }), updatedAt: relevant.reduce((latest, a) => a.approvedAt > latest ? a.approvedAt : latest, workspace.updatedAt) };
}
