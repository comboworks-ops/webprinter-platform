import type { DesignWorkspace } from './designWorkspaceModel.ts';
/** A local artwork must never reopen against another product/template via a changed URL. */
export function assertWorkspaceContext(workspace: DesignWorkspace, actual: URLSearchParams) {
  const expected = new URLSearchParams(workspace.designerParams);
  for (const key of ['productId', 'tenantId', 'force_domain', 'templateId', 'templatePdfUrl', 'templatePdfSha256',
    'widthMm', 'heightMm', 'bleedMm', 'safeMm', 'format', 'variant', 'brochurePages', 'designerMode', 'requiresCutContour']) {
    if (expected.get(key) !== actual.get(key)) throw new Error('Designets produkt eller skabelon matcher ikke. Åbn designet fra arbejdspladsen igen.');
  }
  if (actual.has('designId') || actual.has('companyControlled') || actual.has('apparel')) throw new Error('Dette er ikke en lokal designreference.');
}
