import assert from 'node:assert/strict';
import test from 'node:test';
import { workspaceDeliveryPreview } from './workspaceDeliveryPreview.ts';
import { normalizeCheckoutDeliveryMethods } from '../delivery/checkoutDelivery.ts';
import { LOCAL_BROCHURE_TENANT_ID } from './workspaceCheckoutModel.ts';

const tenant = LOCAL_BROCHURE_TENANT_ID;
const selection = { productPrice: 944, extraPrice: 0, totalPrice: 993, checkoutTenantId: tenant };

test('standard and express add existing delivery and VAT exactly once, preserving the matrix selection', () => {
  const original = structuredClone(selection);
  const standard = workspaceDeliveryPreview(selection, null, 'standard', 'DK', tenant);
  assert.equal(standard.shippingCost, 49);
  assert.equal(standard.tax?.netAmountOre, 99300);
  assert.equal(standard.tax?.vatAmountOre, 24825);
  assert.equal(standard.tax?.grossAmountOre, 124125);
  const express = workspaceDeliveryPreview(selection, null, 'express', 'Danmark', tenant);
  assert.equal(express.shippingCost, 199);
  assert.equal(express.tax?.vatAmountOre, 28575);
  assert.equal(express.tax?.grossAmountOre, 142875);
  assert.deepEqual(selection, original);
});
test('configured delivery prices and product extras reuse the existing cost resolver and øre rounding', () => {
  const methods = [{ id: 'courier', name: 'Kurér', price: 79.6, description: 'Lokal kurér' }];
  const preview = workspaceDeliveryPreview({ ...selection, extraPrice: 20.02 }, methods, 'courier', 'dk', tenant);
  assert.equal(preview.shippingCost, 80);
  assert.equal(preview.tax?.netAmountOre, 104402);
  assert.equal(preview.tax?.vatAmountOre, 26101);
  assert.equal(preview.tax?.grossAmountOre, 130503);
  assert.equal(methods[0].price, 79.6);
});
test('unconfirmed or mismatched shop and foreign or malformed destination never produce an approved VAT total', () => {
  for (const country of ['DE', 'SE', 'NO', 'FO', 'GL', '', 'unknown']) {
    const preview = workspaceDeliveryPreview(selection, null, 'standard', country, tenant);
    assert.equal(preview.tax, null); assert.ok(preview.message);
  }
  for (const shop of [undefined, 'other-shop']) {
    const preview = workspaceDeliveryPreview(selection, null, 'standard', 'DK', shop);
    assert.equal(preview.tax, null); assert.ok(preview.message);
  }
});
test('stale delivery id falls back to the current product first method, as in normal checkout', () => {
  const result = workspaceDeliveryPreview(selection, [{ id: 'replacement', name: 'Ny levering', price: 65 }], 'removed', 'DK', tenant);
  assert.equal(result.method?.id, 'replacement'); assert.equal(result.shippingCost, 65);
  assert.equal(result.tax?.grossAmountOre, 126125);
});
test('extracted checkout normalization retains defaults and per-method fallback behavior', () => {
  const defaults = normalizeCheckoutDeliveryMethods([]);
  assert.deepEqual(defaults.map(m => [m.id, m.price]), [['standard', 49], ['express', 199]]);
  const custom = normalizeCheckoutDeliveryMethods([{ id: 'express', name: 'Hurtig', price: 'invalid', cutoff_label: 'latest', delivery_date: '2026-11-02' }, {}]);
  assert.equal(custom[0].price, 199); assert.equal(custom[0].production_days, 1);
  assert.equal(custom[0].cutoff_label, 'latest'); assert.equal(custom[0].delivery_date, '2026-11-02');
  assert.equal(custom[1].id, 'express');
  defaults[0].price = 0; assert.equal(normalizeCheckoutDeliveryMethods(null)[0].price, 49);
});
