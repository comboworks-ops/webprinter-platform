import { normalizeCheckoutDeliveryMethods } from '../delivery/checkoutDelivery.ts';
import { resolveDeliveryMethodCost } from '../delivery/defaults.ts';
import { checkoutTaxPreview } from '../checkout/tax.ts';
import { checkoutCountryCode } from '../checkout/addressIntegrity.ts';
import type { SiteCheckoutState } from '../checkout/siteCheckoutSession.ts';

/** Composes existing delivery and tax helpers; never replaces the selected matrix price. */
export function workspaceDeliveryPreview(checkout: SiteCheckoutState, rawMethods: unknown,
  methodId: string, country: string, resolvedTenantId: string | undefined) {
  const methods = normalizeCheckoutDeliveryMethods(rawMethods);
  const method = methods.find(item => item.id === methodId) || methods[0] || null;
  const orderPrice = Number(checkout.productPrice) + Number(checkout.extraPrice ?? 0);
  const shippingCost = resolveDeliveryMethodCost(orderPrice, method);
  const netTotal = Math.max(0, orderPrice + shippingCost);
  const tenantId = resolvedTenantId === checkout.checkoutTenantId ? resolvedTenantId : undefined;
  const preview = checkoutTaxPreview(tenantId, checkoutCountryCode(country), Math.round(netTotal * 100));
  return { methods, method, orderPrice, shippingCost, netTotal, ...preview };
}
