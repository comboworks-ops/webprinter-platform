import test from 'node:test';
import assert from 'node:assert/strict';
import { newWorkspaceDesign, workspaceCheckout, type DesignWorkspace } from './designWorkspaceModel.ts';
import { assertWorkspaceCheckoutReady, assertWorkspaceCheckoutCurrent, assertWorkspaceCheckoutFileHashes,
  workspaceCheckoutFingerprint, LOCAL_BROCHURE_PRODUCT_ID, LOCAL_BROCHURE_TENANT_ID, type WorkspaceCheckoutBundle } from './workspaceCheckoutModel.ts';

const hash = async (blob: Blob) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await blob.arrayBuffer())))
  .map(n => n.toString(16).padStart(2, '0')).join('');
function workspace(): DesignWorkspace {
  const checkout = { productId: LOCAL_BROCHURE_PRODUCT_ID, checkoutTenantId: LOCAL_BROCHURE_TENANT_ID,
    designerMode: 'brochure', brochurePageCount: 8, designWidthMm: 148, designHeightMm: 210, designBleedMm: 3,
    templatePdfUrl: '/brochure/templates/148x210.pdf', templatePdfSha256: 'a'.repeat(64),
    quantity: 100, productPrice: 657, extraPrice: 0,
    pricingQuote: { productId: LOCAL_BROCHURE_PRODUCT_ID, quantity: 100, variantKey: 'exact-paper' } };
  const params = new URLSearchParams({ productId: checkout.productId, tenantId: checkout.checkoutTenantId, brochurePages: '8',
    widthMm: '148', heightMm: '210', templatePdfUrl: checkout.templatePdfUrl, templatePdfSha256: checkout.templatePdfSha256 });
  return { version: 1, id: 'workspace-one', selectionKey: 'stable-selection', checkout, designerParams: params.toString(),
    returnPath: '/brochure-shop-preview', updatedAt: '', designs: [60, 40].map((quantity, index) => ({ ...newWorkspaceDesign(quantity),
      name: `Edition ${index + 1}`, revision: 1, approvedRevision: 1, snapshot: { pages: 8 },
      pdf: new Blob([`%PDF-edition-${index}`], { type: 'application/pdf' }) })) };
}
async function bundle(w: DesignWorkspace): Promise<WorkspaceCheckoutBundle> {
  return { version: 1, localOnly: true, id: crypto.randomUUID(), workspaceId: w.id, selectionKey: w.selectionKey,
    selectionFingerprint: workspaceCheckoutFingerprint(w), checkout: workspaceCheckout(w.checkout), returnPath: w.returnPath,
    createdAt: '', files: await Promise.all(w.designs.map(async d => ({ designId: d.id, name: d.name, quantity: d.quantity,
      revision: d.revision, pdf: d.pdf!, sha256: await hash(d.pdf!), preview: null, warnings: [...d.warnings] }))) };
}
test('two approved brochure editions carry exact allocation and the unchanged matrix selection', async () => {
  const w = workspace(), b = await bundle(w);
  assert.doesNotThrow(() => assertWorkspaceCheckoutReady(w));
  await assertWorkspaceCheckoutFileHashes(b, w, hash);
  assert.equal(b.checkout.productPrice, 657); assert.deepEqual(b.files.map(f => f.quantity), [60, 40]);
  assert.equal(b.localOnly, true);
});
test('missing approval, PDF, artwork, blocking errors and quantity mismatch cannot enter checkout', () => {
  const changes = [
    (w: DesignWorkspace) => { w.designs[0].approvedRevision = null; },
    (w: DesignWorkspace) => { w.designs[0].pdf = null; },
    (w: DesignWorkspace) => { w.designs[0].snapshot = null; },
    (w: DesignWorkspace) => { w.designs[0].errors = ['wrong format']; },
    (w: DesignWorkspace) => { w.designs[0].quantity = 61; },
    (w: DesignWorkspace) => { w.designs[0].quantity = -1; },
    (w: DesignWorkspace) => { w.designs[0].quantity = 60.5; },
    (w: DesignWorkspace) => { w.designs[1].id = w.designs[0].id; },
  ];
  for (const change of changes) { const w = workspace(); change(w); assert.throws(() => assertWorkspaceCheckoutReady(w)); }
});
test('wrong product, tenant, template, dimensions, page count and quote context are rejected', () => {
  for (const [key, value] of [['productId', 'other-product'], ['checkoutTenantId', 'other-shop'], ['templatePdfSha256', 'b'.repeat(64)],
    ['designWidthMm', 210], ['brochurePageCount', 12], ['productPrice', NaN]] as const) {
    const w = workspace(); Object.assign(w.checkout, { [key]: value }); assert.throws(() => assertWorkspaceCheckoutReady(w));
  }
  const w = workspace(); w.checkout.pricingQuote!.quantity = 101; assert.throws(() => assertWorkspaceCheckoutReady(w));
});
test('more than eight files cannot overflow the checkout file contract', () => {
  const w = workspace(); w.designs = Array.from({ length: 9 }, () => ({ ...w.designs[0], id: crypto.randomUUID(), quantity: 1 }));
  w.checkout.quantity = 9; w.checkout.pricingQuote!.quantity = 9;
  assert.throws(() => assertWorkspaceCheckoutReady(w), /8 designs/);
});
test('a stale handoff rejects subsequent design edits, allocations, matrix changes and replaced file identities', async () => {
  const changes = [
    (w: DesignWorkspace) => { w.designs[0].revision++; w.designs[0].approvedRevision = w.designs[0].revision; },
    (w: DesignWorkspace) => { w.designs[0].quantity--; w.designs[1].quantity++; },
    (w: DesignWorkspace) => { w.designs[0].name = 'Renamed'; },
    (w: DesignWorkspace) => { w.checkout.productPrice++; },
    (w: DesignWorkspace) => { w.checkout.pricingQuote!.variantKey = 'another-paper'; },
  ];
  for (const change of changes) { const w = workspace(), b = await bundle(w); change(w); assert.throws(() => assertWorkspaceCheckoutCurrent(b, w)); }
  const w = workspace(), b = await bundle(w); b.files[1] = b.files[0]; assert.throws(() => assertWorkspaceCheckoutCurrent(b, w));
});
test('file byte tampering is rejected even if the visible revision was not changed', async () => {
  const w = workspace(), b = await bundle(w); w.designs[0].pdf = new Blob(['changed bytes'], { type: 'application/pdf' });
  await assert.rejects(assertWorkspaceCheckoutFileHashes(b, w, hash), /trykfil er ændret/);
  const w2 = workspace(), b2 = await bundle(w2); b2.files[0].pdf = new Blob(['replaced bundle bytes'], { type: 'application/pdf' });
  await assert.rejects(assertWorkspaceCheckoutFileHashes(b2, w2, hash), /trykfil er ændret/);
});
test('warnings remain reviewable and customer details are not copied to the handoff', async () => {
  const w = workspace(); w.designs[0].warnings = ['Missing output intent']; w.checkout.checkoutCustomer = { customerEmail: 'private@example.test' };
  const b = await bundle(w); assert.deepEqual(b.files[0].warnings, ['Missing output intent']);
  assert.equal(b.checkout.checkoutCustomer, undefined); assert.equal(b.checkout.designerExport, undefined);
  await assertWorkspaceCheckoutFileHashes(b, w, hash);
});
