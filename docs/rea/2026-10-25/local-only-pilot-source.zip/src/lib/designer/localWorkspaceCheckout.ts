import { PDFDocument } from 'pdf-lib';
import { hashCheckoutArtifact } from '../checkout/checkoutArtifact';
import { workspaceCheckout } from './designWorkspaceModel';
import { localDesignWorkspaceEnabled, readDesignWorkspace } from './localDesignWorkspace';
import { assertWorkspaceCheckoutCurrent, assertWorkspaceCheckoutFileHashes, assertWorkspaceCheckoutReady, workspaceCheckoutFingerprint,
  type WorkspaceCheckoutBundle } from './workspaceCheckoutModel';

const DB_NAME = 'webprinter-local-workspace-checkout-v1';
function database(): Promise<IDBDatabase> {
  if (!localDesignWorkspaceEnabled()) return Promise.reject(new Error('Denne checkout er kun til lokal afprøvning.'));
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => request.result.createObjectStore('bundles', { keyPath: 'id' });
    request.onsuccess = () => resolve(request.result);
    request.onerror = request.onblocked = () => reject(new Error('Den lokale checkout kunne ikke åbnes. Dine designs er bevaret.'));
  });
}
async function inspectPdf(pdf: Blob, pageCount: number, width: number, height: number, bleed: number) {
  if (pdf.type !== 'application/pdf' || !pdf.size || pdf.size > 50 * 1024 * 1024
    || !(await pdf.slice(0, 5).text()).startsWith('%PDF-')) throw new Error('En tryk-PDF mangler eller overskrider 50 MB.');
  const document = await PDFDocument.load(await pdf.arrayBuffer());
  if (document.getPageCount() !== pageCount) throw new Error('En tryk-PDF har et andet sidetal end det valgte produkt.');
  for (const page of document.getPages()) {
    const { width: w, height: h } = page.getMediaBox();
    if (Math.abs(w * 25.4 / 72 - width - 2 * bleed) > .15 || Math.abs(h * 25.4 / 72 - height - 2 * bleed) > .15) {
      throw new Error('En tryk-PDF har et andet format end det valgte produkt.');
    }
  }
}
export async function createLocalWorkspaceCheckout(workspaceId: string): Promise<WorkspaceCheckoutBundle> {
  if (!localDesignWorkspaceEnabled()) throw new Error('Denne checkout er kun til lokal afprøvning.');
  const workspace = await readDesignWorkspace(workspaceId);
  assertWorkspaceCheckoutReady(workspace);
  if (workspace.designs.reduce((sum, d) => sum + d.pdf!.size, 0) > 200 * 1024 * 1024) throw new Error('Trykfilerne må tilsammen højst fylde 200 MB i denne lokale prøve.');
  const files: WorkspaceCheckoutBundle['files'] = [];
  for (const design of workspace.designs) {
    await inspectPdf(design.pdf!, workspace.checkout.brochurePageCount!, workspace.checkout.designWidthMm!,
      workspace.checkout.designHeightMm!, workspace.checkout.designBleedMm ?? 3);
    files.push({ designId: design.id, name: design.name, quantity: design.quantity, revision: design.revision,
      pdf: design.pdf!, sha256: await hashCheckoutArtifact(design.pdf!), preview: design.preview, warnings: [...design.warnings] });
  }
  const bundle: WorkspaceCheckoutBundle = { version: 1, localOnly: true, id: crypto.randomUUID(), workspaceId,
    selectionKey: workspace.selectionKey, selectionFingerprint: workspaceCheckoutFingerprint(workspace),
    checkout: workspaceCheckout(workspace.checkout), returnPath: workspace.returnPath, files, createdAt: new Date().toISOString() };
  assertWorkspaceCheckoutCurrent(bundle, await readDesignWorkspace(workspaceId));
  const db = await database();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction('bundles', 'readwrite'); tx.objectStore('bundles').put(bundle);
      tx.oncomplete = () => resolve(); tx.onerror = tx.onabort = () => reject(new Error('Checkout kunne ikke gemmes lokalt. Dine designs er bevaret.'));
    });
  } finally { db.close(); }
  return bundle;
}
export async function readLocalWorkspaceCheckout(id: string): Promise<WorkspaceCheckoutBundle> {
  if (!/^[a-f0-9-]{36}$/i.test(id)) throw new Error('Den lokale checkout-reference er ugyldig.');
  const db = await database();
  try {
    const bundle = await new Promise<WorkspaceCheckoutBundle>((resolve, reject) => {
      const req = db.transaction('bundles').objectStore('bundles').get(id);
      req.onsuccess = () => req.result ? resolve(req.result) : reject(new Error('Den lokale checkout findes ikke i denne browser. Åbn den fra dine designs.'));
      req.onerror = () => reject(new Error('Checkout kunne ikke læses. Dine designs er bevaret.'));
    });
    await validateLocalWorkspaceCheckout(bundle);
    return bundle;
  } finally { db.close(); }
}
export async function validateLocalWorkspaceCheckout(bundle: WorkspaceCheckoutBundle) {
  if (!localDesignWorkspaceEnabled()) throw new Error('Denne checkout er kun til lokal afprøvning.');
  const workspace = await readDesignWorkspace(bundle.workspaceId);
  await assertWorkspaceCheckoutFileHashes(bundle, workspace, hashCheckoutArtifact);
  // A simultaneous save/allocation change during hashing must invalidate the handoff too.
  assertWorkspaceCheckoutCurrent(bundle, await readDesignWorkspace(bundle.workspaceId));
}
export function localWorkspaceCheckoutPath(bundle: WorkspaceCheckoutBundle) {
  return `/checkout/konfigurer?tenantId=${encodeURIComponent(bundle.checkout.checkoutTenantId!)}&workspaceCheckout=${encodeURIComponent(bundle.id)}`;
}
