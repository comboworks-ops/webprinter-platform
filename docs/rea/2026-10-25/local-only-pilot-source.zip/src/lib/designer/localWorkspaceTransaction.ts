import type { DesignWorkspace } from './designWorkspaceModel.ts';
import { WORKSPACE_APPROVAL_STORE, withWorkspaceApprovals, workspaceApproval, type WorkspaceApproval } from './workspaceApprovalModel.ts';

type SaveStage = 'transaction' | 'read' | 'write' | 'commit';
const STORAGE_CODES = new Set(['QuotaExceededError', 'DataCloneError', 'AbortError', 'UnknownError',
  'ConstraintError', 'DataError', 'InvalidStateError', 'NotFoundError', 'NotReadableError', 'SecurityError', 'TransactionInactiveError']);

/** Only stage and allowlisted native error names may be shown/logged, never the saved content. */
export class LocalWorkspaceSaveError extends Error {
  readonly diagnostic: { stage: SaveStage; code: string };
  constructor(stage: SaveStage, failure: unknown) {
    const name = failure instanceof Error ? failure.name : '';
    const code = STORAGE_CODES.has(name) ? name : 'UnknownError';
    super(`Browseren kunne ikke gemme lokalt. Behold fanen åben og prøv igen manuelt. Fejlkode: ${stage}/${code}.`);
    this.name = 'LocalWorkspaceSaveError';
    this.diagnostic = { stage, code };
  }
}

/** Both reads share a transaction with artwork edits and approval writes. No await inside it. */
export function readWorkspaceRecord(transaction: IDBTransaction, id: string,
  ready: (workspace: DesignWorkspace) => void, failed: (error: unknown) => void) {
  let workspace: DesignWorkspace | undefined, approvals: WorkspaceApproval[] | undefined;
  let loaded = false;
  const finish = () => {
    if (!loaded || !approvals) return;
    if (workspace?.version !== 1) { failed(new Error('Den lokale arbejdsplads findes ikke i denne browser. Åbn den fra produktets prismatrix.')); return; }
    ready(withWorkspaceApprovals(workspace, approvals));
  };
  const read = transaction.objectStore('workspaces').get(id);
  const receipts = transaction.objectStore(WORKSPACE_APPROVAL_STORE).index('workspaceId').getAll(id);
  read.onsuccess = () => { workspace = read.result; loaded = true; finish(); };
  receipts.onsuccess = () => { approvals = receipts.result; finish(); };
  read.onerror = () => failed(new LocalWorkspaceSaveError('read', read.error));
  receipts.onerror = () => failed(new LocalWorkspaceSaveError('read', receipts.error));
}

/** Success means commit, not just a successful put request. No retries. */
function mutateWorkspaceRecord(db: IDBDatabase, id: string,
  change: (workspace: DesignWorkspace) => DesignWorkspace,
  write: (transaction: IDBTransaction, workspace: DesignWorkspace) => IDBRequest): Promise<DesignWorkspace> {
  return new Promise((resolve, reject) => {
    let transaction: IDBTransaction;
    try { transaction = db.transaction(['workspaces', WORKSPACE_APPROVAL_STORE], 'readwrite'); }
    catch (error) { reject(new LocalWorkspaceSaveError('transaction', error)); return; }
    let result: DesignWorkspace;
    let failure: unknown;
    transaction.oncomplete = () => resolve(result);
    transaction.onabort = () => reject(failure || new LocalWorkspaceSaveError('commit', transaction.error || new DOMException('', 'AbortError')));
    // Request errors bubble to the transaction. Keep the original request's stage/code.
    transaction.onerror = () => { failure ||= new LocalWorkspaceSaveError('commit', transaction.error); };
    let aborting = false;
    const abort = (error: unknown) => {
      failure ||= error;
      if (!aborting) { aborting = true; transaction.abort(); }
    };
    try {
      readWorkspaceRecord(transaction, id, workspace => {
        try {
          result = { ...change(workspace), updatedAt: new Date().toISOString() };
        } catch (error) { abort(error); return; }
        try {
          const request = write(transaction, result);
          request.onerror = () => { failure = new LocalWorkspaceSaveError('write', request.error); };
        } catch (error) { abort(new LocalWorkspaceSaveError('write', error)); }
      }, abort);
    } catch (error) { abort(new LocalWorkspaceSaveError('read', error)); }
  });
}

export function changeWorkspaceRecord(db: IDBDatabase, id: string,
  change: (workspace: DesignWorkspace) => DesignWorkspace): Promise<DesignWorkspace> {
  return mutateWorkspaceRecord(db, id, change, (tx, workspace) => tx.objectStore('workspaces').put(workspace));
}

/** Approval writes this small receipt only. Both stores are locked until the revision check commits. */
export function approveWorkspaceRecord(db: IDBDatabase, id: string, designId: string, revision: number): Promise<DesignWorkspace> {
  let approval: WorkspaceApproval;
  return mutateWorkspaceRecord(db, id, workspace => {
    approval = workspaceApproval(workspace, designId, revision);
    return withWorkspaceApprovals(workspace, [approval]);
  }, tx => tx.objectStore(WORKSPACE_APPROVAL_STORE).put(approval));
}
