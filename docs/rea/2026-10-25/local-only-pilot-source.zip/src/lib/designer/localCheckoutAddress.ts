import { checkoutCountryCode, missingCheckoutContactFields } from '../checkout/addressIntegrity.ts';

// eslint-disable-next-line no-control-regex -- Matches the existing server text boundary; controls are deliberately rejected.
const INVALID_CHECKOUT_TEXT = /[\u0000-\u0008\u000b\u000c\u000e-\u001f]/;

export const localContactFields = [
  { key: 'customerName', label: 'Navn', max: 250, required: true, type: 'text', wide: false },
  { key: 'customerEmail', label: 'E-mail', max: 254, required: true, type: 'email', wide: false },
  { key: 'deliveryRecipientName', label: 'Modtagerens navn', max: 250, required: true, type: 'text', wide: false },
  { key: 'deliveryCompany', label: 'Firma (valgfrit)', max: 250, required: false, type: 'text', wide: false },
  { key: 'deliveryAddress', label: 'Adresse', max: 500, required: true, type: 'text', wide: true },
  { key: 'deliveryAddress2', label: 'Adresse linje 2 (valgfrit)', max: 500, required: false, type: 'text', wide: true },
  { key: 'deliveryZip', label: 'Postnr.', max: 40, required: true, type: 'text', wide: false },
  { key: 'deliveryCity', label: 'By', max: 160, required: true, type: 'text', wide: false },
] as const;
export type LocalContactKey = typeof localContactFields[number]['key'];
export type LocalCheckoutAddress = Record<LocalContactKey, string>;
export type LocalCheckoutAddressErrors = Partial<Record<LocalContactKey | 'deliveryCountry', string>>;
export function emptyLocalCheckoutAddress(): LocalCheckoutAddress {
  return Object.fromEntries(localContactFields.map(field => [field.key, ''])) as LocalCheckoutAddress;
}

/** Local field feedback mirrors existing checkout required fields, server text bounds/email and country normalization.
 * It is not address lookup or authority to create an order. */
export function localCheckoutAddressErrors(fields: LocalCheckoutAddress, country: string): LocalCheckoutAddressErrors {
  const missing = new Set<string>(missingCheckoutContactFields(fields));
  const errors: LocalCheckoutAddressErrors = {};
  for (const field of localContactFields) {
    const value = fields[field.key];
    if (missing.has(field.key)) errors[field.key] = 'Udfyld dette felt.';
    else if (value.length > field.max || INVALID_CHECKOUT_TEXT.test(value)) {
      errors[field.key] = `Brug almindelig tekst med højst ${field.max} tegn.`;
    }
  }
  if (!errors.customerEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(fields.customerEmail.trim())) errors.customerEmail = 'Angiv en gyldig e-mailadresse.';
  if (!checkoutCountryCode(country)) errors.deliveryCountry = 'Angiv en landekode på to bogstaver, fx DK.';
  return errors;
}
