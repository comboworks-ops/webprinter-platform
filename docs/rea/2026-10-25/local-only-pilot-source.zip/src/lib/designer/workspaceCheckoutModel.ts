import { allocation, designStatus, workspaceCheckout, type DesignWorkspace } from './designWorkspaceModel.ts';
import type { SiteCheckoutState } from '../checkout/siteCheckoutSession.ts';

// A local acceptance adapter for the saved product; never a commercial split permission.
export const LOCAL_BROCHURE_PRODUCT_ID = '1f494aac-e4f2-47a2-96ab-b4b6955382ef';
export const LOCAL_BROCHURE_TENANT_ID = '00000000-0000-0000-0000-000000000000';
export const MAX_WORKSPACE_CHECKOUT_DESIGNS = 8;
export interface WorkspaceCheckoutFile {
  designId: string; name: string; quantity: number; revision: number;
  sha256: string; pdf: Blob; preview: string | null; warnings: string[];
}
export interface WorkspaceCheckoutBundle {
  version: 1; localOnly: true; id: string; workspaceId: string; selectionKey: string;
  selectionFingerprint: string; checkout: SiteCheckoutState; returnPath: string;
  files: WorkspaceCheckoutFile[]; createdAt: string;
}
export function isLocalBrochureWorkspace(checkout: SiteCheckoutState) {
  return checkout.productId === LOCAL_BROCHURE_PRODUCT_ID
    && checkout.checkoutTenantId === LOCAL_BROCHURE_TENANT_ID && checkout.designerMode === 'brochure';
}
export function assertWorkspaceCheckoutReady(workspace: DesignWorkspace) {
  if (!isLocalBrochureWorkspace(workspace.checkout)) throw new Error('Åbn arbejdspladsen fra det gemte brochureprodukt.');
  if (!allocation(workspace).valid) throw new Error('Fordel det valgte antal mellem dine designs først.');
  if (workspace.designs.length > MAX_WORKSPACE_CHECKOUT_DESIGNS) throw new Error('Den lokale checkout understøtter højst 8 designs.');
  if (workspace.designs.some(d => designStatus(d) !== 'Klar til print' || d.revision < 1 || !d.pdf?.size)) {
    throw new Error('Gem og godkend den aktuelle tryk-PDF for hvert design først.');
  }
  if (new Set(workspace.designs.map(d => d.id)).size !== workspace.designs.length) throw new Error('Designreferencerne er ikke entydige. Åbn arbejdspladsen igen.');
  const c = workspace.checkout, p = new URLSearchParams(workspace.designerParams);
  if (!Number.isInteger(c.brochurePageCount) || c.brochurePageCount! < 8 || c.brochurePageCount! > 152 || c.brochurePageCount! % 4
    || !Number.isFinite(c.designWidthMm) || c.designWidthMm! <= 0 || !Number.isFinite(c.designHeightMm) || c.designHeightMm! <= 0
    || !Number.isFinite(c.designBleedMm) || c.designBleedMm! < 0) throw new Error('Brochurens sidetal eller mål er ugyldige.');
  if (p.get('productId') !== c.productId || p.get('tenantId') !== c.checkoutTenantId
    || Number(p.get('brochurePages')) !== c.brochurePageCount
    || Number(p.get('widthMm')) !== c.designWidthMm || Number(p.get('heightMm')) !== c.designHeightMm
    || !c.templatePdfSha256 || p.get('templatePdfSha256') !== c.templatePdfSha256
    || !c.templatePdfUrl || p.get('templatePdfUrl') !== c.templatePdfUrl) {
    throw new Error('Brochurens produkt, format eller skabelon matcher ikke. Vælg produktet igen.');
  }
  if (!c.pricingQuote || c.pricingQuote.productId !== c.productId || c.pricingQuote.quantity !== c.quantity
    || !Number.isFinite(c.productPrice) || c.productPrice <= 0
    || !Number.isFinite(c.extraPrice ?? 0) || (c.extraPrice ?? 0) < 0) {
    throw new Error('Vælg en aktuel pris i produktets prismatrix først.');
  }
}
export async function assertWorkspaceCheckoutFileHashes(bundle: WorkspaceCheckoutBundle, workspace: DesignWorkspace,
  hash: (file: Blob) => Promise<string>) {
  assertWorkspaceCheckoutCurrent(bundle, workspace);
  for (const [index, file] of bundle.files.entries()) {
    if (await hash(file.pdf) !== file.sha256 || await hash(workspace.designs[index].pdf!) !== file.sha256) {
      throw new Error('En trykfil er ændret. Godkend den aktuelle fil og åbn checkout igen.');
    }
  }
}
export function workspaceCheckoutFingerprint(workspace: DesignWorkspace) {
  return JSON.stringify(workspaceCheckout(workspace.checkout));
}
export function assertWorkspaceCheckoutCurrent(bundle: WorkspaceCheckoutBundle, workspace: DesignWorkspace) {
  assertWorkspaceCheckoutReady(workspace);
  if (bundle.version !== 1 || bundle.localOnly !== true || bundle.workspaceId !== workspace.id
    || bundle.selectionKey !== workspace.selectionKey || bundle.selectionFingerprint !== workspaceCheckoutFingerprint(workspace)
    || bundle.files.length !== workspace.designs.length || !isLocalBrochureWorkspace(bundle.checkout)
    || JSON.stringify(bundle.checkout) !== JSON.stringify(workspaceCheckout(workspace.checkout))) {
    throw new Error('Produktvalget er ændret. Åbn checkout igen fra dine designs.');
  }
  for (const [index, file] of bundle.files.entries()) {
    const current = workspace.designs[index];
    if (file.designId !== current.id || file.revision !== current.revision || file.quantity !== current.quantity
      || file.name !== current.name || !/^[a-f0-9]{64}$/.test(file.sha256) || !(file.pdf instanceof Blob)) {
      throw new Error('Et design eller antal er ændret. Kontrollér dine designs og åbn checkout igen.');
    }
  }
}
