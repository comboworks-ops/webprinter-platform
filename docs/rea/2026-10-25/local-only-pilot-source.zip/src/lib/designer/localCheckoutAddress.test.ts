import assert from 'node:assert/strict';
import test from 'node:test';
import { emptyLocalCheckoutAddress, localCheckoutAddressErrors, localContactFields } from './localCheckoutAddress.ts';
import { checkoutCountryCode, missingCheckoutContactFields } from '../checkout/addressIntegrity.ts';
import { validateCheckoutOrder } from '../../../supabase/functions/_shared/storefrontCheckout.ts';

const valid = () => ({ ...emptyLocalCheckoutAddress(), customerName: 'Lokal prøvekunde', customerEmail: 'test@nord-atelier.example',
  deliveryRecipientName: 'Lokal prøvemodtager', deliveryAddress: 'Prøvevej 12', deliveryZip: '8000', deliveryCity: 'Aarhus C' });

test('local address uses the same required contact/recipient fields as normal checkout', () => {
  const fields = emptyLocalCheckoutAddress();
  assert.deepEqual(missingCheckoutContactFields(fields), ['customerEmail', 'customerName', 'deliveryRecipientName', 'deliveryAddress', 'deliveryZip', 'deliveryCity']);
  assert.equal(Object.keys(localCheckoutAddressErrors(fields, 'DK')).length, 6);
  for (const key of missingCheckoutContactFields(fields)) {
    const changed = valid(); changed[key] = ' \t ';
    assert.equal(localCheckoutAddressErrors(changed, 'DK')[key], 'Udfyld dette felt.');
  }
  assert.deepEqual(localCheckoutAddressErrors(valid(), 'Danmark'), {});
});
test('optional company and line 2 stay optional; address edits are not trimmed or mutated while typing', () => {
  const fields = { ...valid(), deliveryCompany: ' Nord Atelier ', deliveryAddress2: ' 2. sal, tv. ', deliveryAddress: ' Prøvevej 12 ' };
  const before = structuredClone(fields);
  assert.deepEqual(localCheckoutAddressErrors(fields, 'dk'), {});
  assert.deepEqual(fields, before);
});
test('e-mail format and malformed country use existing checkout rules', () => {
  for (const email of ['name', 'name@domain', 'name @example.test', 'name@example.test extra']) {
    assert.ok(localCheckoutAddressErrors({ ...valid(), customerEmail: email }, 'DK').customerEmail);
  }
  for (const country of ['', 'Atlantis', 'D\u0000K']) assert.ok(localCheckoutAddressErrors(valid(), country).deliveryCountry);
  // Country syntax is separate from the existing VAT policy, which rejects non-DK delivery.
  assert.equal(checkoutCountryCode('SE'), 'SE');
});
test('all fields enforce existing checkout text bounds and reject control characters', () => {
  for (const field of localContactFields) {
    assert.ok(localCheckoutAddressErrors({ ...valid(), [field.key]: 'x'.repeat(field.max + 1) }, 'DK')[field.key]);
    assert.ok(localCheckoutAddressErrors({ ...valid(), [field.key]: 'bad\u0000text' }, 'DK')[field.key]);
  }
});
test('contact/address preflight stays compatible with the existing server validator without creating an order', () => {
  for (const patch of [{}, { customerEmail: 'invalid' }, { deliveryAddress: ' ' }, { deliveryZip: ' ' },
    { customerName: 'x'.repeat(251) }, { deliveryAddress2: 'x'.repeat(501) }, { deliveryCity: 'bad\u0000text' }]) {
    const fields = { ...valid(), ...patch };
    const input = { customer_email: fields.customerEmail, customer_name: fields.customerName, delivery_address: fields.deliveryAddress,
      delivery_address2: fields.deliveryAddress2, delivery_zip: fields.deliveryZip, delivery_city: fields.deliveryCity, delivery_country: 'DK',
      files: [{ file_name: 'local-test.pdf', storage_path: 'order-files/local-test.pdf', bucket: 'order-files', sha256: 'a'.repeat(64) }] };
    let serverAccepts = true;
    try { validateCheckoutOrder(input); } catch { serverAccepts = false; }
    assert.equal(Object.keys(localCheckoutAddressErrors(fields, 'DK')).length === 0, serverAccepts);
  }
});
