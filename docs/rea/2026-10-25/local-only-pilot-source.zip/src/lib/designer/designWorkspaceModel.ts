import type { SiteCheckoutState } from '../checkout/siteCheckoutSession.ts';

export interface WorkspaceDesign {
  id: string;
  name: string;
  quantity: number;
  revision: number;
  approvedRevision: number | null;
  snapshot: object | null;
  preview: string | null;
  pdf: Blob | null;
  errors: string[];
  warnings: string[];
}
export interface DesignWorkspace {
  version: 1;
  id: string;
  selectionKey: string;
  checkout: SiteCheckoutState;
  designerParams: string;
  returnPath: string;
  designs: WorkspaceDesign[];
  updatedAt: string;
}
export function newWorkspaceDesign(quantity = 0): WorkspaceDesign {
  return { id: crypto.randomUUID(), name: 'Nyt design', quantity, revision: 0, approvedRevision: null,
    snapshot: null, preview: null, pdf: null, errors: [], warnings: [] };
}
export function designStatus(design: WorkspaceDesign) {
  if (!design.snapshot) return 'Mangler design';
  if (design.errors.length) return 'Skal rettes';
  if (!design.pdf) return 'Tryk-PDF mangler';
  return design.approvedRevision === design.revision ? 'Klar til print' : 'Afventer godkendelse';
}
export function allocation(workspace: DesignWorkspace) {
  const total = workspace.checkout.quantity || 0;
  const assigned = workspace.designs.reduce((sum, design) => sum + design.quantity, 0);
  const valid = workspace.designs.length > 0 && workspace.designs.every(d => Number.isSafeInteger(d.quantity) && d.quantity > 0);
  return { total, assigned, remaining: total - assigned, valid: valid && total === assigned };
}
export function approveWorkspaceDesign(design: WorkspaceDesign, revision: number): WorkspaceDesign {
  if (design.revision !== revision || !design.snapshot || !design.pdf || design.errors.length) {
    throw new Error('Designet er ændret eller mangler en gyldig tryk-PDF. Åbn korrekturen igen.');
  }
  return { ...design, approvedRevision: revision };
}
export function saveWorkspaceRevision(design: WorkspaceDesign, expectedRevision: number,
  saved: Pick<WorkspaceDesign, 'snapshot' | 'preview' | 'pdf' | 'errors' | 'warnings'>): WorkspaceDesign {
  if (design.revision !== expectedRevision) throw new Error('Designet er ændret i en anden fane. Behold denne fane åben.');
  const changed = JSON.stringify(design.snapshot) !== JSON.stringify(saved.snapshot)
    || JSON.stringify(design.errors) !== JSON.stringify(saved.errors) || JSON.stringify(design.warnings) !== JSON.stringify(saved.warnings)
    || Boolean(design.pdf) !== Boolean(saved.pdf);
  return { ...design, ...saved, revision: design.revision + (changed ? 1 : 0),
    approvedRevision: changed ? null : design.approvedRevision };
}
/** Product configuration stays authoritative. Artwork allocation never computes a price. */
export function workspaceSelectionKey(checkout: SiteCheckoutState, designerParams: string): string {
  const params = new URLSearchParams(designerParams);
  for (const key of ['order', 'returnTo', 'backTo', 'designId']) params.delete(key);
  params.sort();
  const quote = checkout.pricingQuote;
  return JSON.stringify({ tenant: checkout.checkoutTenantId, product: checkout.productId, params: params.toString(),
    format: checkout.selectedFormat, variant: checkout.selectedVariant, options: checkout.optionSelections,
    quote: quote ? { ...quote, quantity: undefined, quantityTiers: undefined, shippingSelected: undefined } : null });
}
/** Only retain the product selection, never customer details or another artwork's upload. */
export function workspaceCheckout(checkout: SiteCheckoutState): SiteCheckoutState {
  const fields: (keyof SiteCheckoutState)[] = ['checkoutTenantId', 'productId', 'productSlug', 'productName', 'productReturnPath',
    'designerMode', 'brochurePageCount', 'pricingModel', 'quantity', 'productPrice', 'extraPrice', 'totalPrice', 'summary',
    'selectedVariant', 'selectedFormat', 'linkedTemplateId', 'templatePdfName', 'templatePdfUrl', 'templatePdfSha256',
    'designWidthMm', 'designHeightMm', 'designBleedMm', 'designSafeAreaMm', 'optionSelections', 'pricingQuote', 'requiresCutContour'];
  return Object.fromEntries(fields.map(key => [key, checkout[key]]));
}
