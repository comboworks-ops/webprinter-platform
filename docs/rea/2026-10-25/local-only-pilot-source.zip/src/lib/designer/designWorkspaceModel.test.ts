import test from 'node:test';
import assert from 'node:assert/strict';
import { allocation, approveWorkspaceDesign, designStatus, newWorkspaceDesign, saveWorkspaceRevision, workspaceCheckout, workspaceSelectionKey, type DesignWorkspace } from './designWorkspaceModel.ts';
import { assertWorkspaceContext } from './workspaceContext.ts';

const checkout = { checkoutTenantId: 'shop-a', productId: 'product-a', quantity: 1000, productPrice: 1290,
  pricingQuote: { quantity: 1000, materialId: 'paper-a' }, selectedFormat: 'A5' };
const design = () => ({ ...newWorkspaceDesign(400), revision: 1, snapshot: { objects: [{ text: 'First' }] },
  pdf: new Blob(['pdf'], { type: 'application/pdf' }), approvedRevision: 1 });
const workspace = (): DesignWorkspace => ({ version: 1, id: 'workspace', selectionKey: 'selection', checkout,
  designerParams: 'productId=product-a&tenantId=shop-a&widthMm=148&heightMm=210&templatePdfSha256=abc', returnPath: '/produkt/flyers',
  designs: [design(), { ...design(), quantity: 600 }], updatedAt: '' });

test('quantity allocation never changes selected matrix price or approvals', () => {
  const value = workspace();
  value.designs[0].quantity = 500;
  assert.deepEqual(allocation(value), { total: 1000, assigned: 1100, remaining: -100, valid: false });
  assert.equal(value.checkout.productPrice, 1290);
  assert.equal(designStatus(value.designs[0]), 'Klar til print');
});
test('zero and fractional quantities do not pass even when sum matches', () => {
  const value = workspace();
  value.designs[0].quantity = 0; value.designs[1].quantity = 1000;
  assert.equal(allocation(value).valid, false);
  value.designs[0].quantity = 0.5; value.designs[1].quantity = 999.5;
  assert.equal(allocation(value).valid, false);
});
test('changed artwork invalidates only that revision, preserving other designs', () => {
  const value = workspace(), original = value.designs[0];
  value.designs[0] = saveWorkspaceRevision(original, 1, { ...original, snapshot: { objects: [{ text: 'Changed' }] } });
  assert.equal(value.designs[0].revision, 2); assert.equal(value.designs[0].approvedRevision, null);
  assert.equal(value.designs[1].approvedRevision, 1);
});
test('unchanged save retains approval; new PDF readiness or errors require review', () => {
  const original = design();
  assert.equal(saveWorkspaceRevision(original, 1, original).approvedRevision, 1);
  assert.equal(saveWorkspaceRevision(original, 1, { ...original, errors: ['Bad contour'] }).approvedRevision, null);
});
test('stale edits and stale approvals are rejected', () => {
  assert.throws(() => saveWorkspaceRevision(design(), 0, design()), /anden fane/);
  assert.throws(() => approveWorkspaceDesign(design(), 0), /ændret/);
});
test('missing PDF, missing artwork and preflight errors cannot be approved', () => {
  for (const value of [{ ...design(), pdf: null }, { ...design(), snapshot: null }, { ...design(), errors: ['Outside bleed'] }]) {
    assert.throws(() => approveWorkspaceDesign(value, value.revision));
    assert.notEqual(designStatus(value), 'Klar til print');
  }
});
test('quantity and price updates keep selection identity but stock, template and tenant do not', () => {
  const value = workspace(), key = workspaceSelectionKey(checkout, value.designerParams);
  assert.equal(workspaceSelectionKey({ ...checkout, quantity: 2000, productPrice: 1890, pricingQuote: { ...checkout.pricingQuote, quantity: 2000 } }, value.designerParams), key);
  assert.notEqual(workspaceSelectionKey({ ...checkout, checkoutTenantId: 'shop-b' }, value.designerParams), key);
  assert.notEqual(workspaceSelectionKey({ ...checkout, pricingQuote: { ...checkout.pricingQuote, materialId: 'paper-b' } }, value.designerParams), key);
  assert.notEqual(workspaceSelectionKey(checkout, value.designerParams.replace('abc', 'def')), key);
});
test('workspace does not retain customer details or another checkout artwork', () => {
  const value = workspaceCheckout({ ...checkout, checkoutCustomer: { customerEmail: 'private@example.test' }, siteUpload: { fileUrl: 'private' }, designerExport: { filePath: 'private' } });
  assert.equal(value.checkoutCustomer, undefined); assert.equal(value.siteUpload, undefined); assert.equal(value.designerExport, undefined);
  assert.equal(value.productPrice, 1290);
});
test('designer handoff rejects changed tenant, dimensions, template and hosted design IDs', () => {
  const value = workspace();
  assert.doesNotThrow(() => assertWorkspaceContext(value, new URLSearchParams(value.designerParams)));
  for (const [key, content] of [['tenantId', 'shop-b'], ['widthMm', '210'], ['templatePdfSha256', 'wrong'], ['designId', 'remote']]) {
    const params = new URLSearchParams(value.designerParams); params.set(key, content);
    assert.throws(() => assertWorkspaceContext(value, params));
  }
});
