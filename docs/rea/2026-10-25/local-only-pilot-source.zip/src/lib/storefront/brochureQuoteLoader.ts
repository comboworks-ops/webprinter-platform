import { readBrochureFreePriceResponse, type BrochureFreeSelection } from '../pricing/brochureFreePricing.ts';

export type BrochureQuotePrices = Array<[number, number]>;
type ReadQuote = (endpoint: string, source: BrochureFreeSelection) => Promise<BrochureQuotePrices>;
type Subscriber = { resolve: (value: BrochureQuotePrices) => void; reject: (error: unknown) => void; cleanup: () => void };
type Job = { key: string; endpoint: string; source: BrochureFreeSelection; subscribers: Set<Subscriber> };

async function readQuote(endpoint: string, source: BrochureFreeSelection): Promise<BrochureQuotePrices> {
  const params = new URLSearchParams({ articleId: source.articleId, substrateId: source.nativePaperId,
    widthMm: String(source.widthMm), heightMm: String(source.heightMm) });
  const response = await fetch(`${endpoint}?${params}`);
  const payload = await response.json();
  if (!response.ok) throw Error(payload.error || 'Prisen kunne ikke hentes.');
  return readBrochureFreePriceResponse(payload, source);
}

/** Read-only delivery of the unchanged exact quote. Two active requests match the existing API limit. */
export function createBrochureQuoteLoader(read: ReadQuote = readQuote, now = Date.now) {
  const cache = new Map<string, { at: number; prices: BrochureQuotePrices }>();
  const pending = new Map<string, Job>(), queue: Job[] = [];
  let active = 0;
  const drain = () => {
    while (active < 2 && queue.length) {
      const job = queue.shift()!;
      if (!job.subscribers.size) { pending.delete(job.key); continue; }
      active++;
      // Started requests finish even after a subscriber leaves: aborting the browser
      // fetch would not cancel the server's supplier work and could exceed its limit.
      void read(job.endpoint, job.source).then(prices => {
        pending.delete(job.key);
        if (cache.size >= 128) cache.delete(cache.keys().next().value!);
        cache.set(job.key, { at: now(), prices });
        for (const subscriber of job.subscribers) { subscriber.cleanup(); subscriber.resolve(prices); }
      }, error => {
        pending.delete(job.key);
        for (const subscriber of job.subscribers) { subscriber.cleanup(); subscriber.reject(error); }
      }).finally(() => { active--; drain(); });
    }
  };
  return {
    load(endpoint: string, source: BrochureFreeSelection, signal: AbortSignal): Promise<BrochureQuotePrices> {
      if (signal.aborted) return Promise.reject(new DOMException('', 'AbortError'));
      const key = JSON.stringify([endpoint, source.articleId, source.nativePaperId, source.pageCount, source.widthMm, source.heightMm]);
      const hit = cache.get(key);
      if (hit && now() - hit.at < 300000) return Promise.resolve(hit.prices);
      return new Promise((resolve, reject) => {
        let job = pending.get(key);
        if (!job) { job = { key, endpoint, source, subscribers: new Set() }; pending.set(key, job); queue.push(job); }
        const subscriber: Subscriber = { resolve, reject, cleanup: () => signal.removeEventListener('abort', cancel) };
        const cancel = () => { job!.subscribers.delete(subscriber); subscriber.cleanup(); reject(new DOMException('', 'AbortError')); };
        job.subscribers.add(subscriber); signal.addEventListener('abort', cancel, { once: true });
        drain();
      });
    },
  };
}
export const brochureQuoteLoader = createBrochureQuoteLoader();
