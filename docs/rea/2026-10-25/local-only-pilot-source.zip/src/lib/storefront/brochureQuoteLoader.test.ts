import test from 'node:test';
import assert from 'node:assert/strict';
import { createBrochureQuoteLoader, type BrochureQuotePrices } from './brochureQuoteLoader.ts';

const source = (paper: string, widthMm = 148) => ({ articleId: '2009', nativePaperId: paper, pageCount: 8, widthMm, heightMm: 210 });
const prices: BrochureQuotePrices = [[50, 669], [100, 944]];
const tick = () => new Promise(resolve => setImmediate(resolve));
test('automatic requests are deduplicated, cached by exact dimensions/paper and limited to two in flight', async () => {
  const started: string[] = [], release: (() => void)[] = [];
  const loader = createBrochureQuoteLoader(async (_, value) => {
    started.push(`${value.nativePaperId}:${value.widthMm}`);
    await new Promise<void>(resolve => release.push(resolve)); return prices;
  });
  const signal = new AbortController().signal;
  const a = loader.load('/quote', source('a'), signal), same = loader.load('/quote', source('a'), signal);
  const b = loader.load('/quote', source('b'), signal), c = loader.load('/quote', source('c'), signal);
  assert.deepEqual(started, ['a:148', 'b:148']);
  release.shift()!(); await a; await same; await tick();
  assert.deepEqual(started, ['a:148', 'b:148', 'c:148']);
  release.shift()!(); release.shift()!(); await Promise.all([b, c]);
  assert.equal(await loader.load('/quote', source('a'), signal), prices);
  const changed = loader.load('/quote', source('a', 149), signal);
  assert.equal(started[started.length - 1], 'a:149'); release.shift()!(); await changed;
});
test('cancelled queued rows are not fetched, and leaving an active quote does not free its server slot early', async () => {
  const started: string[] = [], release: (() => void)[] = [];
  const loader = createBrochureQuoteLoader(async (_, value) => {
    started.push(value.nativePaperId); await new Promise<void>(resolve => release.push(resolve)); return prices;
  });
  const first = new AbortController(), queued = new AbortController(), active = new AbortController();
  const a = loader.load('/quote', source('a'), first.signal), b = loader.load('/quote', source('b'), active.signal);
  const c = loader.load('/quote', source('c'), queued.signal);
  const aRejected = assert.rejects(a, { name: 'AbortError' }), cRejected = assert.rejects(c, { name: 'AbortError' });
  first.abort(); queued.abort(); await Promise.all([aRejected, cRejected]);
  const d = loader.load('/quote', source('d'), active.signal);
  assert.deepEqual(started, ['a', 'b']);
  release.shift()!(); await tick(); assert.deepEqual(started, ['a', 'b', 'd']);
  release.shift()!(); release.shift()!(); await Promise.all([b, d]);
});
test('failed quotes are retryable and successful quotes expire at the existing five-minute cache window', async () => {
  let at = 0, calls = 0;
  const loader = createBrochureQuoteLoader(async () => { if (++calls === 1) throw new Error('offline'); return prices; }, () => at);
  const signal = new AbortController().signal;
  await assert.rejects(loader.load('/quote', source('a'), signal), /offline/);
  await loader.load('/quote', source('a'), signal); await tick();
  at = 299999; await loader.load('/quote', source('a'), signal); assert.equal(calls, 2);
  at = 300000; await loader.load('/quote', source('a'), signal); assert.equal(calls, 3);
});
