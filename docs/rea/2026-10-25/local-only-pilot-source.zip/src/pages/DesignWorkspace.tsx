import Header from '@/components/Header';
import { useEffect, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { allocation, designStatus, newWorkspaceDesign, type DesignWorkspace as Workspace, type WorkspaceDesign } from '@/lib/designer/designWorkspaceModel';
import { approveDesignWorkspace, changeDesignWorkspace, listDesignWorkspaces, localDesignWorkspaceEnabled, readDesignWorkspace, workspaceDesignerPath, workspacePath } from '@/lib/designer/localDesignWorkspace';
import { getSafeInternalPath } from '@/lib/designer/orderFlowNavigation';
import '@/styles/designWorkspace.css';
import { isLocalBrochureWorkspace } from '@/lib/designer/workspaceCheckoutModel';
import { createLocalWorkspaceCheckout, localWorkspaceCheckoutPath } from '@/lib/designer/localWorkspaceCheckout';

function PdfProof({ design }: { design: WorkspaceDesign }) {
  const [url, setUrl] = useState<string>();
  useEffect(() => {
    if (!design.pdf) return;
    const value = URL.createObjectURL(design.pdf);
    setUrl(value);
    return () => URL.revokeObjectURL(value);
  }, [design.pdf]);
  return url ? <a className="underline" href={url} target="_blank" rel="noopener noreferrer">Åbn tryk-PDF · version {design.revision}</a> : null;
}

export default function DesignWorkspace() {
  const navigate = useNavigate();
  const [params] = useSearchParams(), id = params.get('workspace');
  const [workspace, setWorkspace] = useState<Workspace | null>(null);
  const [workspaces, setWorkspaces] = useState<Workspace[]>([]);
  const [reviewId, setReviewId] = useState<string | null>(null);
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false), [error, setError] = useState('');
  useEffect(() => {
    let active = true;
    setWorkspace(null); setReviewId(null); setError('');
    const load = async () => {
      try {
        if (id) { const value = await readDesignWorkspace(id); if (active) setWorkspace(value); }
        else { const values = await listDesignWorkspaces(); if (active) setWorkspaces(values); }
      } catch (failure) { if (active) setError((failure as Error).message); }
    };
    void load();
    return () => { active = false; };
  }, [id]);
  const change = async (apply: (value: Workspace) => Workspace) => {
    if (!id || busy) return false;
    setBusy(true); setError('');
    try { setWorkspace(await changeDesignWorkspace(id, apply)); return true; }
    catch (failure) { setError((failure as Error).message); return false; }
    finally { setBusy(false); }
  };
  if (!localDesignWorkspaceEnabled()) return <p className="p-8">Denne arbejdsplads er kun til lokal afprøvning.</p>;
  const review = workspace?.designs.find(d => d.id === reviewId);
  const counts = workspace ? allocation(workspace) : null;
  const ready = workspace?.designs.filter(d => designStatus(d) === 'Klar til print').length || 0;
  const money = (amount: number) => new Intl.NumberFormat('da-DK', { style: 'currency', currency: 'DKK' }).format(amount);
  const openCheckout = async () => {
    if (!workspace || busy) return;
    setBusy(true); setError('');
    try { navigate(localWorkspaceCheckoutPath(await createLocalWorkspaceCheckout(workspace.id))); }
    catch (failure) { setError((failure as Error).message); }
    finally { setBusy(false); }
  };
  return <main className="design-workspace">
    <Header />
    <div className="dw-header"><span>Lokal afprøvning · Gemmes i denne browser</span>{id && <Link className="underline" to={`/design-workspace${params.get("tenantId") ? `?tenantId=${encodeURIComponent(params.get("tenantId")!)}` : ""}`}>Alle lokale arbejdspladser</Link>}</div>
    <div className="dw-body">
      <div className="dw-heading"><div><h1>Dine designs</h1><p className="text-muted-foreground">{workspace?.checkout.productName || 'Lokale designarbejdspladser'}</p></div>
        {workspace && <Button variant="outline" asChild><Link to={getSafeInternalPath(workspace.returnPath) || '/shop'} state={{ localWorkspaceSelection: workspace.checkout }}>Prismatrix og produktvalg</Link></Button>}
      </div>
      {error && <p role="alert" className="dw-error">{error}</p>}
      {!workspace && !error && (id ? <p role="status">Åbner dine designs…</p> : <div className="dw-list">
        {workspaces.map(w => <Link key={w.id} to={workspacePath(w.id, w.designerParams)} className="dw-panel"><strong>{w.checkout.productName}</strong><p>{w.designs.length} designs · {w.checkout.quantity} stk</p></Link>)}
        {!workspaces.length && <p>Vælg et produkt og en pris i webshoppen. Tryk derefter på “Flere designs · lokal test”.</p>}
      </div>)}
      {workspace && <>
        <section className="dw-panel dw-selection" aria-label="Valg fra prismatrix"><div><h2>Valgt i prismatricen</h2><p>{workspace.checkout.summary || workspace.checkout.selectedVariant}</p><p>{workspace.checkout.quantity} stk · {workspace.checkout.designWidthMm} × {workspace.checkout.designHeightMm} mm</p></div><div><strong className="dw-price">{money(workspace.checkout.productPrice || 0)}</strong><p className="text-sm text-muted-foreground">Produktpris ekskl. moms · fra eksisterende prisvalg</p></div></section>
        {review ? <section className="dw-panel" aria-label={`Korrektur: ${review.name}`}>
          <div className="dw-heading"><div><h2>{review.name}</h2><p>Version {review.revision} · {review.quantity} stk</p></div><Button variant="outline" onClick={() => setReviewId(null)}>Til alle designs</Button></div>
          <div className="dw-proof"><div>{review.preview && <img src={review.preview} alt={`Korrektur af ${review.name}`} />}<PdfProof design={review} /></div><div>
            <h3>{designStatus(review)}</h3><p>Kontrol fra den eksisterende designer</p>
            {review.errors.map((message, index) => <p className="dw-error" key={index}>{message}</p>)}
            {review.warnings.map((message, index) => <p className="dw-warning" key={index}>{message}</p>)}
            {review.pdf && !review.errors.length && <p>Tryk-PDF er oprettet lokalt med designerens eksisterende eksport.</p>}
            <div className="dw-actions"><Button asChild variant="outline"><Link to={workspaceDesignerPath(workspace, review.id)}>Rediger i designeren</Link></Button></div>
            {review.pdf && !review.errors.length && review.approvedRevision !== review.revision && <>
              <label className="dw-check"><input type="checkbox" checked={checked} onChange={e => setChecked(e.target.checked)} />Jeg har kontrolleret tekst, placering og tryk-PDF samt eventuelle advarsler for denne version.</label>
              <Button disabled={!checked || busy} onClick={async () => {
                if (!id || busy) return;
                setBusy(true); setError('');
                try {
                  setWorkspace(await approveDesignWorkspace(id, review.id, review.revision));
                  setReviewId(null); setChecked(false);
                } catch (failure) { setError((failure as Error).message); }
                finally { setBusy(false); }
              }}>Godkend denne version</Button>
            </>}
          </div></div>
        </section> : <div className="dw-grid"><section aria-label="Designoversigt">
          <div className="dw-heading"><h2>{workspace.designs.length} designs</h2><Button disabled={busy || workspace.designs.length >= 20} onClick={() => void change(current => ({ ...current, designs: [...current.designs, newWorkspaceDesign()] }))}>Tilføj design</Button></div>
          <div className="dw-cards">{workspace.designs.map(design => <article className="dw-card" key={design.id} aria-label={design.name}>
            <div className="dw-thumbnail">{design.preview ? <img src={design.preview} alt={`Forhåndsvisning af ${design.name}`} /> : <span>Dit design her</span>}</div>
            <div className="dw-card-body"><Input aria-label={`Navn på ${design.name}`} defaultValue={design.name} maxLength={80} disabled={busy} onBlur={e => {
              const name = e.target.value.trim();
              if (name && name !== design.name) void change(current => ({ ...current, designs: current.designs.map(d => d.id === design.id ? { ...d, name } : d) }));
              else e.target.value = design.name;
            }} /><p className="dw-status" data-ready={designStatus(design) === 'Klar til print'}>{designStatus(design)}</p><p className="text-sm text-muted-foreground">Version {design.revision}</p>
              <label className="dw-quantity">Antal<Input aria-label={`Antal til ${design.name}`} key={`${design.id}-${design.quantity}`} type="number" min={0} max={1000000} step={1} defaultValue={design.quantity} disabled={busy} onBlur={e => {
                const quantity = Number(e.target.value);
                if (!Number.isSafeInteger(quantity) || quantity < 0 || quantity > 1000000) { setError('Angiv et helt antal mellem 0 og 1.000.000.'); e.target.value = String(design.quantity); return; }
                if (quantity !== design.quantity) void change(current => ({ ...current, designs: current.designs.map(d => d.id === design.id ? { ...d, quantity } : d) }));
              }} /></label>
              <Button asChild><Link to={workspaceDesignerPath(workspace, design.id)}>{design.snapshot ? 'Rediger design' : 'Opret i designeren'}</Link></Button>
              {design.snapshot && <Button variant="outline" onClick={() => { setReviewId(design.id); setChecked(false); }}>Se korrektur</Button>}
            </div>
          </article>)}</div>
          <p className={counts?.valid ? 'dw-allocation' : 'dw-allocation dw-warning'} role="status" aria-live="polite">{counts?.assigned} af {counts?.total} stk fordelt. {counts?.remaining ? `Fordel ${counts.remaining > 0 ? `${counts.remaining} stk mere` : `${-counts.remaining} stk mindre`}.` : counts?.valid ? 'Antallet stemmer.' : 'Hvert design skal have mindst 1 stk.'}</p>
          <Button variant="outline" disabled={busy} onClick={() => void change(current => {
            const total = current.checkout.quantity || 0, n = current.designs.length;
            return { ...current, designs: current.designs.map((d, i) => ({ ...d, quantity: Math.floor(total / n) + (i < total % n ? 1 : 0) })) };
          })}>Fordel antallet ligeligt</Button>
        </section><aside className="dw-panel dw-summary" aria-label="Status for bestilling"><h2>{ready} af {workspace.designs.length} klar</h2><p>{counts?.valid && ready === workspace.designs.length ? 'Alle designs har tryk-PDF og godkendt korrektur.' : 'Ret og godkend hvert design, og fordel det valgte antal.'}</p><hr /><p>Prismatricens pris bevares. Fordelingen her ændrer ingen beregninger.</p>
          {isLocalBrochureWorkspace(workspace.checkout) && <Button className="min-h-11 w-full" disabled={busy || !counts?.valid || ready !== workspace.designs.length || workspace.designs.length > 8} onClick={() => void openCheckout()}>{busy ? 'Kontrollerer trykfiler…' : 'Fortsæt til lokal checkout'}</Button>}
          <p className="text-sm text-muted-foreground">Lokal test: ingen betaling eller afsendelse til tryk. Deling af et samlet antal skal være tilladt for produktet, før dette kobles til bestilling.</p></aside></div>}
      </>}
    </div>
  </main>;
}
