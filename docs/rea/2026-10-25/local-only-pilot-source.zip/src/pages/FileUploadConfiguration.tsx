import { applyBrochureDocumentParams } from '@/lib/designer/brochureProduct';
import { validBrochurePageCount, validateBrochurePdfPageCount } from '@/lib/designer/brochureDocument';
import { normalizeCheckoutFormatKey, checkoutTemplateFormatLabel } from '@/lib/checkout/formatLabels';
import { PrintMockupButton } from '@/components/mockup/PrintMockupButton';
import { useApprovedPrintModel } from '@/components/mockup/useApprovedPrintModel';
import { resolveApprovedPrintModel } from '@/lib/mockup/approvedPrintModels';
import { preparePrintModelPdf, placePrintArtwork } from '@/lib/mockup/printModelArtwork';
import { PrintJourneyDialogContent } from '@/components/storefront/PrintJourneyDialogContent';
import { resolveSharedButton, sharedButtonAttributes } from '@/lib/branding/sharedButtons';
import { CheckoutProductValue } from '@/components/checkout/CheckoutProductValue';
import { quantityValueOptions, type QuantityTier } from '@/lib/checkout/quantityValue';
import { FileUploadProgress } from "@/components/checkout/FileUploadProgress";
import { FileProofActions } from "@/components/checkout/FileProofActions";
import { PrintWarningAcknowledgement } from "@/components/checkout/PrintWarningAcknowledgement";
import { recommendedPrintDpi, placedImageDpi, resolutionWarning, printWarningAcceptanceKey, printWarningOrderNote, PRINT_QUALITY_RESPONSIBILITY, GENERAL_PROOF_ACKNOWLEDGEMENT, type PrintWarningApproval } from "@/lib/checkout/printQualityPolicy";
import { FolderMockupButton } from '@/components/mockup/FolderMockupButton';
import { resolveFolderDefinition } from '@/lib/mockup/folderDefinition';
import { composeFolderArtwork } from '@/lib/mockup/artwork';
import type { FileTransferProgress } from "@/lib/storage/resumableUpload";
import { openLocalPdf } from "@/lib/localPdf";
import { StorefrontPrimaryButton } from "@/components/storefront/StorefrontPrimaryButton";
import {safePdfDocumentOptions} from '@/lib/pdfDocumentOptions';
import { uploadCheckoutFile, readCheckoutUpload, checkoutUploadAccess, MAX_CHECKOUT_UPLOAD_BYTES, CHECKOUT_UPLOAD_LIMIT_LABEL } from "@/lib/checkout/privateUploads";
import { PDF_COLOUR_REVIEW_NOTICE } from '@/lib/checkout/pdfColourReview';
import { useOrderFlowDesign } from "@/hooks/useOrderFlowDesign";
import { PREVIEW_PAYMENT_DISABLED, PREVIEW_PAYMENT_MESSAGE } from "@/lib/isolatedPreview";
import { OrderDesignPreviewSwitch } from "@/components/checkout/OrderDesignPreviewSwitch";
import { OrderCheckoutLayout, OrderFlowDialog, OrderPaymentLayout, OrderConfirmationLayout, ProofReviewLayout, type OrderReceiptData } from "@/components/checkout/OrderFlowLayouts";
import { useState, useEffect, useMemo, useRef, lazy, Suspense } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useShopSettings } from "@/hooks/useShopSettings";
import { useUserRole } from "@/hooks/useUserRole";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Loader2, Upload, AlertCircle, CheckCircle2, FileText, ArrowRight, Download, Info, Sparkles, Package, X, Clock3, RotateCcw, ChevronDown, User, Truck } from "lucide-react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { StripePaymentForm } from "@/components/checkout/StripePaymentForm";
import { resolveDeliveryMethodCost } from "@/lib/delivery/defaults";
import { normalizeCheckoutDeliveryMethods, type CheckoutDeliveryMethod } from "@/lib/delivery/checkoutDelivery";
import {
    clearSiteCheckoutDesignReady,
    isSiteCheckoutDesignReady,
    readSiteCheckoutSession,
    writeSiteCheckoutSession,
} from "@/lib/checkout/siteCheckoutSession";
import { deleteCheckoutCustomerProfile, readCheckoutCustomerProfiles, upsertCheckoutCustomerProfile, type CheckoutCustomerProfile } from "@/lib/checkout/customerProfiles";
import { fillEmptyCustomerContact, resolveCustomerContact } from "@/lib/account/profile";
import { canHydrateDeliveryAddress, checkoutCountryCode, deliveryAddressLines, missingCheckoutContactFields } from "@/lib/checkout/addressIntegrity";
import { requiresProofExport, proofArtifactFingerprint, primaryProductionFiles } from "@/lib/checkout/proofArtifact";
import { getCheckoutProofAvailability } from "@/lib/checkout/proofAvailability";
import { hashCheckoutArtifact } from "@/lib/checkout/checkoutArtifact";
import { checkoutNotificationNotice } from "@/lib/checkout/checkoutNotification";
import { checkoutStartMessage } from "@/lib/checkout/checkoutStartMessage";
import { checkoutProductReturnPath, checkoutTenantConflict, readCheckoutProduct } from "@/lib/checkout/checkoutProduct";
import { checkoutTaxPreview } from '@/lib/checkout/tax';
import { linkCompanyOrder } from "@/lib/company-hub";
import { readCheckoutRecovery, saveCheckoutRecovery, clearCheckoutRecovery, requireCheckoutV2Response } from "@/lib/checkout/checkoutRecovery";
import { ptToMm } from "@/utils/unitConversions";
import {
    getFlyerMatrixDataFromDB,
    getFolderMatrixDataFromDB,
    getVisitkortMatrixDataFromDB,
    getPosterMatrixDataFromDB,
    getStickerMatrixDataFromDB,
    getBookletMatrixDataFromDB,
    getSalesfolderMatrixDataFromDB,
    getBeachflagMatrixDataFromDB,
    getBannerMatrixDataFromDB,
    getSignMatrixDataFromDB,
    getFoilMatrixDataFromDB,
    getGenericMatrixDataFromDB
} from "@/utils/pricingDatabase";
import { StorefrontThemeFrame } from "@/components/storefront/StorefrontThemeFrame";
import {
    applyDesignerDocumentParams,
    buildCurrentInternalPath,
    buildProductFallbackPath,
    getSafeInternalPath,
} from "@/lib/designer/orderFlowNavigation";
import {
    ProductFormatGuidePanel,
    type ProductFormatGuideData,
} from "@/components/product-price-page/ProductFormatGuide";
import {
    templateMatchesSelectedConfiguration,
    type ProductTemplateFile,
} from "@/lib/designer/productTemplateLinks";

interface TechnicalSpecs {
    width_mm: number;
    height_mm: number;
    bleed_mm: number;
    min_dpi: number;
    safe_area_mm?: number;
}

type TemplateFile = ProductTemplateFile & {
    path?: string;
};

interface LinkedTemplatePreview {
    previewUrl: string;
    source: "image" | "pdf";
}

type OptionPriceMode = "fixed" | "per_quantity" | "per_area";

interface CheckoutOptionSelection {
    optionId: string;
    name: string;
    extraPrice: number;
    priceMode: OptionPriceMode;
}

interface SizeDistributionField {
    key: string;
    label: string;
}



interface ProofingPreviewData {
    fileType: "image" | "pdf";
    previewUrl: string;
    physicalWidthMm: number;
    physicalHeightMm: number;
    sourceWidthPx: number;
    sourceHeightPx: number;
    pageCount?: number;
}

interface ProofingHandlePosition {
    key: string;
    left?: string;
    right?: string;
    top?: string;
    bottom?: string;
    translate: string;
    cursor: string;
}

interface CheckoutPreflightResult {
    dpi?: number;
    width_px?: number;
    height_px?: number;
    aspectRatioMatch: boolean;
    dpiOk: boolean;
    issues: string[];
}

interface PdfContourScanResult {
    cutContourNameDetected: boolean;
    separationHintDetected: boolean;
    overprintHintDetected: boolean;
    summary: string;
    note: string;
}

type CheckoutFlowNotice = {
    title: string;
    body: string;
    checklist: string[];
    tone: "blue" | "amber" | "emerald" | "slate";
    designerActionLabel: string;
    showDesignerAction: boolean;
};

const getCheckoutFlowNotice = (
    designerMode?: string | null,
    productFlowLabel?: string | null,
    requiresCutContour = false,
    professionalPdfUploadOnly = false,
    artworkModeReasonDa?: string | null,
): CheckoutFlowNotice => {
    const mode = String(designerMode || "").trim();
    const label = String(productFlowLabel || "Fil-tjek").trim();

    if (professionalPdfUploadOnly) {
        return {
            title: "Professionel tryk-PDF kræves",
            body: String(artworkModeReasonDa || "Denne efterbehandling kræver en separat staffagefarve, som online-designeren ikke kan oprette sikkert. Download skabelonen og upload en færdig tryk-PDF."),
            checklist: [
                "Brug den valgte produktskabelon til den færdige trykfil.",
                "Bevar den krævede staffagefarve og overprint i din professionelle PDF.",
                "Online-designeren er deaktiveret for denne efterbehandling.",
            ],
            tone: "amber",
            designerActionLabel: "Online-designer ikke tilgængelig",
            showDesignerAction: false,
        };
    }

    if (mode === "brochure") {
        return {
            title: "Brochurens sider",
            body: "Upload brochuren som enkeltsider i læserækkefølge, eller åbn sidedesigneren.",
            checklist: ["Forside er side 1, bagside er sidste side.", "Sidetallet omfatter omslaget og går op i fire.", "Alle sider skal have det valgte format og 3 mm udfald."],
            tone: "blue", designerActionLabel: "Åbn sidedesigner", showDesignerAction: true,
        };
    }

    if (mode === "pdf_template") {
        return {
            title: "Skabelonprodukt",
            body: "Brug upload til en færdig trykfil, eller åbn designeren når filen skal placeres oven på produktets skabelon.",
            checklist: [
                "Skabelonlinjer bruges kun som visuel kontrol.",
                "Fold, ryg, beskæring og sikkerhedszone skal passe før betaling.",
                "Skabelonens hjælpelinjer må ikke ende som trykbar grafik.",
            ],
            tone: "blue",
            designerActionLabel: "Åbn designer med skabelon",
            showDesignerAction: true,
        };
    }

    if (mode === "upload_only") {
        return {
            title: "Kun upload og fil-tjek",
            body: "Dette produkt er sat op til færdige trykfiler. Upload filen her og brug korrekturvinduet til sidste kontrol.",
            checklist: [
                "Designknappen skjules på produktsiden.",
                "Korrektur kontrollerer størrelse, bleed og sikkerhedszone.",
                "Fuld designer bruges kun som manuel ekstra-kontrol.",
            ],
            tone: "slate",
            designerActionLabel: "Åbn manuel designerkontrol",
            showDesignerAction: true,
        };
    }

    if (mode === "storformat" || mode === "signage") {
        return {
            title: mode === "signage" ? "Skilt/facade flow" : "Storformat flow",
            body: "Upload en produktionsklar fil, eller brug designeren til at kontrollere motivet mod de valgte mål.",
            checklist: [
                "Motivet kontrolleres mod bredde, højde og bleed.",
                requiresCutContour ? "CutContour bør kontrolleres, hvis produktet kræver udskæring." : "Brug PDF for mest stabil filkontrol.",
                "Store rasterfiler skal have nok opløsning ved valgt størrelse.",
            ],
            tone: "emerald",
            designerActionLabel: mode === "signage" ? "Åbn skiltdesigner" : "Åbn storformatdesigner",
            showDesignerAction: true,
        };
    }

    if (mode === "apparel") {
        return {
            title: "Tekstiltryk flow",
            body: "Upload motivet her. Størrelser og antal håndteres i ordreflowet, mens designeren kan bruges til placering af trykfelt.",
            checklist: [
                "Motivet skal være klart og i høj opløsning.",
                "Størrelsesfordeling skal matche det samlede antal.",
                "Designer er bedst til placering, ikke til prisændringer.",
            ],
            tone: "amber",
            designerActionLabel: "Åbn trykfeltdesigner",
            showDesignerAction: true,
        };
    }

    return {
        title: label,
        body: "Upload en trykklar fil, eller brug designeren hvis du vil placere eller kontrollere filen visuelt.",
        checklist: [
            "PDF anbefales til trykklare filer.",
            "Korrektur viser størrelse, bleed og sikkerhedszone.",
            "Du kan gå tilbage til produktet uden at miste konfigurationen.",
        ],
        tone: "blue",
        designerActionLabel: "Åbn fuld designer",
        showDesignerAction: true,
    };
};

const checkoutFlowNoticeClasses: Record<CheckoutFlowNotice["tone"], string> = {
    blue: "border-sky-200 bg-sky-50 text-sky-950",
    amber: "border-amber-200 bg-amber-50 text-amber-950",
    emerald: "border-emerald-200 bg-emerald-50 text-emerald-950",
    slate: "border-slate-200 bg-slate-50 text-slate-900",
};

interface CheckoutSavedAddress {
    id: string;
    label: string | null;
    company_name: string | null;
    first_name: string;
    last_name: string;
    street_address: string;
    street_address_2: string | null;
    postal_code: string;
    city: string;
    country: string;
    phone: string | null;
    is_default: boolean;
}

type CheckoutSenderMode = "standard" | "blind" | "custom";
const PROOFING_MIN_SCALE = 40;
const PROOFING_OVERFLOW_MARGIN_PERCENT = 25;
const PROOFING_HANDLE_POSITIONS: ProofingHandlePosition[] = [
    {
        key: "top-left",
        left: "0%",
        top: "0%",
        translate: "translate(-50%, -50%)",
        cursor: "nwse-resize",
    },
    {
        key: "top-right",
        right: "0%",
        top: "0%",
        translate: "translate(50%, -50%)",
        cursor: "nesw-resize",
    },
    {
        key: "bottom-left",
        left: "0%",
        bottom: "0%",
        translate: "translate(-50%, 50%)",
        cursor: "nesw-resize",
    },
    {
        key: "bottom-right",
        right: "0%",
        bottom: "0%",
        translate: "translate(50%, 50%)",
        cursor: "nwse-resize",
    },
];

const STANDARD_SPECS: Record<string, { width_mm: number; height_mm: number; min_dpi: number }> = {
    "A6": { width_mm: 105, height_mm: 148, min_dpi: 300 },
    "M65": { width_mm: 99, height_mm: 210, min_dpi: 300 },
    "A5": { width_mm: 148, height_mm: 210, min_dpi: 300 },
    "A4": { width_mm: 210, height_mm: 297, min_dpi: 300 },
    "A3": { width_mm: 297, height_mm: 420, min_dpi: 300 },
    "A2": { width_mm: 420, height_mm: 594, min_dpi: 300 },
    "A1": { width_mm: 594, height_mm: 841, min_dpi: 300 },
    "A0": { width_mm: 841, height_mm: 1189, min_dpi: 300 },
    "standard": { width_mm: 85, height_mm: 55, min_dpi: 300 }, // Visitkort
    "85x55": { width_mm: 85, height_mm: 55, min_dpi: 300 },
};

const SIZE_OPTION_PREFIX = "size-dist-";
const deliveryDateFormatter = new Intl.DateTimeFormat("da-DK", {
    weekday: "short",
    day: "numeric",
    month: "short",
});
const deliveryDateTimeFormatter = new Intl.DateTimeFormat("da-DK", {
    weekday: "short",
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
});

const toSafeKey = (value: string) =>
    value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");

const parseSizeValueFromName = (name: string): number => {
    const match = String(name || "").match(/:\s*([0-9]+)/);
    if (!match) return 0;
    const parsed = Number(match[1]);
    if (!Number.isFinite(parsed) || parsed <= 0) return 0;
    return Math.floor(parsed);
};

const normalizeOptionSelections = (raw: unknown): Record<string, CheckoutOptionSelection> => {
    if (!raw || typeof raw !== "object") return {};

    const entries = Object.entries(raw as Record<string, any>);
    const normalized: Record<string, CheckoutOptionSelection> = {};

    entries.forEach(([entryKey, value], idx) => {
        if (!value || typeof value !== "object") return;
        const optionId = String(value.optionId || entryKey || `opt-${idx}`);
        const name = String(value.name || "").trim();
        if (!name) return;

        const extraPriceRaw = Number(value.extraPrice || 0);
        const extraPrice = Number.isFinite(extraPriceRaw) ? extraPriceRaw : 0;

        const priceModeRaw = String(value.priceMode || "fixed");
        const priceMode: OptionPriceMode =
            priceModeRaw === "per_quantity" || priceModeRaw === "per_area"
                ? priceModeRaw
                : "fixed";

        normalized[optionId] = {
            optionId,
            name,
            extraPrice,
            priceMode,
        };
    });

    return normalized;
};



const parseCutoffTime = (time?: string) => {
    if (!time) return null;
    const [hours, minutes] = time.split(":").map(Number);
    if (!Number.isFinite(hours) || !Number.isFinite(minutes)) return null;
    return { hours, minutes };
};

const getNextCutoffDate = (method: CheckoutDeliveryMethod, now: Date) => {
    const parsed = parseCutoffTime(method.cutoff_time);
    if (!parsed) return null;

    const cutoff = new Date(now);
    cutoff.setHours(parsed.hours, parsed.minutes, 0, 0);
    if (cutoff.getTime() <= now.getTime()) {
        cutoff.setDate(cutoff.getDate() + 1);
    }

    return cutoff;
};

const formatCountdown = (ms: number) => {
    if (ms <= 0) return "0m";
    const totalSeconds = Math.floor(ms / 1000);
    const days = Math.floor(totalSeconds / 86400);
    const hours = Math.floor((totalSeconds % 86400) / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;

    if (days > 0) return `${days}d ${hours}t`;
    if (hours > 0) return `${hours}t ${minutes}m`;
    return `${minutes}m ${String(seconds).padStart(2, "0")}s`;
};

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

const approximatelyMatchesSize = (
    widthMm: number,
    heightMm: number,
    targetWidthMm: number,
    targetHeightMm: number,
    toleranceMm = 1.5
) => {
    const directMatch = Math.abs(widthMm - targetWidthMm) <= toleranceMm && Math.abs(heightMm - targetHeightMm) <= toleranceMm;
    const rotatedMatch = Math.abs(widthMm - targetHeightMm) <= toleranceMm && Math.abs(heightMm - targetWidthMm) <= toleranceMm;
    return directMatch || rotatedMatch;
};

const PDF_MARKS_MARGIN_MM = 25;

const resolvePdfPrintableSize = (
    widthMm: number,
    heightMm: number,
    specs: TechnicalSpecs
) => {
    const trimWidthMm = specs.width_mm;
    const trimHeightMm = specs.height_mm;
    const bleedWidthMm = specs.width_mm + (specs.bleed_mm * 2);
    const bleedHeightMm = specs.height_mm + (specs.bleed_mm * 2);

    const matchesTrim = approximatelyMatchesSize(widthMm, heightMm, trimWidthMm, trimHeightMm);
    const matchesBleed = approximatelyMatchesSize(widthMm, heightMm, bleedWidthMm, bleedHeightMm);

    const trimWithMarks =
        widthMm >= trimWidthMm - 1
        && heightMm >= trimHeightMm - 1
        && widthMm <= trimWidthMm + (PDF_MARKS_MARGIN_MM * 2)
        && heightMm <= trimHeightMm + (PDF_MARKS_MARGIN_MM * 2);

    const bleedWithMarks =
        widthMm >= bleedWidthMm - 1
        && heightMm >= bleedHeightMm - 1
        && widthMm <= bleedWidthMm + (PDF_MARKS_MARGIN_MM * 2)
        && heightMm <= bleedHeightMm + (PDF_MARKS_MARGIN_MM * 2);

    if (matchesBleed || bleedWithMarks) {
        return {
            displayWidthMm: bleedWidthMm,
            displayHeightMm: bleedHeightMm,
            matchesExpected: true,
        };
    }

    if (matchesTrim || trimWithMarks) {
        return {
            displayWidthMm: trimWidthMm,
            displayHeightMm: trimHeightMm,
            matchesExpected: true,
        };
    }

    return {
        displayWidthMm: widthMm,
        displayHeightMm: heightMm,
        matchesExpected: false,
    };
};

const clampProofingOffset = (
    nextOffset: { x: number; y: number },
    displayedWidthPercent: number,
    displayedHeightPercent: number
) => {
    const maxX = Math.max(50, ((displayedWidthPercent + 100) / 2) + PROOFING_OVERFLOW_MARGIN_PERCENT);
    const maxY = Math.max(50, ((displayedHeightPercent + 100) / 2) + PROOFING_OVERFLOW_MARGIN_PERCENT);

    return {
        x: clamp(nextOffset.x, -maxX, maxX),
        y: clamp(nextOffset.y, -maxY, maxY),
    };
};

const parsePositiveNumber = (value: unknown): number | null => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed <= 0) return null;
    return parsed;
};

const parseNonNegativeNumber = (value: unknown): number | null => {
    if (value == null || value === '') return null;
    const parsed = Number(value);
    return Number.isFinite(parsed) && parsed >= 0 ? parsed : null;
};

const normalizeFormatKey = normalizeCheckoutFormatKey;

const getStandardFormatLabelFromSpecs = (specs: TechnicalSpecs | null) => {
    if (!specs?.width_mm || !specs?.height_mm) return null;

    const width = Math.round(specs.width_mm);
    const height = Math.round(specs.height_mm);

    for (const [label, dims] of Object.entries(STANDARD_SPECS)) {
        if (Math.round(dims.width_mm) === width && Math.round(dims.height_mm) === height) {
            return label;
        }
    }

    return null;
};

const getReadableFormatLabel = (
    rawFormat: unknown,
    specs: TechnicalSpecs | null
) => {
    const standardFormatLabel = getStandardFormatLabelFromSpecs(specs);
    if (standardFormatLabel) {
        return standardFormatLabel;
    }

    if (typeof rawFormat === "string" && rawFormat.trim()) {
        const trimmed = rawFormat.trim();
        const looksLikeUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(trimmed);
        const normalized = normalizeFormatKey(rawFormat);
        if (normalized && normalized !== trimmed) return normalized;
        if (!looksLikeUuid) return trimmed;
    }

    if (specs?.width_mm && specs?.height_mm) {
        return `${Math.round(specs.width_mm)} x ${Math.round(specs.height_mm)} mm`;
    }

    return "Standard";
};

const splitFullName = (value: string) => {
    const parts = String(value || "").trim().split(/\s+/).filter(Boolean);
    if (parts.length === 0) {
        return { firstName: "", lastName: "" };
    }
    if (parts.length === 1) {
        return { firstName: parts[0], lastName: "" };
    }
    return {
        firstName: parts.slice(0, -1).join(" "),
        lastName: parts.slice(-1).join(" "),
    };
};

const formatSavedAddressLabel = (address: CheckoutSavedAddress) => {
    const name = [address.first_name, address.last_name].filter(Boolean).join(" ").trim();
    const company = String(address.company_name || "").trim();
    const primary = [name, company].filter(Boolean).join(" · ");
    const secondary = [address.street_address, `${address.postal_code} ${address.city}`.trim()]
        .filter(Boolean)
        .join(", ");
    return [primary || address.label || "Adresse", secondary].filter(Boolean).join(" — ");
};

const addBusinessDays = (date: Date, days: number) => {
    const next = new Date(date);
    let remaining = Math.max(0, days);

    while (remaining > 0) {
        next.setDate(next.getDate() + 1);
        const weekday = next.getDay();
        if (weekday !== 0 && weekday !== 6) {
            remaining -= 1;
        }
    }

    return next;
};

const parseDeliveryDate = (value?: string) => {
    if (!value) return null;
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed;
};

const getEstimatedDeliveryDate = (method: CheckoutDeliveryMethod, now: Date) => {
    const explicitDate = parseDeliveryDate(method.delivery_date);
    if (explicitDate) return explicitDate;

    const cutoff = getNextCutoffDate(method, now);
    const base = cutoff && cutoff.getTime() > now.getTime() ? cutoff : now;
    const leadTime = Math.max(
        1,
        Number.isFinite(Number(method.lead_time_days))
            ? Number(method.lead_time_days)
            : Number(method.production_days || 0) + Number(method.shipping_days || 0),
    );

    return addBusinessDays(base, leadTime);
};

import { isDraftFlow, DRAFT_FLOW_MESSAGE } from "@/lib/checkout/draftFlow";

const FileUploadConfigurationContent = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const locationSearchParams = useMemo(() => new URLSearchParams(location.search), [location.search]);
    const returnedPaymentIntentId = locationSearchParams.get("payment_intent");
    const persistedCheckoutState = useMemo(() => readSiteCheckoutSession(), []);
    const incomingCheckoutState = location.state as any;
    const rawCheckoutState = incomingCheckoutState?.checkoutInstanceId
        && incomingCheckoutState.checkoutInstanceId === persistedCheckoutState?.checkoutInstanceId
        ? persistedCheckoutState : incomingCheckoutState || persistedCheckoutState;
    const hasCheckoutState = Boolean(rawCheckoutState);
    const state = rawCheckoutState || {};
    const draftFlow = isDraftFlow(locationSearchParams, state);
    const trialAccess = useUserRole();
    const allowUnpublished = draftFlow && trialAccess.isAdmin && Boolean(trialAccess.userId);
    const draftAccessLoading = draftFlow && trialAccess.loading;
    const [checkoutInstanceId] = useState(() => String(state.checkoutInstanceId || crypto.randomUUID()));
    // Give this browser history entry a stable checkout identity, including reload.
    // A fresh product configuration arrives without one and starts a new checkout.
    useEffect(() => {
        if (!hasCheckoutState || state.checkoutInstanceId === checkoutInstanceId) return;
        navigate({ pathname: location.pathname, search: location.search }, {
            replace: true, state: { ...state, checkoutInstanceId },
        });
    }, [checkoutInstanceId, hasCheckoutState, state, location.pathname, location.search, navigate]);
    const checkoutTitle = String(state?.checkoutTitle || "Konfigurer dit design");
    const productFlowLabel = String(state?.productFlowLabel || "Fil-tjek");
    const productFlowHelpText = String(state?.productFlowHelpText || "");
    const activeDesignerMode = typeof state?.designerMode === "string" ? state.designerMode : null;
    const checkoutTemplatePdfUrl = typeof state?.templatePdfUrl === "string" && state.templatePdfUrl.trim()
        ? state.templatePdfUrl.trim()
        : null;
    const checkoutTemplatePdfName = typeof state?.templatePdfName === "string" && state.templatePdfName.trim()
        ? state.templatePdfName.trim()
        : "Produktskabelon";
    const checkoutTemplatePdfSha256 = typeof state?.templatePdfSha256 === "string"
        && /^[a-f0-9]{64}$/i.test(state.templatePdfSha256.trim())
        ? state.templatePdfSha256.trim().toLowerCase()
        : null;
    const checkoutTemplateArtworkMode = state?.templateArtworkMode === "professional_pdf_upload_only"
        ? "professional_pdf_upload_only"
        : state?.templateArtworkMode === "online_designer"
            ? "online_designer"
            : null;
    const checkoutTemplateArtworkModeReasonDa = typeof state?.templateArtworkModeReasonDa === "string"
        && state.templateArtworkModeReasonDa.trim()
        ? state.templateArtworkModeReasonDa.trim()
        : null;
    const professionalPdfUploadOnly = checkoutTemplateArtworkMode === "professional_pdf_upload_only";
    const checkoutTemplateDownloadName = checkoutTemplatePdfName.toLowerCase().endsWith(".pdf")
        ? checkoutTemplatePdfName
        : `${checkoutTemplatePdfName}.pdf`;
    const checkoutUploadTitle = String(state?.checkoutUploadTitle || "Upload trykfil");
    const checkoutUploadHelpText = String(
        state?.checkoutUploadHelpText
        || "Upload en trykklar PDF eller brug fuld designer til at placere filen på formatet.",
    );
    const shopSettings = useShopSettings();
    const branding = shopSettings.data?.branding;
    const sharedSelection = sharedButtonAttributes(resolveSharedButton(branding, 'selection', 'order-selection'), 'selection');
    const checkoutDesign = useOrderFlowDesign('checkout', branding);
    const proofDesign = useOrderFlowDesign('proof', branding);
    const paymentDesign = useOrderFlowDesign('payment', branding);
    const confirmationDesign = useOrderFlowDesign('confirmation', branding);
    const tenantName = String(
        branding?.shop_name
        || shopSettings.data?.tenant_name
        || shopSettings.data?.company?.name
        || "Din Shop",
    ).trim() || "Din Shop";
    const initialShippingCost = Number.isFinite(Number(state?.shippingCost)) ? Math.round(Number(state.shippingCost)) : 0;
    const initialTotalPrice = Number.isFinite(Number(state?.totalPrice)) ? Math.round(Number(state.totalPrice)) : 0;
    const initialBasePrice = Math.round(Number(state?.productPrice || 0) + Number(state?.extraPrice || 0));
    const initialOrderSubtotal = Math.max(0, initialTotalPrice - initialShippingCost) || initialBasePrice || initialTotalPrice;
    const persistedSiteUpload = state?.siteUpload;
    const persistedDesignerExport = state?.designerExport;

    const [loading, setLoading] = useState(true);
    const [product, setProduct] = useState<any>(null);
    const [productError, setProductError] = useState<string | null>(null);
    const [productRetry, setProductRetry] = useState(0);
    const checkoutTenantId = String(shopSettings.data?.id || '');
    const tenantConflict = Boolean(checkoutTenantId && checkoutTenantConflict(state, { id: checkoutTenantId, domain: shopSettings.data?.domain }));
    const productReady = Boolean(product && !loading && !productError && !tenantConflict && (!draftFlow || (allowUnpublished && !draftAccessLoading)));
    const [orderDeliveryConfig, setOrderDeliveryConfig] = useState<any>(null);
    const [uploading, setUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState<FileTransferProgress>({phase: "preparing", loaded: 0, total: 0});
    const uploadBusyRef = useRef(false);
    const [uploadDropActive, setUploadDropActive] = useState(false);
    const [uploadedFile, setUploadedFile] = useState<{ name: string; url: string; path: string; sha256: string } | null>(() => {
        if (persistedDesignerExport?.fileUrl) {
            return {
                name: String(persistedDesignerExport.name || "designer-production.pdf"),
                url: String(persistedDesignerExport.fileUrl),
                path: String(persistedDesignerExport.filePath || ""),
                sha256: String(persistedDesignerExport.sha256 || ""),
            };
        }
        if (!persistedSiteUpload?.fileUrl || !persistedSiteUpload?.filePath) return null;
        return {
            name: String(persistedSiteUpload.name || "upload"),
            url: String(persistedSiteUpload.fileUrl),
            path: String(persistedSiteUpload.filePath),
            sha256: String(persistedSiteUpload.sha256 || ""),
        };
    });
    const [checkoutUserId, setCheckoutUserId] = useState<string | null>(null);
    const [savedCustomerProfiles, setSavedCustomerProfiles] = useState<CheckoutCustomerProfile[]>([]);

    const markTemplateDownloaded = () => {
        if (!checkoutTemplatePdfUrl) return;
        const existingSession = readSiteCheckoutSession() || state;
        writeSiteCheckoutSession({
            ...existingSession,
            templatePdfName: checkoutTemplatePdfName,
            templatePdfUrl: checkoutTemplatePdfUrl,
            templateDownloadedAt: new Date().toISOString(),
        });
    };
    const [selectedCustomerProfileId, setSelectedCustomerProfileId] = useState(String(state?.checkoutCustomer?.selectedCustomerProfileId || "new"));
    const [customerProfileLabel, setCustomerProfileLabel] = useState("");
    const [customerEmail, setCustomerEmail] = useState(String(state?.checkoutCustomer?.customerEmail || ""));
    const [customerName, setCustomerName] = useState(String(state?.checkoutCustomer?.customerName || ""));
    const [customerPhone, setCustomerPhone] = useState(String(state?.checkoutCustomer?.customerPhone || ""));
    const [customerCompany, setCustomerCompany] = useState(String(state?.checkoutCustomer?.customerCompany || ""));
    const [savedAddresses, setSavedAddresses] = useState<CheckoutSavedAddress[]>([]);
    const [savedAddressesLoading, setSavedAddressesLoading] = useState(false);
    const [selectedSavedAddressId, setSelectedSavedAddressId] = useState(String(state?.checkoutCustomer?.selectedSavedAddressId || "new"));
    const [deliveryRecipientName, setDeliveryRecipientName] = useState(String(state?.checkoutCustomer?.deliveryRecipientName || ""));
    const [deliveryCompany, setDeliveryCompany] = useState(String(state?.checkoutCustomer?.deliveryCompany || ""));
    const [deliveryAddress, setDeliveryAddress] = useState(String(state?.checkoutCustomer?.deliveryAddress || ""));
    const [deliveryAddress2, setDeliveryAddress2] = useState(String(state?.checkoutCustomer?.deliveryAddress2 || ""));
    const [deliveryCountry, setDeliveryCountry] = useState(String(state?.checkoutCustomer?.deliveryCountry || "DK"));
    const [deliveryZip, setDeliveryZip] = useState(String(state?.checkoutCustomer?.deliveryZip || ""));
    const [deliveryCity, setDeliveryCity] = useState(String(state?.checkoutCustomer?.deliveryCity || ""));
    const [saveAddressForLater, setSaveAddressForLater] = useState(Boolean(state?.checkoutCustomer?.saveAddressForLater));
    const [addressLabel, setAddressLabel] = useState(String(state?.checkoutCustomer?.addressLabel || ""));
    const [senderMode, setSenderMode] = useState<CheckoutSenderMode>(
        state?.checkoutCustomer?.senderMode === "blind" || state?.checkoutCustomer?.senderMode === "custom"
            ? state.checkoutCustomer.senderMode
            : "standard"
    );
    const [senderName, setSenderName] = useState(String(state?.checkoutCustomer?.senderName || ""));
    const [useSeparateBillingAddress, setUseSeparateBillingAddress] = useState(Boolean(state?.checkoutCustomer?.useSeparateBillingAddress));
    const [billingName, setBillingName] = useState(String(state?.checkoutCustomer?.billingName || ""));
    const [billingCompany, setBillingCompany] = useState(String(state?.checkoutCustomer?.billingCompany || ""));
    const [billingAddress, setBillingAddress] = useState(String(state?.checkoutCustomer?.billingAddress || ""));
    const [billingAddress2, setBillingAddress2] = useState(String(state?.checkoutCustomer?.billingAddress2 || ""));
    const [billingCountry, setBillingCountry] = useState(String(state?.checkoutCustomer?.billingCountry || "DK"));
    const [billingZip, setBillingZip] = useState(String(state?.checkoutCustomer?.billingZip || ""));
    const [billingCity, setBillingCity] = useState(String(state?.checkoutCustomer?.billingCity || ""));
    const deliveryDraftRef = useRef<Record<string, string>>({});
    const deliveryAddressEditedRef = useRef(false);
    deliveryDraftRef.current = { name: deliveryRecipientName, company: deliveryCompany, address: deliveryAddress, address2: deliveryAddress2, zip: deliveryZip, city: deliveryCity };
    const [paymentLoading, setPaymentLoading] = useState(false);
    const [tenantPaymentStatus, setTenantPaymentStatus] = useState<{
        status: string;
        charges_enabled: boolean;
        stripe_account_id: string | null;
    } | null>(null);
    const [paymentStatusLoaded, setPaymentStatusLoaded] = useState(false);
    const [preflightResults, setPreflightResults] = useState<{
        dpi?: number;
        width_px?: number;
        height_px?: number;
        aspectRatioMatch: boolean;
        dpiOk: boolean;
        issues: string[];
    } | null>(null);
    const [platformPreflight, setPlatformPreflight] = useState<{
        status: "PROCESSING" | "PROCESSED" | "FAILED";
        errors: string[];
        warnings: string[];
        fixes: string[];
        jobId?: string;
        updatedFileUrl?: string;
        message?: string;
    } | null>(null);
    const [platformPreflightLoading, setPlatformPreflightLoading] = useState(false);
    const [previewUrl, setPreviewUrl] = useState<string | null>(() => {
        const persistedPreview = persistedDesignerExport?.previewDataUrl
            || persistedSiteUpload?.previewDataUrl
            || persistedSiteUpload?.fileUrl;
        return persistedPreview ? String(persistedPreview) : null;
    });
    const [proofingPreview, setProofingPreview] = useState<ProofingPreviewData | null>(() => {
        if (persistedDesignerExport?.previewDataUrl) {
            const physicalWidthMm = Number(
                persistedDesignerExport.previewWidthMm
                || state?.designWidthMm
                || 0
            );
            const physicalHeightMm = Number(
                persistedDesignerExport.previewHeightMm
                || state?.designHeightMm
                || 0
            );

            if (physicalWidthMm > 0 && physicalHeightMm > 0) {
                return {
                    fileType: persistedDesignerExport.mimeType === "image/png" ? "image" : "pdf",
                    previewUrl: String(persistedDesignerExport.previewDataUrl),
                    physicalWidthMm,
                    physicalHeightMm,
                    sourceWidthPx: 0,
                    sourceHeightPx: 0,
                };
            }
        }

        if (!persistedSiteUpload?.previewDataUrl) return null;
        const physicalWidthMm = Number(persistedSiteUpload.physicalWidthMm || 0);
        const physicalHeightMm = Number(persistedSiteUpload.physicalHeightMm || 0);
        if (!Number.isFinite(physicalWidthMm) || !Number.isFinite(physicalHeightMm) || physicalWidthMm <= 0 || physicalHeightMm <= 0) {
            return null;
        }

        const fileName = String(persistedSiteUpload.name || "");
        const mimeType = String(persistedSiteUpload.mimeType || "");
        const fileType = mimeType === "application/pdf" || fileName.toLowerCase().endsWith(".pdf") ? "pdf" : "image";

        return {
            fileType,
            previewUrl: String(persistedSiteUpload.previewDataUrl),
            physicalWidthMm,
            physicalHeightMm,
            sourceWidthPx: Number(persistedSiteUpload.widthPx || 0),
            sourceHeightPx: Number(persistedSiteUpload.heightPx || 0),
        };
    });
    const [linkedTemplatePreview, setLinkedTemplatePreview] = useState<LinkedTemplatePreview | null>(null);
    const [pdfContourScan, setPdfContourScan] = useState<PdfContourScanResult | null>(null);
    const [proofingOpen, setProofingOpen] = useState(false);
    const [proofingApproved, setProofingApproved] = useState(Boolean(persistedDesignerExport?.fileUrl) && !state.proofApprovalRequired);
    const [approvedProofIdentity, setApprovedProofIdentity] = useState<string | null>(null);
    const [acceptedPrintWarningKey, setAcceptedPrintWarningKey] = useState("");
    const [approvedPrintWarnings, setApprovedPrintWarnings] = useState<PrintWarningApproval | null>(state.printWarningApproval || null);
    const [proofingScale, setProofingScale] = useState(100);
    const [proofingOffset, setProofingOffset] = useState({ x: 0, y: 0 });
    const [proofingDragging, setProofingDragging] = useState(false);
    const [proofingResizing, setProofingResizing] = useState(false);

    // Local Order Configuration (to allow for Best Deal upgrades)
    const [orderQuantity, setOrderQuantity] = useState<number>(state?.quantity || 0);
    const [orderPrice, setOrderPrice] = useState<number>(initialOrderSubtotal);
    const [quantityTiers, setQuantityTiers] = useState<QuantityTier[]>(state?.pricingQuote?.quantityTiers || []);
    const [exportingProof, setExportingProof] = useState(false);
    const proofExportBusyRef = useRef(false);
    const latestProofIdentityRef = useRef<string | null>(null);
    const [sizeDistributionValues, setSizeDistributionValues] = useState<Record<string, number>>({});
    const [shippingSelected, setShippingSelected] = useState<string>(String(state?.shippingSelected || ""));
    const [deliveryNow, setDeliveryNow] = useState<Date>(() => new Date());
    // Recipient-is-me toggle: when true, customer fields are reused as delivery fields.
    const [sendToSelf, setSendToSelf] = useState<boolean>(false);
    // "More options" accordion (sender mode + separate billing). Collapsed by default.
    const [moreOptionsOpen, setMoreOptionsOpen] = useState<boolean>(false);
    // "Your details" accordion — starts collapsed for logged-in users with pre-fill, expanded for guests.
    const [yourDetailsOpen, setYourDetailsOpen] = useState<boolean>(false);

    // Stripe payment state
    const [showPaymentModal, setShowPaymentModal] = useState(false);
    const [paymentClientSecret, setPaymentClientSecret] = useState<string | null>(null);
    const [paymentConnectedAccountId, setPaymentConnectedAccountId] = useState<string | null>(null);
    const [paymentSuccess, setPaymentSuccess] = useState(false);
    const [confirmedReceipt, setConfirmedReceipt] = useState<OrderReceiptData | null>(null);
    const [finalizingPayment, setFinalizingPayment] = useState(false);
    const finalizingPaymentRef = useRef(false);
    const [hasCheckoutRecovery, setHasCheckoutRecovery] = useState(false);
    const [recoverablePaymentId, setRecoverablePaymentId] = useState<string | null>(null);
    const [createdOrderNumber, setCreatedOrderNumber] = useState<string | null>(null);
    const [orderPersistWarning, setOrderPersistWarning] = useState<string | null>(null);
    const [orderNotificationWarning, setOrderNotificationWarning] = useState<string | null>(null);
    const [orderSuccessMessage, setOrderSuccessMessage] = useState("Vi har modtaget din betaling og begynder at behandle din ordre.");

    const fileInputRef = useRef<HTMLInputElement>(null);
    const checkoutSummaryRef = useRef<HTMLDivElement>(null);
    const returnToCheckoutAfterProofRef = useRef(false);
    const proofingDragStartRef = useRef<{ x: number; y: number; startX: number; startY: number } | null>(null);
    const proofingResizeStartRef = useRef<{ centerX: number; centerY: number; startDistance: number; startScale: number } | null>(null);
    const proofingArtworkRef = useRef<HTMLDivElement>(null);
    const proofingArtboardRef = useRef<HTMLDivElement>(null);
    const processedRedirectPaymentIntentRef = useRef<string | null>(null);

    const clearStripeReturnParams = () => {
        const nextParams = new URLSearchParams(locationSearchParams);
        const keys = ["payment_intent", "payment_intent_client_secret", "redirect_status"];
        let changed = false;

        keys.forEach((key) => {
            if (nextParams.has(key)) {
                nextParams.delete(key);
                changed = true;
            }
        });

        if (!changed) return;

        navigate(
            {
                pathname: location.pathname,
                search: nextParams.toString() ? `?${nextParams.toString()}` : "",
            },
            { replace: true, state: { ...state, checkoutInstanceId } }
        );
    };

    useEffect(() => {
        const linkedTemplateId = String(state?.linkedTemplateId || "").trim();
        if (!linkedTemplateId) {
            setLinkedTemplatePreview(null);
            return;
        }

        let cancelled = false;

        const loadLinkedTemplatePreview = async () => {
            try {
                const { data: template, error } = await supabase
                    .from("designer_templates")
                    .select("preview_image_url, template_pdf_url")
                    .eq("id", linkedTemplateId)
                    .maybeSingle();

                if (cancelled) return;
                if (error || !template) {
                    setLinkedTemplatePreview(null);
                    return;
                }

                if ((template as any).preview_image_url) {
                    setLinkedTemplatePreview({
                        previewUrl: String((template as any).preview_image_url),
                        source: "image",
                    });
                    return;
                }

                if ((template as any).template_pdf_url) {
                    const pdfjs = await import("pdfjs-dist");
                    pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

                    const loadingTask = pdfjs.getDocument(safePdfDocumentOptions({url: String((template as any).template_pdf_url)}));
                    const pdf = await loadingTask.promise;
                    const page = await pdf.getPage(1);
                    const viewport = page.getViewport({ scale: 2.5 });

                    const offscreenCanvas = document.createElement("canvas");
                    offscreenCanvas.width = Math.round(viewport.width);
                    offscreenCanvas.height = Math.round(viewport.height);
                    const context = offscreenCanvas.getContext("2d");
                    if (!context) {
                        setLinkedTemplatePreview(null);
                        return;
                    }

                    context.clearRect(0, 0, offscreenCanvas.width, offscreenCanvas.height);
                    await page.render({
                        canvasContext: context,
                        viewport,
                    }).promise;

                    if (cancelled) return;

                    setLinkedTemplatePreview({
                        previewUrl: offscreenCanvas.toDataURL("image/png", 1.0),
                        source: "pdf",
                    });
                    return;
                }

                setLinkedTemplatePreview(null);
            } catch (error) {
                if (cancelled) return;
                console.error("[Checkout] Failed to load linked template preview:", error);
                setLinkedTemplatePreview(null);
            }
        };

        loadLinkedTemplatePreview();

        return () => {
            cancelled = true;
        };
    }, [state?.linkedTemplateId]);

    const applySavedAddress = (address: CheckoutSavedAddress) => {
        setDeliveryRecipientName([address.first_name, address.last_name].filter(Boolean).join(" ").trim());
        setDeliveryCompany(String(address.company_name || ""));
        setDeliveryAddress(String(address.street_address || ""));
        setDeliveryAddress2(String(address.street_address_2 || ""));
        setDeliveryCountry(String(address.country || "DK"));
        setDeliveryZip(String(address.postal_code || ""));
        setDeliveryCity(String(address.city || ""));
        setCustomerPhone((prev) => prev || String(address.phone || ""));
        setAddressLabel(String(address.label || ""));
    };

    const applyCustomerProfile = (profile: CheckoutCustomerProfile) => {
        setCustomerEmail(String(profile.customerEmail || ""));
        setCustomerName(String(profile.customerName || ""));
        setCustomerPhone(String(profile.customerPhone || ""));
        setCustomerCompany(String(profile.customerCompany || ""));
        setDeliveryRecipientName(String(profile.deliveryRecipientName || ""));
        setDeliveryCompany(String(profile.deliveryCompany || ""));
        setDeliveryAddress(String(profile.deliveryAddress || ""));
        setDeliveryAddress2(String(profile.deliveryAddress2 || ""));
        setDeliveryCountry(String(profile.deliveryCountry || "DK"));
        setDeliveryZip(String(profile.deliveryZip || ""));
        setDeliveryCity(String(profile.deliveryCity || ""));
        setUseSeparateBillingAddress(Boolean(profile.useSeparateBillingAddress));
        setBillingName(String(profile.billingName || ""));
        setBillingCompany(String(profile.billingCompany || ""));
        setBillingAddress(String(profile.billingAddress || ""));
        setBillingAddress2(String(profile.billingAddress2 || ""));
        setBillingCountry(String(profile.billingCountry || "DK"));
        setBillingZip(String(profile.billingZip || ""));
        setBillingCity(String(profile.billingCity || ""));
        setSenderMode(
            profile.senderMode === "blind" || profile.senderMode === "custom"
                ? profile.senderMode
                : "standard"
        );
        setSenderName(String(profile.senderName || ""));
        setCustomerProfileLabel(profile.label || "");
    };

    const activeDeliveryMethods = useMemo(
        () => normalizeCheckoutDeliveryMethods(orderDeliveryConfig?.delivery?.methods),
        [orderDeliveryConfig]
    );

    useEffect(() => {
        if (activeDeliveryMethods.length === 0) return;
        if (!shippingSelected || !activeDeliveryMethods.some((method) => method.id === shippingSelected)) {
            setShippingSelected(activeDeliveryMethods[0].id);
        }
    }, [activeDeliveryMethods, shippingSelected]);

    // Mirror customer fields → delivery fields while "Send til mig selv" is on.
    // We snapshot delivery fields on toggle-on so we can restore them on toggle-off,
    // letting the customer experiment without losing typed recipient data.
    const savedRecipientSnapshot = useRef<null | {
        name: string;
        company: string;
        address: string;
        address2: string;
        country: string;
        zip: string;
        city: string;
        savedAddressId: string;
    }>(null);
    useEffect(() => {
        if (!sendToSelf) return;
        setDeliveryRecipientName(customerName);
        setDeliveryCompany(customerCompany);
    }, [sendToSelf, customerName, customerCompany]);
    const handleSendToSelfToggle = (next: boolean) => {
        if (next && !sendToSelf) {
            // Turning ON — snapshot current recipient, copy from customer.
            savedRecipientSnapshot.current = {
                name: deliveryRecipientName,
                company: deliveryCompany,
                address: deliveryAddress,
                address2: deliveryAddress2,
                country: deliveryCountry,
                zip: deliveryZip,
                city: deliveryCity,
                savedAddressId: selectedSavedAddressId,
            };
            setDeliveryRecipientName(customerName);
            setDeliveryCompany(customerCompany);
            setSelectedSavedAddressId("new");
        } else if (!next && sendToSelf) {
            // Turning OFF — restore whatever was there before, if anything.
            const snap = savedRecipientSnapshot.current;
            if (snap) {
                setDeliveryRecipientName(snap.name);
                setDeliveryCompany(snap.company);
                setDeliveryAddress(snap.address);
                setDeliveryAddress2(snap.address2);
                setDeliveryCountry(snap.country);
                setDeliveryZip(snap.zip);
                setDeliveryCity(snap.city);
                setSelectedSavedAddressId(snap.savedAddressId);
            }
        }
        setSendToSelf(next);
    };

    useEffect(() => {
        const timer = window.setInterval(() => setDeliveryNow(new Date()), 1000);
        return () => window.clearInterval(timer);
    }, []);

    useEffect(() => {
        return () => {
            if (previewUrl?.startsWith("blob:")) {
                URL.revokeObjectURL(previewUrl);
            }
        };
    }, [previewUrl]);

    const activeDeliveryMethod = useMemo(
        () => activeDeliveryMethods.find((method) => method.id === shippingSelected) || activeDeliveryMethods[0] || null,
        [activeDeliveryMethods, shippingSelected]
    );

    const shippingCost = useMemo(
        () => resolveDeliveryMethodCost(orderPrice, activeDeliveryMethod),
        [orderPrice, activeDeliveryMethod]
    );

    const checkoutNetTotal = useMemo(
        () => Math.max(0, orderPrice + shippingCost),
        [orderPrice, shippingCost]
    );
    const {tax: checkoutTax, message: checkoutTaxMessage} = checkoutTaxPreview(
        shopSettings.data?.id, checkoutCountryCode(deliveryCountry), Math.round(checkoutNetTotal * 100),
    );
    const checkoutTotal = checkoutTax ? checkoutTax.grossAmountOre / 100 : checkoutNetTotal;

    const selectedDeliveryLabel = activeDeliveryMethod?.name || shippingSelected || "";

    const baseOptionSelections = useMemo(
        () => normalizeOptionSelections(state?.optionSelections),
        [state?.optionSelections]
    );

    const sizeDistributionConfig = useMemo(() => {
        const raw = product?.technical_specs?.size_distribution;
        if (!raw?.enabled) return null;

        const rawFields = Array.isArray(raw.fields) ? raw.fields : [];
        const fields: SizeDistributionField[] = rawFields
            .map((field: any, index: number) => {
                if (typeof field === "string") {
                    const label = field.trim();
                    if (!label) return null;
                    return {
                        key: toSafeKey(label) || `field-${index + 1}`,
                        label,
                    };
                }

                if (field && typeof field === "object") {
                    const label = String(field.label || field.name || field.key || "").trim();
                    if (!label) return null;
                    const key = toSafeKey(String(field.key || "")) || toSafeKey(label) || `field-${index + 1}`;
                    return { key, label };
                }

                return null;
            })
            .filter(Boolean) as SizeDistributionField[];

        if (fields.length === 0) return null;

        return {
            title: String(raw.title || "Størrelsesfordeling"),
            enforceQuantityMatch: raw.enforce_quantity_match !== false,
            fields,
        };
    }, [product?.technical_specs?.size_distribution]);

    const sizeDistributionFields = sizeDistributionConfig?.fields || [];

    const nonSizeOptionSelections = useMemo(() => {
        return Object.fromEntries(
            Object.entries(baseOptionSelections).filter(([entryKey, option]) => {
                const candidateId = String(option.optionId || entryKey);
                return !candidateId.startsWith(SIZE_OPTION_PREFIX);
            })
        );
    }, [baseOptionSelections]);

    useEffect(() => {
        if (!sizeDistributionConfig) {
            setSizeDistributionValues((prev) => (Object.keys(prev).length > 0 ? {} : prev));
            return;
        }

        const allowedKeys = new Set(sizeDistributionFields.map((field) => field.key));
        setSizeDistributionValues((prev) => {
            const next: Record<string, number> = {};
            let changed = false;

            sizeDistributionFields.forEach((field) => {
                const current = Number(prev[field.key] || 0);
                next[field.key] = Number.isFinite(current) && current > 0 ? Math.floor(current) : 0;
            });

            const hasExistingValues = sizeDistributionFields.some((field) => (next[field.key] || 0) > 0);
            if (!hasExistingValues) {
                Object.entries(baseOptionSelections).forEach(([entryKey, option]) => {
                    const candidateId = String(option.optionId || entryKey);
                    if (!candidateId.startsWith(SIZE_OPTION_PREFIX)) return;
                    const fieldKey = candidateId.slice(SIZE_OPTION_PREFIX.length);
                    if (!allowedKeys.has(fieldKey)) return;
                    const parsedValue = parseSizeValueFromName(option.name);
                    if (parsedValue > 0) {
                        next[fieldKey] = parsedValue;
                    }
                });
            }

            Object.keys(prev).forEach((key) => {
                if (!allowedKeys.has(key)) changed = true;
            });

            if (!changed) {
                changed = Object.keys(next).some((key) => (prev[key] || 0) !== next[key]);
            }

            return changed ? next : prev;
        });
    }, [sizeDistributionConfig, sizeDistributionFields, baseOptionSelections]);

    const sizeDistributionEntries = useMemo(() => {
        if (!sizeDistributionConfig) return [] as Array<{ key: string; label: string; value: number }>;
        return sizeDistributionFields
            .map((field) => ({
                key: field.key,
                label: field.label,
                value: Number(sizeDistributionValues[field.key] || 0) || 0,
            }))
            .filter((entry) => entry.value > 0);
    }, [sizeDistributionConfig, sizeDistributionFields, sizeDistributionValues]);

    const sizeDistributionTotal = useMemo(
        () => sizeDistributionEntries.reduce((sum, entry) => sum + entry.value, 0),
        [sizeDistributionEntries]
    );

    const sizeDistributionMismatch = useMemo(() => {
        if (!sizeDistributionConfig?.enforceQuantityMatch) return false;
        if (!orderQuantity || orderQuantity <= 0) return false;
        return sizeDistributionTotal !== orderQuantity;
    }, [sizeDistributionConfig?.enforceQuantityMatch, orderQuantity, sizeDistributionTotal]);

    const sizeDistributionSummary = useMemo(() => {
        if (!sizeDistributionConfig || sizeDistributionEntries.length === 0) return "";
        return sizeDistributionEntries.map((entry) => `${entry.label}: ${entry.value}`).join(", ");
    }, [sizeDistributionConfig, sizeDistributionEntries]);

    const sizeDistributionOptionSelections = useMemo(() => {
        const selections: Record<string, CheckoutOptionSelection> = {};
        sizeDistributionEntries.forEach((entry) => {
            const optionId = `${SIZE_OPTION_PREFIX}${entry.key}`;
            selections[optionId] = {
                optionId,
                name: `${entry.label}: ${entry.value}`,
                extraPrice: 0,
                priceMode: "fixed",
            };
        });
        return selections;
    }, [sizeDistributionEntries]);

    const effectiveOptionSelections = useMemo(
        () => ({ ...nonSizeOptionSelections, ...sizeDistributionOptionSelections }),
        [nonSizeOptionSelections, sizeDistributionOptionSelections]
    );

    const handleSizeDistributionChange = (fieldKey: string, rawValue: string) => {
        const parsed = Number(rawValue);
        const nextValue = Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
        setSizeDistributionValues((prev) => ({
            ...prev,
            [fieldKey]: nextValue,
        }));
    };

    const handleBackToConfiguration = () => {
        const storedProductPath = getSafeInternalPath(state?.productReturnPath);
        if (storedProductPath) {
            navigate(storedProductPath, { replace: true });
            return;
        }

        const productFallbackPath = buildProductFallbackPath(state?.productSlug, locationSearchParams);
        if (productFallbackPath) {
            navigate(productFallbackPath, { replace: true });
            return;
        }

        if (window.history.length > 1) {
            navigate(-1);
            return;
        }
        navigate("/");
    };

    const buildCheckoutOrder = async () => {
        const session = readSiteCheckoutSession();
        // An old Designer export must not take precedence over a newer upload.
        const design = session?.designerExport?.fileUrl === uploadedFile?.url ? session.designerExport : null;
        const productionFiles = primaryProductionFiles(design?.productionFiles?.filter(file => file.fileUrl && file.filePath) || []);
        const sources = productionFiles.length > 0 ? productionFiles.map(file => ({
            name: String(file.name || "production.pdf"), path: String(file.filePath), sha256: String(file.sha256 || ""),
        })) : uploadedFile ? [{ name: uploadedFile.name, path: uploadedFile.path, sha256: uploadedFile.sha256 }] : [];
        if (!sources.length) throw new Error("Godkend en produktionsfil før betaling.");
        const files = await Promise.all(sources.map(async source => {
            const access = checkoutUploadAccess(source.path);
            let sha256 = source.sha256;
            if (!access) {
                const blob = await readCheckoutUpload(supabase, source.path);
                if (blob.size > MAX_CHECKOUT_UPLOAD_BYTES) throw new Error(`Trykfiler over ${CHECKOUT_UPLOAD_LIMIT_LABEL} skal aftales med butikken før betaling.`);
                sha256 = await hashCheckoutArtifact(blob);
                if (sha256 !== source.sha256) throw new Error("Trykfilen er ændret siden korrekturen. Upload og godkend den aktuelle fil igen.");
            }
            return { file_name: source.name, storage_path: source.path, bucket: "order-files", sha256,
                ...(access ? {access_token: access.access_token} : {}) };
        }));
        const billingSummary = useSeparateBillingAddress
            ? [billingName, billingCompany, deliveryAddressLines(billingAddress, billingAddress2), billingZip, billingCity, billingCountry]
            : [customerName, customerCompany, deliveryAddressLines(deliveryAddress, deliveryAddress2), deliveryZip, deliveryCity, deliveryCountry];
        return {
            customer_email: customerEmail.trim(), customer_name: customerName.trim(), customer_phone: customerPhone.trim(),
            delivery_type: selectedDeliveryLabel, delivery_address: deliveryAddress.trim(), delivery_address2: deliveryAddress2.trim(),
            delivery_zip: deliveryZip.trim(), delivery_city: deliveryCity.trim(), delivery_country: checkoutCountryCode(deliveryCountry),
            product_configuration: sizeDistributionSummary || null,
            status_note: [
                `[MODTAGER] ${deliveryRecipientName.trim()}`,
                deliveryCompany.trim() ? `[MODTAGER-FIRMA] ${deliveryCompany.trim()}` : null,
                customerCompany.trim() ? `[FIRMA] ${customerCompany.trim()}` : null,
                customerPhone.trim() ? `[TELEFON] ${customerPhone.trim()}` : null,
                `[FAKTURERING] ${billingSummary.filter(Boolean).join(", ")}`,
                senderMode === "blind" ? "[BLIND_SHIPPING] Ja" : null,
                senderMode === "custom" ? `[AFSENDER] ${senderName.trim()}` : null,
                `[PRODUKTIONSFLOW] ${design ? "Designer online" : "Godkendt tryk-PDF"}`,
                printWarningOrderNote(approvedPrintWarnings, uploadedFile?.sha256 || ""),
            ].filter(Boolean).join("\n"),
            files,
        };
    };

    const handleProceedToPayment = async () => {
        if (!productReady) { toast.error('Kontrollér produktet og butikken, før du fortsætter.'); return; }
        if (draftFlow) { toast.info(DRAFT_FLOW_MESSAGE); return; }
        if (PREVIEW_PAYMENT_DISABLED) { toast.info(PREVIEW_PAYMENT_MESSAGE); return; }
        if (finalizingPaymentRef.current) return;
        if (checkoutTaxMessage || !checkoutTax) { toast.error(checkoutTaxMessage || 'Moms kunne ikke bekræftes.'); return; }
        if (sizeDistributionMismatch) { toast.error(`Størrelsesfordeling skal summere til ${orderQuantity} stk.`); return; }
        if (!proofArtifactApproved || uploading || platformPreflightLoading) {
            toast.error("Godkend den aktuelle produktionsfil før betaling."); setProofingOpen(true); return;
        }
        if (missingCheckoutContactFields({ customerEmail, customerName, deliveryRecipientName, deliveryAddress, deliveryZip, deliveryCity }).length) {
            toast.error("Udfyld kunde- og leveringsoplysninger før betaling."); return;
        }
        if (!checkoutCountryCode(deliveryCountry) || (useSeparateBillingAddress && !checkoutCountryCode(billingCountry))) {
            toast.error("Angiv en landekode på to bogstaver, fx DK eller SE."); return;
        }
        if (useSeparateBillingAddress && (!billingName.trim() || !billingAddress.trim() || !billingZip.trim() || !billingCity.trim())) {
            toast.error("Udfyld faktureringsadresse før betaling."); return;
        }
        const tenantId = shopSettings.data?.id;
        if (!tenantId) { toast.error("Kunne ikke finde shop-id til betaling."); return; }
        setPaymentLoading(true);
        try {
            const optionIds = Object.values(nonSizeOptionSelections).map(option => option.optionId)
                .filter(id => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(id || "")));
            const checkoutQuote = state?.pricingQuote ? { ...state.pricingQuote,
                productId: state.pricingQuote.productId || state?.productId || null,
                productSlug: state.pricingQuote.productSlug || state?.productSlug || null,
                quantity: orderQuantity, optionIds, shippingSelected,
                pricingModel: state?.pricingModel || state.pricingQuote.pricingModel,
            } : null;
            if (checkoutQuote) delete checkoutQuote.quantityTiers;
            if (!checkoutQuote) throw new Error("Gå tilbage til produktet og vælg prisen igen.");
            const order = await buildCheckoutOrder();
            const body = { contract_version: 2, tenant_id: tenantId, amount_ore: Math.round(checkoutTotal * 100), currency: "dkk", checkout_quote: checkoutQuote, checkout_order: order };
            const payloadHash = await hashCheckoutArtifact(new Blob([JSON.stringify(body)]));
            const storedRecovery = readCheckoutRecovery(localStorage, tenantId);
            const previous = storedRecovery?.completed && storedRecovery.checkoutInstanceId !== checkoutInstanceId ? null : storedRecovery;
            if (previous?.completed) { await handlePaymentSuccess(previous.paymentIntentId); return; }
            if (previous && previous.payloadHash !== payloadHash) {
                setRecoverablePaymentId(previous.paymentIntentId || null);
                throw new Error("Der findes en påbegyndt betaling for andre oplysninger. Afslut eller annuller den nedenfor, før du starter en ny.");
            }
            const recovery = previous || { tenantId, attemptId: crypto.randomUUID(), accessToken: crypto.randomUUID(), payloadHash, checkoutInstanceId,
                companyOrderRequestId: readSiteCheckoutSession()?.companyOrderRequestId || undefined };
            // Persist recovery before invoking Stripe, including when the response gets lost.
            saveCheckoutRecovery(localStorage, recovery);
            setHasCheckoutRecovery(true);
            try { await saveCheckoutAddress(); } catch { toast.error("Adressen kunne ikke gemmes i adressebogen."); }
            const { data, error } = await supabase.functions.invoke("stripe-create-payment-intent", {
                body: { ...body, checkout_attempt_id: recovery.attemptId, checkout_access_token: recovery.accessToken },
            });
            if (error) throw new Error(await checkoutStartMessage(error));
            requireCheckoutV2Response(data, recovery.attemptId);
            saveCheckoutRecovery(localStorage, { ...recovery, paymentIntentId: data.payment_intent_id });
            setRecoverablePaymentId(data.payment_intent_id);
            setPaymentClientSecret(data.client_secret);
            setPaymentConnectedAccountId(data.connected ? tenantPaymentStatus?.stripe_account_id || null : null);
            setShowPaymentModal(true);
            setOrderPersistWarning(null);
        } catch (error: any) {
            setOrderPersistWarning(error?.message || "Betaling kunne ikke oprettes.");
            toast.error(error?.message || "Betaling kunne ikke oprettes.");
        } finally { setPaymentLoading(false); }
    };

    const saveCheckoutAddress = async () => {
        if (!saveAddressForLater || !checkoutUserId) return;
        const { data: { user } } = await supabase.auth.getUser();
        if (user?.id !== checkoutUserId) return;
        const recipient = splitFullName(deliveryRecipientName.trim());
        const payload = { user_id: user.id, label: addressLabel.trim() || null, company_name: deliveryCompany.trim() || null,
            first_name: recipient.firstName, last_name: recipient.lastName, street_address: deliveryAddress.trim(),
            street_address_2: deliveryAddress2.trim() || null, postal_code: deliveryZip.trim(), city: deliveryCity.trim(),
            country: deliveryCountry.trim(), phone: customerPhone.trim() || null, is_default: savedAddresses.length === 0 };
        const query = selectedSavedAddressId && selectedSavedAddressId !== "new"
            ? supabase.from("customer_addresses").update(payload).eq("id", selectedSavedAddressId).eq("user_id", user.id)
            : supabase.from("customer_addresses").insert(payload);
        const { data, error } = await query.select("id").single();
        if (error || !(data as any)?.id) toast.error("Adressen kunne ikke gemmes i adressebogen.");
    };

    const handlePaymentSuccess = async (paymentIntentId?: string) => {
        if (draftFlow) { toast.info(DRAFT_FLOW_MESSAGE); return; }
        const tenantId = shopSettings.data?.id;
        if (!tenantId || finalizingPaymentRef.current) return;
        finalizingPaymentRef.current = true; setFinalizingPayment(true); setShowPaymentModal(false);
        setOrderPersistWarning(null);
        try {
            const recovery = readCheckoutRecovery(localStorage, tenantId);
            if (!recovery) throw new Error("Betalingsreferencen mangler. Kontakt butikken før en ny betaling.");
            const intentId = paymentIntentId || recovery.paymentIntentId;
            if (paymentIntentId && recovery.paymentIntentId && paymentIntentId !== recovery.paymentIntentId) {
                throw new Error("Betalingsreferencen matcher ikke denne bestilling.");
            }
            const { data, error } = await supabase.functions.invoke("stripe-finalize-checkout", { body: {
                checkout_attempt_id: recovery.attemptId, checkout_access_token: recovery.accessToken, payment_intent_id: intentId,
            } });
            if (error || data?.contract_version !== 2 || data?.success !== true || !data?.order?.id || !data?.order?.order_number) {
                throw new Error("Betaling og ordre er endnu ikke bekræftet samlet. Prøv at kontrollere igen. Betal ikke igen.");
            }
            setCreatedOrderNumber(data.order.order_number);
            if (!data.order.checkout_receipt || !Number.isFinite(data.order.checkout_receipt.total)) {
                throw new Error("Ordrekvitteringen kunne ikke indlæses. Kontrollér ordren igen.");
            }
            setConfirmedReceipt(data.order.checkout_receipt);
            const notificationNotice = checkoutNotificationNotice(data.order.checkout_notification);
            setOrderNotificationWarning(notificationNotice.warning ? notificationNotice.message : null);
            setOrderSuccessMessage(`Din betaling, ordre og produktionsfil er gemt. ${notificationNotice.warning ? "Gem dit ordrenummer ved spørgsmål." : notificationNotice.message}`);
            setPaymentSuccess(true); setPaymentClientSecret(null); setRecoverablePaymentId(null); setHasCheckoutRecovery(false);
            clearStripeReturnParams();
            try { saveCheckoutRecovery(localStorage, { ...recovery, completed: true, checkoutInstanceId }); } catch { /* Keep the original attempt recoverable if local persistence fails. */ }
            toast.success("Din ordre er modtaget!");
            if (recovery.companyOrderRequestId) {
                void linkCompanyOrder(supabase, recovery.companyOrderRequestId, data.order.id)
                    .catch(() => setOrderNotificationWarning("Ordren er gemt. Butikken skal kontrollere forbindelsen til virksomhedens bestilling."));
            }
            if (data.order.checkout_context?.podV2 === true) {
                void supabase.functions.invoke("pod2-create-jobs", { body: { orderId: data.order.id,
                    checkout_attempt_id: recovery.attemptId, checkout_access_token: recovery.accessToken } })
                    .then(({ error }) => { if (error) setOrderNotificationWarning("Ordren er gemt. Butikken skal kontrollere overførslen til produktion."); })
                    .catch(() => setOrderNotificationWarning("Ordren er gemt. Butikken skal kontrollere overførslen til produktion."));
            }
        } catch (error: any) {
            const message = error?.message || "Ordren kunne ikke bekræftes. Betal ikke igen.";
            setOrderPersistWarning(message); toast.error(message);
        } finally { finalizingPaymentRef.current = false; setFinalizingPayment(false); }
    };

    const cancelPendingPayment = async () => {
        if (draftFlow) { toast.info(DRAFT_FLOW_MESSAGE); return; }
        const tenantId = shopSettings.data?.id;
        if (!tenantId || finalizingPaymentRef.current) return;
        setPaymentLoading(true);
        try {
            const recovery = readCheckoutRecovery(localStorage, tenantId);
            if (!recovery) { setOrderPersistWarning(null); return; }
            const { data, error } = await supabase.functions.invoke("stripe-finalize-checkout", { body: {
                action: "cancel", checkout_attempt_id: recovery.attemptId, checkout_access_token: recovery.accessToken,
                payment_intent_id: recovery.paymentIntentId,
            } });
            if (!error && data?.success === true) {
                await handlePaymentSuccess(recovery.paymentIntentId);
                return;
            }
            if (error || data?.contract_version !== 2 || data?.cancelled !== true || data?.checkout_attempt_id !== recovery.attemptId) throw new Error("Betalingen kunne ikke annulleres sikkert. Kontrollér ordren eller kontakt butikken.");
            clearCheckoutRecovery(localStorage, tenantId);
            setRecoverablePaymentId(null); setHasCheckoutRecovery(false); setPaymentClientSecret(null); setShowPaymentModal(false); setOrderPersistWarning(null);
            toast.info("Den påbegyndte betaling er annulleret. Du kan nu ændre bestillingen.");
        } catch (error: any) { setOrderPersistWarning(error?.message); toast.error(error?.message); }
        finally { setPaymentLoading(false); }
    };
    const handlePaymentCancel = () => { setShowPaymentModal(false); };

    useEffect(() => {
        const tenantId = shopSettings.data?.id;
        if (!tenantId || draftFlow || tenantConflict) return;
        try {
            const stored = readCheckoutRecovery(localStorage, tenantId);
            const recovery = stored?.completed && stored.checkoutInstanceId !== checkoutInstanceId ? null : stored;
            setHasCheckoutRecovery(Boolean(recovery));
            setRecoverablePaymentId(recovery?.paymentIntentId || null);
            if (recovery?.completed) void handlePaymentSuccess(recovery.paymentIntentId);
        }
        catch (error: any) { setOrderPersistWarning(error.message); }
    }, [shopSettings.data?.id, checkoutInstanceId, draftFlow, tenantConflict]);

    useEffect(() => {
        if (draftFlow || tenantConflict || !returnedPaymentIntentId || !shopSettings.data?.id) return;
        if (processedRedirectPaymentIntentRef.current === returnedPaymentIntentId) return;
        processedRedirectPaymentIntentRef.current = returnedPaymentIntentId;
        // URL redirect_status is an untrusted hint. The server verifies Stripe.
        void handlePaymentSuccess(returnedPaymentIntentId);
    }, [returnedPaymentIntentId, shopSettings.data?.id, draftFlow, tenantConflict]);

    // Resolve specs: prefer explicit width/height from state or query, then standard formats, then product metadata
    const getResolvedSpecs = (): TechnicalSpecs | null => {
        const bleedDefault = 3;
        const explicitWidthMm = parsePositiveNumber(state?.designWidthMm) ?? parsePositiveNumber(locationSearchParams.get("widthMm"));
        const explicitHeightMm = parsePositiveNumber(state?.designHeightMm) ?? parsePositiveNumber(locationSearchParams.get("heightMm"));
        const explicitBleedMm = parsePositiveNumber(state?.designBleedMm) ?? parsePositiveNumber(locationSearchParams.get("bleedMm")) ?? bleedDefault;
        const explicitSafeAreaMm = parseNonNegativeNumber(state?.designSafeAreaMm) ?? parseNonNegativeNumber(locationSearchParams.get("safeMm")) ?? parseNonNegativeNumber(product?.technical_specs?.safe_area_mm) ?? 3;

        if (explicitWidthMm && explicitHeightMm) {
            return {
                width_mm: explicitWidthMm,
                height_mm: explicitHeightMm,
                bleed_mm: explicitBleedMm,
                min_dpi: 300,
                safe_area_mm: explicitSafeAreaMm,
            };
        }

        const normalizedFormat = normalizeFormatKey(state?.selectedFormat || locationSearchParams.get("format"));
        if (normalizedFormat && STANDARD_SPECS[normalizedFormat]) {
            const std = STANDARD_SPECS[normalizedFormat];
            return { ...std, bleed_mm: bleedDefault };
        }
        if (product?.technical_specs?.width_mm && product?.technical_specs?.height_mm) {
            return {
                ...(product.technical_specs as TechnicalSpecs),
                bleed_mm: parsePositiveNumber((product.technical_specs as any).bleed_mm) ?? bleedDefault,
                safe_area_mm: parseNonNegativeNumber((product.technical_specs as any).safe_area_mm) ?? 3,
                min_dpi: parsePositiveNumber((product.technical_specs as any).min_dpi) ?? 300,
            };
        }
        // Very fallback for common products if nothing found
        return null;
    };

    const isPodProduct = Boolean(product?.technical_specs?.is_pod || product?.technical_specs?.is_pod_v2);
    const isPodV2Product = Boolean(product?.technical_specs?.is_pod_v2);
    const podPreflightEnabled = Boolean(product?.technical_specs?.pod_preflight_enabled) && isPodV2Product;
    // Only products that actually need a cut contour (stickers, die-cut shapes, etc.)
    // should surface CutContour status/warnings in the upload previews. Admin opts in
    // via `technical_specs.requires_cut_contour` in ProductPriceManager.
    const requiresCutContour = Boolean((product?.technical_specs as any)?.requires_cut_contour);
    const checkoutFlowNotice = getCheckoutFlowNotice(
        activeDesignerMode,
        productFlowLabel,
        requiresCutContour,
        professionalPdfUploadOnly,
        checkoutTemplateArtworkModeReasonDa,
    );
    const podPreflightAutoFix = (product?.technical_specs as any)?.pod_preflight_auto_fix ?? true;
    // NOTE: We used to gate checkout on the server-side preflight result, but per
    // product direction we now keep that preflight silent (background autoFix only)
    // and rely entirely on our local preflight for customer-visible gating.

    const resolvedSpecs = getResolvedSpecs();
    const recommendedDpi = recommendedPrintDpi({
        designerMode: activeDesignerMode, pricingModel: state.pricingModel,
        pricingType: product?.pricing_type, category: product?.category,
        widthMm: resolvedSpecs?.width_mm || 0, heightMm: resolvedSpecs?.height_mm || 0,
    });
    const resolvedWidthMm = resolvedSpecs?.width_mm;
    const resolvedHeightMm = resolvedSpecs?.height_mm;
    const resolvedBleedMm = resolvedSpecs?.bleed_mm;
    const resolvedSafeAreaMm = resolvedSpecs?.safe_area_mm;
    const specs = useMemo(() => resolvedWidthMm && resolvedHeightMm ? {
        width_mm: resolvedWidthMm, height_mm: resolvedHeightMm, bleed_mm: resolvedBleedMm || 0,
        safe_area_mm: resolvedSafeAreaMm, min_dpi: recommendedDpi,
    } : null, [resolvedWidthMm, resolvedHeightMm, resolvedBleedMm, resolvedSafeAreaMm, recommendedDpi]);
    const displayProductName = product?.name || state?.productName || "Produkt";
    const resolvedFormatLabel = useMemo(
        () => getReadableFormatLabel(
            checkoutTemplateFormatLabel(
                state?.pricingQuote?.formatId || state?.selectedFormat || locationSearchParams.get("format"),
                checkoutTemplatePdfSha256,
                product?.template_files as ProductTemplateFile[] | undefined,
            ) || state?.selectedFormat || locationSearchParams.get("format"),
            specs,
        ),
        [state?.selectedFormat, state?.pricingQuote?.formatId, locationSearchParams, specs, checkoutTemplatePdfSha256, product?.template_files]
    );
    const checkoutTemplateSelectionLabels = useMemo(() => {
        const quotedLabels = Array.isArray(state?.pricingQuote?.variantDisplayLabels)
            ? state.pricingQuote.variantDisplayLabels
            : [];
        const summaryLabels = String(state?.summary || "")
            .split("•")
            .map((label) => label.trim())
            .filter(Boolean);

        return Array.from(new Set([...quotedLabels, ...summaryLabels]));
    }, [state?.pricingQuote?.variantDisplayLabels, state?.summary]);
    const availableTemplateFiles = useMemo<TemplateFile[]>(() => {
        const byUrl = new Map<string, TemplateFile>();

        if (checkoutTemplatePdfUrl) {
            byUrl.set(checkoutTemplatePdfUrl, {
                name: checkoutTemplatePdfName,
                url: checkoutTemplatePdfUrl,
                path: "",
                format: resolvedFormatLabel || "Valgt format",
                uploadedAt: state?.templateDownloadedAt || "",
            });
        }

        const productTemplates = Array.isArray(product?.template_files)
            ? product.template_files as TemplateFile[]
            : [];
        productTemplates.forEach((template: TemplateFile) => {
            if (!template?.url || byUrl.has(template.url)) return;
            if (!templateMatchesSelectedConfiguration(
                template,
                state?.selectedFormat,
                resolvedFormatLabel,
                checkoutTemplateSelectionLabels,
            )) return;
            byUrl.set(template.url, template);
        });

        return Array.from(byUrl.values());
    }, [
        checkoutTemplatePdfName,
        checkoutTemplatePdfUrl,
        checkoutTemplateSelectionLabels,
        product?.template_files,
        resolvedFormatLabel,
        state?.selectedFormat,
        state?.templateDownloadedAt,
    ]);
    const targetWidth = specs ? specs.width_mm + (specs.bleed_mm * 2) : 0;
    const targetHeight = specs ? specs.height_mm + (specs.bleed_mm * 2) : 0;
    const folderMockupDefinition = resolveFolderDefinition(checkoutTemplatePdfSha256, targetWidth, targetHeight);
    const verifiedPrintModel = useApprovedPrintModel({ pdfUrl: checkoutTemplatePdfUrl, templatePdfSha256: checkoutTemplatePdfSha256 });
    const approvedPrintModel = resolveApprovedPrintModel(verifiedPrintModel?.definition.templateHash, targetWidth, targetHeight);

    const safeAreaMm = specs?.safe_area_mm ?? 3;
    const checkoutFormatGuideData = useMemo<ProductFormatGuideData | null>(() => {
        if (!specs || specs.width_mm <= 0 || specs.height_mm <= 0) return null;

        const selectionText = [displayProductName, state?.summary, ...checkoutTemplateSelectionLabels]
            .filter(Boolean)
            .join(" ")
            .toLocaleLowerCase("da-DK");
        const layoutKind = state?.designerMode === 'brochure' ? 'brochure' : /(folder|foldetype|falset|rullefals|zigzag)/.test(selectionText)
            ? "folded"
            : "flat";
        const printSideLabel = checkoutTemplateSelectionLabels.find((label) => (
            /4\+0|4\+4|en side|begge sider|enkeltsidet|dobbeltsidet/i.test(label)
        )) || null;
        const selectedTemplate = availableTemplateFiles[0] || null;
        const foldedFormatKey = layoutKind === "folded"
            ? [resolvedFormatLabel, ...checkoutTemplateSelectionLabels]
                .map((label) => normalizeFormatKey(label))
                .find((key) => Boolean(key && STANDARD_SPECS[key]))
            : null;
        const foldedFinishedSpecs = foldedFormatKey ? STANDARD_SPECS[foldedFormatKey] : null;
        const templateDataWidthMm = parsePositiveNumber(selectedTemplate?.widthMm ?? selectedTemplate?.width_mm);
        const templateDataHeightMm = parsePositiveNumber(selectedTemplate?.heightMm ?? selectedTemplate?.height_mm);
        const orientationLabel = checkoutTemplateSelectionLabels.find((label) => /^(lodret|vandret)$/i.test(label)) || null;
        const foldTypeLabel = checkoutTemplateSelectionLabels.find((label) => /rullefalset|zigzag/i.test(label)) || null;
        const pageCountLabel = checkoutTemplateSelectionLabels.find((label) => /\d+\s*sider/i.test(label)) || null;
        const swapFinishedDimensions = layoutKind === "folded"
            && /vandret/i.test(orientationLabel || "")
            && (foldedFinishedSpecs?.width_mm ?? specs.width_mm) !== (foldedFinishedSpecs?.height_mm ?? specs.height_mm);
        const baseFinishedWidthMm = foldedFinishedSpecs?.width_mm ?? specs.width_mm;
        const baseFinishedHeightMm = foldedFinishedSpecs?.height_mm ?? specs.height_mm;

        return {
            productName: displayProductName,
            productImageUrl: product?.image_url || null,
            formatLabel: resolvedFormatLabel,
            finishedWidthMm: swapFinishedDimensions ? baseFinishedHeightMm : baseFinishedWidthMm,
            finishedHeightMm: swapFinishedDimensions ? baseFinishedWidthMm : baseFinishedHeightMm,
            dataWidthMm: layoutKind === "folded" ? (templateDataWidthMm ?? specs.width_mm) : undefined,
            dataHeightMm: layoutKind === "folded" ? (templateDataHeightMm ?? specs.height_mm) : undefined,
            bleedMm: specs.bleed_mm,
            safeAreaMm,
            minDpi: specs.min_dpi,
            layoutKind,
            brochurePageCount: state?.brochurePageCount,
            printSideLabel,
            foldTypeLabel,
            pageCountLabel,
            foldGeometry: selectedTemplate?.guideGeometry || selectedTemplate?.guide_geometry,
            template: selectedTemplate?.url
                ? {
                    name: selectedTemplate.name,
                    url: selectedTemplate.url,
                }
                : null,
        };
    }, [
        availableTemplateFiles,
        checkoutTemplateSelectionLabels,
        displayProductName,
        product?.image_url,
        resolvedFormatLabel,
        safeAreaMm,
        specs,
        state?.summary,
        state?.designerMode,
        state?.brochurePageCount,
    ]);

    const bleedXPercent = specs ? (specs.bleed_mm / targetWidth) * 100 : 0;
    const bleedYPercent = specs ? (specs.bleed_mm / targetHeight) * 100 : 0;
    const safeXPercent = specs ? ((specs.bleed_mm + safeAreaMm) / targetWidth) * 100 : 0;
    const safeYPercent = specs ? ((specs.bleed_mm + safeAreaMm) / targetHeight) * 100 : 0;
    const proofingScaleFactor = proofingScale / 100;
    const proofingMinScale = PROOFING_MIN_SCALE;
    const proofingMaxScale = useMemo(() => {
        if (!proofingPreview || targetWidth <= 0 || targetHeight <= 0) return 220;

        const widthFillScale = proofingPreview.physicalWidthMm > 0
            ? (targetWidth / proofingPreview.physicalWidthMm) * 100
            : 100;
        const heightFillScale = proofingPreview.physicalHeightMm > 0
            ? (targetHeight / proofingPreview.physicalHeightMm) * 100
            : 100;
        const requiredFillScale = Math.max(widthFillScale, heightFillScale);

        return clamp(Math.ceil(requiredFillScale * 1.8), 220, 3000);
    }, [proofingPreview, targetWidth, targetHeight]);
    const proofingEffectiveDpi = useMemo(() => {
        if (proofingPreview?.fileType !== "image") return null;
        return placedImageDpi({ widthPx: proofingPreview.sourceWidthPx, heightPx: proofingPreview.sourceHeightPx,
            widthMm: proofingPreview.physicalWidthMm, heightMm: proofingPreview.physicalHeightMm, scalePercent: proofingScale });
    }, [proofingPreview, proofingScale]);
    const lowResolutionWarning = resolutionWarning(proofingEffectiveDpi, recommendedDpi);
    const proofingBaseWidthPercent = proofingPreview && targetWidth > 0
        ? (proofingPreview.physicalWidthMm / targetWidth) * 100
        : 100;
    const proofingBaseHeightPercent = proofingPreview && targetHeight > 0
        ? (proofingPreview.physicalHeightMm / targetHeight) * 100
        : 100;
    const proofingDisplayedWidthPercent = proofingBaseWidthPercent * proofingScaleFactor;
    const proofingDisplayedHeightPercent = proofingBaseHeightPercent * proofingScaleFactor;
    const proofingArtworkBounds = proofingPreview
        ? {
            left: 50 + proofingOffset.x - (proofingDisplayedWidthPercent / 2),
            right: 50 + proofingOffset.x + (proofingDisplayedWidthPercent / 2),
            top: 50 + proofingOffset.y - (proofingDisplayedHeightPercent / 2),
            bottom: 50 + proofingOffset.y + (proofingDisplayedHeightPercent / 2),
        }
        : null;
    const proofingTrimBounds = {
        left: bleedXPercent,
        right: 100 - bleedXPercent,
        top: bleedYPercent,
        bottom: 100 - bleedYPercent,
    };
    const proofingArtworkOutsideArtboard = Boolean(
        proofingArtworkBounds
        && (
            proofingArtworkBounds.left < 0
            || proofingArtworkBounds.right > 100
            || proofingArtworkBounds.top < 0
            || proofingArtworkBounds.bottom > 100
        )
    );
    const proofingPlacementIssues = proofingPreview
        ? [
            ...(lowResolutionWarning ? [lowResolutionWarning] : []),
            ...(proofingArtworkOutsideArtboard ? ["Motivet rækker uden for trykfladen. De dele, der ligger udenfor, bliver beskåret. Det kan være tilsigtet ved tryk til kant og CutContour. Du kan godkende den viste placering på eget ansvar."] : []),
        ]
        : [];
    // Only show issues from our own local preflight — CMYK/RGB, dimensions,
    // resolution, corruption. The server-side Print.com check runs silently
    // in the background for its auto-fix capability only; its findings are
    // never surfaced to customers directly.
    const originalFilePrimaryIssue = preflightResults?.issues?.[0] || null;
    const proofingPlacementPrimaryIssue = proofingPlacementIssues[0] || null;
    const activeDesignerProductionFile = Boolean(
        uploadedFile?.url
        && persistedDesignerExport?.fileUrl
        && uploadedFile.url === persistedDesignerExport.fileUrl
    );
    const currentProofArtifact = proofingPreview && uploadedFile ? {
        fileUrl: uploadedFile.url, filePath: uploadedFile.path, sha256: uploadedFile.sha256, fileType: proofingPreview.fileType,
        designerExport: persistedDesignerExport?.fileUrl === uploadedFile.url,
        physicalWidthMm: proofingPreview.physicalWidthMm, physicalHeightMm: proofingPreview.physicalHeightMm,
        targetWidthMm: targetWidth, targetHeightMm: targetHeight,
        scale: proofingScale, offsetX: proofingOffset.x, offsetY: proofingOffset.y,
    } : null;
    const proofNeedsExport = !currentProofArtifact || requiresProofExport(currentProofArtifact);
    const currentProofIdentity = currentProofArtifact ? proofArtifactFingerprint(currentProofArtifact) : null;
    const designerPrintWarnings = activeDesignerProductionFile ? persistedDesignerExport?.printWarnings || [] : [];
    const proofArtifactApproved = proofingApproved && !proofNeedsExport && (!designerPrintWarnings.length || approvedProofIdentity === currentProofIdentity) && (
        approvedProofIdentity === currentProofIdentity
        || (approvedProofIdentity === null && currentProofArtifact?.designerExport === true)
    );
    const proofingApprovalPending = !proofArtifactApproved;
    const proofingDpiWarning = Boolean(proofingEffectiveDpi && specs?.min_dpi && proofingEffectiveDpi < specs.min_dpi);
    const proofingPhysicalMismatch = false;
    const proofAvailability = getCheckoutProofAvailability({
        hasFile: Boolean(uploadedFile?.url),
        hasPreview: Boolean(proofingPreview),
        processing: uploading || platformPreflightLoading || exportingProof,
        approved: proofArtifactApproved,
        hasLocalCheck: preflightResults !== null,
        designerExport: activeDesignerProductionFile,
        hasIssues: Boolean(originalFilePrimaryIssue || proofingPlacementPrimaryIssue || designerPrintWarnings.length),
        needsExport: proofNeedsExport,
    });
    latestProofIdentityRef.current = currentProofIdentity;
    const canExportImageHere = Boolean(currentProofArtifact?.fileType === 'image'
        && /\.(png|jpe?g)$/i.test(uploadedFile?.name || '') && !professionalPdfUploadOnly
        && !requiresCutContour && activeDesignerMode !== 'apparel');
    const canApproveHere = proofAvailability.canReview && (!proofNeedsExport || canExportImageHere);
    const retainedPrintWarnings = approvedPrintWarnings?.fileSha256 === uploadedFile?.sha256
        && proofingPreview?.fileType === 'pdf' && !proofNeedsExport ? approvedPrintWarnings : null;
    const outsideProofIssues = [...new Set([
        ...(preflightResults?.issues || []), ...proofingPlacementIssues, ...designerPrintWarnings, ...(retainedPrintWarnings?.warnings || []),
        ...(canExportImageHere ? [PDF_COLOUR_REVIEW_NOTICE] : []),
        ...(!preflightResults && !activeDesignerProductionFile ? ['Kontrollér billedet omhyggeligt. Filens automatiske tjek er ikke tilgængeligt i denne session.'] : []),
    ])];
    const printWarningKey = printWarningAcceptanceKey(currentProofIdentity, outsideProofIssues, recommendedDpi);
    const printWarningsAccepted = !outsideProofIssues.length || acceptedPrintWarningKey === printWarningKey;
    const printAcknowledgementLabel = lowResolutionWarning || proofingArtworkOutsideArtboard || designerPrintWarnings.length
        || retainedPrintWarnings?.acknowledgement === PRINT_QUALITY_RESPONSIBILITY
        ? PRINT_QUALITY_RESPONSIBILITY : GENERAL_PROOF_ACKNOWLEDGEMENT;
    const acceptPrintWarnings = (accepted: boolean) => setAcceptedPrintWarningKey(accepted ? printWarningKey : "");
    const makePrintWarningApproval = (sha256: string): PrintWarningApproval | null => outsideProofIssues.length ? {
        version: 1, fileSha256: sha256, approvedAt: new Date().toISOString(), warnings: outsideProofIssues,
        acknowledgement: printAcknowledgementLabel, recommendedDpi, effectiveDpi: proofingEffectiveDpi ?? retainedPrintWarnings?.effectiveDpi ?? null,
    } : null;
    const proofingRequiresModalReview = proofAvailability.requiresModalReview;
    const quickApproveAvailable = proofAvailability.quickApproveAvailable;
    const proofingFileKindLabel = activeDesignerProductionFile
        ? "Designer-PDF"
        : proofingPreview?.fileType === "image"
            ? "Rasterfil"
            : "PDF / vektor";
    const proofingApprovalLabel = proofArtifactApproved ? "Godkendt" : "Afventer godkendelse";

    useEffect(() => {
        if (!proofingDragging && !proofingResizing) return;

        const handlePointerMove = (event: MouseEvent) => {
            if (proofingDragging) {
                const start = proofingDragStartRef.current;
                if (!start) return;
                const artboardRect = proofingArtboardRef.current?.getBoundingClientRect();
                if (!artboardRect) return;
                const rawOffset = {
                    x: start.startX + (((event.clientX - start.x) / artboardRect.width) * 100),
                    y: start.startY + (((event.clientY - start.y) / artboardRect.height) * 100),
                };
                setProofingOffset(
                    clampProofingOffset(
                        rawOffset,
                        proofingDisplayedWidthPercent,
                        proofingDisplayedHeightPercent
                    )
                );
                return;
            }

            if (proofingResizing) {
                const start = proofingResizeStartRef.current;
                if (!start) return;
                const currentDistance = Math.max(
                    1,
                    Math.hypot(event.clientX - start.centerX, event.clientY - start.centerY)
                );
                setProofingScale(clamp(start.startScale * (currentDistance / start.startDistance), proofingMinScale, proofingMaxScale));
            }
        };

        const handlePointerUp = () => {
            setProofingDragging(false);
            setProofingResizing(false);
            proofingDragStartRef.current = null;
            proofingResizeStartRef.current = null;
        };

        window.addEventListener("mousemove", handlePointerMove);
        window.addEventListener("mouseup", handlePointerUp);
        return () => {
            window.removeEventListener("mousemove", handlePointerMove);
            window.removeEventListener("mouseup", handlePointerUp);
        };
    }, [
        proofingDragging,
        proofingResizing,
        proofingMinScale,
        proofingMaxScale,
        proofingDisplayedWidthPercent,
        proofingDisplayedHeightPercent,
    ]);

    useEffect(() => {
        if (!hasCheckoutState || !productReady) return;
        const existingSession = readSiteCheckoutSession();
        writeSiteCheckoutSession({
            ...existingSession,
            ...state,
            checkoutInstanceId,
            checkoutTenantId,
            proofApprovalRequired: !proofArtifactApproved,
            printWarningApproval: proofArtifactApproved ? approvedPrintWarnings : null,
            quantity: orderQuantity,
            productPrice: orderPrice,
            // Existing session totalPrice is net; keep that contract on reload
            // so VAT cannot become part of the next product subtotal.
            totalPrice: checkoutNetTotal,
            shippingCost,
            shippingSelected,
            selectedFormat: resolvedFormatLabel,
            designWidthMm: specs?.width_mm || null,
            designHeightMm: specs?.height_mm || null,
            designBleedMm: specs?.bleed_mm || null,
            designSafeAreaMm: safeAreaMm ?? null,
            designerExport: uploadedFile?.url === existingSession?.designerExport?.fileUrl ? existingSession?.designerExport || null : null,
            siteUpload: uploadedFile ? {
                name: uploadedFile.name,
                mimeType: uploadedFile.name.includes(".")
                    ? uploadedFile.name.split(".").pop()?.toLowerCase() === "pdf"
                        ? "application/pdf"
                        : uploadedFile.name.toLowerCase().endsWith(".png")
                            ? "image/png"
                            : uploadedFile.name.toLowerCase().endsWith(".jpg") || uploadedFile.name.toLowerCase().endsWith(".jpeg")
                                ? "image/jpeg"
                                : null
                    : null,
                fileUrl: uploadedFile.url,
                filePath: uploadedFile.path,
                sha256: uploadedFile.sha256,
                widthPx: proofingPreview?.sourceWidthPx || preflightResults?.width_px || null,
                heightPx: proofingPreview?.sourceHeightPx || preflightResults?.height_px || null,
                physicalWidthMm: proofingPreview?.physicalWidthMm || null,
                physicalHeightMm: proofingPreview?.physicalHeightMm || null,
                estimatedDpi: preflightResults?.dpi || null,
                sourceDpi: preflightResults?.dpi || null,
                previewDataUrl: proofingPreview?.previewUrl || previewUrl || null,
                proofingScalePercent: proofingScale,
                proofingOffsetXPercent: proofingOffset.x,
                proofingOffsetYPercent: proofingOffset.y,
            } : null,
            checkoutCustomer: {
                selectedCustomerProfileId,
                customerEmail,
                customerName,
                customerPhone,
                customerCompany,
                deliveryRecipientName,
                deliveryCompany,
                deliveryAddress,
                deliveryAddress2,
                deliveryCountry,
                deliveryZip,
                deliveryCity,
                selectedSavedAddressId,
                saveAddressForLater,
                addressLabel,
                senderMode,
                senderName,
                useSeparateBillingAddress,
                billingName,
                billingCompany,
                billingAddress,
                billingAddress2,
                billingCountry,
                billingZip,
                billingCity,
            },
            createdAt: new Date().toISOString(),
        });
    }, [
        state,
        hasCheckoutState,
        productReady,
        checkoutTenantId,
        proofArtifactApproved,
        approvedPrintWarnings,
        orderQuantity,
        orderPrice,
        checkoutNetTotal,
        shippingCost,
        shippingSelected,
        uploadedFile,
        proofingPreview,
        preflightResults,
        previewUrl,
        specs?.width_mm,
        specs?.height_mm,
        specs?.bleed_mm,
        customerEmail,
        customerName,
        customerPhone,
        customerCompany,
        selectedCustomerProfileId,
        deliveryRecipientName,
        deliveryCompany,
        deliveryAddress,
        deliveryAddress2,
        deliveryCountry,
        deliveryZip,
        deliveryCity,
        selectedSavedAddressId,
        saveAddressForLater,
        addressLabel,
        senderMode,
        senderName,
        useSeparateBillingAddress,
        billingName,
        billingCompany,
        billingAddress,
        billingAddress2,
        billingCountry,
        billingZip,
        billingCity,
    ]);

    // If no state, redirect back to home or a generic products page
    useEffect(() => {
        if (!hasCheckoutState) {
            console.warn("No state found in FileUploadConfiguration, redirecting...");
            navigate("/");
            return;
        }

        let cancelled = false;
        setLoading(true);
        setProduct(null);
        setProductError(null);
        if (draftAccessLoading) return;
        if (draftFlow && !allowUnpublished) {
            setProductError('Log ind som administrator for at afprøve en kladde. Din gemte bestilling er bevaret.');
            setLoading(false);
            return;
        }
        if (!checkoutTenantId || tenantConflict) {
            setProductError(tenantConflict ? 'Denne bestilling tilhører en anden butik. Din gemte bestilling er bevaret.' : 'Butikken kunne ikke bekræftes.');
            setLoading(false);
            return;
        }

        const fetchProductData = async () => {
            console.log("Fetching product data for:", {
                productId: state.productId,
                productSlug: state.productSlug
            });

            try {
                const productData = await readCheckoutProduct(supabase, checkoutTenantId, state, { allowUnpublished });
                if (cancelled) return;

                if (productData) {
                    console.log("Product data fetched successfully:", productData.name);
                    setProduct(productData);
                    setOrderDeliveryConfig((productData as any).banner_config?.order_delivery || null);

                    // Fetch Matrix for Upsell logic (wrapped in try/catch to not block the main product load)
                    try {
                        let matrixData: any = null;
                        if (productData.pricing_structure && typeof productData.pricing_structure === "object"
                            && !Array.isArray(productData.pricing_structure)
                            && productData.pricing_structure.mode === "matrix_layout_v1") return;
                        const slug = (state.productSlug || productData.slug)?.toLowerCase();
                        const format = normalizeFormatKey(state.selectedFormat || locationSearchParams.get("format")) || "A4";

                        console.log("Fetching matrix for upsells. Slug:", slug, "Format:", format);

                        if (slug === 'flyers') matrixData = await getFlyerMatrixDataFromDB(format);
                        else if (slug === 'foldere') matrixData = await getFolderMatrixDataFromDB(format, state.optionSelections?.foldType?.name || "");
                        else if (slug === 'visitkort') matrixData = await getVisitkortMatrixDataFromDB();
                        else if (slug === 'plakater') matrixData = await getPosterMatrixDataFromDB(format);
                        else if (slug === 'klistermærker') matrixData = await getStickerMatrixDataFromDB(format);
                        else if (slug === 'hæfter') matrixData = await getBookletMatrixDataFromDB(format, state.optionSelections?.pages?.name || "");
                        else if (slug === 'salgsmapper') matrixData = await getSalesfolderMatrixDataFromDB(format, state.optionSelections?.sides?.name || "");
                        else if (slug === 'beachflag') matrixData = await getBeachflagMatrixDataFromDB();
                        else if (slug === 'bannere') matrixData = await getBannerMatrixDataFromDB();
                        else if (slug === 'skilte') matrixData = await getSignMatrixDataFromDB();
                        else if (slug === 'folie') matrixData = await getFoilMatrixDataFromDB();
                        else if (productData.id) {
                            const generic = await getGenericMatrixDataFromDB(productData.id, state.variant);
                            matrixData = generic.matrixData;
                        }

                        if (cancelled) return;
                        if (matrixData && matrixData.columns && matrixData.columns.length > 0 && matrixData.rows) {
                            console.log("Matrix data loaded. Columns:", matrixData.columns.length, "Rows:", matrixData.rows);

                            // Find the closest row match
                            const variantValue = state.variant || state.selectedVariant;
                            console.log("Looking for row match for variant value:", variantValue);

                            const rowName = matrixData.rows.find((r: string) =>
                                variantValue && r.toLowerCase().trim() === variantValue.toLowerCase().trim()
                            );

                            console.log("Matched row name:", rowName);

                            calculateUpsells(matrixData, state.quantity, rowName);
                        } else {
                            console.log("No valid matrix data found for this product/slug or data is malformed.");
                        }
                    } catch (matrixErr) {
                        console.error("Error fetching matrix for upsells (non-blocking):", matrixErr);
                    }
                } else {
                    console.warn("Product not found by ID or slug in Supabase");
                    toast.error("Produktet kunne ikke findes i databasen.");
                }
            } catch (err: any) {
                if (cancelled) return;
                console.error("Critical error in fetchProductData:", err);
                setProductError(err.message || 'Produktet kunne ikke hentes. Prøv igen.');
            } finally {
                if (!cancelled) setLoading(false);
            }
        };

        fetchProductData();
        return () => { cancelled = true; };
    }, [hasCheckoutState, navigate, state, checkoutTenantId, tenantConflict, productRetry, draftFlow, draftAccessLoading, allowUnpublished]);

    useEffect(() => {
        let cancelled = false;
        let revision = 0;
        let currentUserId: string | null | undefined;
        const hydrateCustomer = async (user: any) => {
            const request = ++revision;
            const active = () => !cancelled && revision === request;
            if (currentUserId !== undefined && currentUserId !== (user?.id || null)) {
                deliveryAddressEditedRef.current = false;
                setCustomerEmail(""); setCustomerName(""); setCustomerPhone(""); setCustomerCompany("");
                setDeliveryRecipientName(""); setDeliveryCompany(""); setDeliveryAddress(""); setDeliveryAddress2("");
                setDeliveryZip(""); setDeliveryCity(""); setDeliveryCountry("DK");
                setBillingName(""); setBillingCompany(""); setBillingAddress(""); setBillingAddress2("");
                setBillingZip(""); setBillingCity(""); setBillingCountry("DK");
                setSelectedSavedAddressId("new"); setSelectedCustomerProfileId("new");
            }
            currentUserId = user?.id || null;
            setCheckoutUserId(currentUserId);
            setSavedAddresses([]); setSavedCustomerProfiles([]);
            setSavedAddressesLoading(Boolean(user));
            if (!user) return;
            try {
                const profiles = await readCheckoutCustomerProfiles(user.id);
                if (!active()) return;
                setSavedCustomerProfiles(profiles);
                const { data: profile, error } = await supabase.from("profiles")
                    .select("first_name, last_name, phone, company").eq("id", user.id).maybeSingle();
                if (!active()) return;
                if (error) throw error;
                const contact = resolveCustomerContact(user, profile);
                setCustomerEmail(prev => fillEmptyCustomerContact(prev, contact.customerEmail));
                setCustomerName(prev => fillEmptyCustomerContact(prev, contact.customerName));
                setCustomerPhone(prev => fillEmptyCustomerContact(prev, contact.customerPhone));
                setCustomerCompany(prev => fillEmptyCustomerContact(prev, contact.customerCompany));
            } catch {
                if (!active()) return;
                setCustomerEmail(prev => prev || String(user.email || ""));
                toast.error("Dine kontaktoplysninger kunne ikke hentes. Udfyld dem her, før du fortsætter.");
            }
            try {
                const { data, error } = await supabase.from("customer_addresses").select("*")
                    .eq("user_id", user.id).order("is_default", { ascending: false }).order("created_at", { ascending: false })
                    .returns<CheckoutSavedAddress[]>();
                if (!active()) return;
                if (error) throw error;
                const addresses = (data || []).filter(entry => entry?.id);
                setSavedAddresses(addresses);
                if (!deliveryAddressEditedRef.current && canHydrateDeliveryAddress(deliveryDraftRef.current)) {
                    const address = addresses.find(entry => entry.is_default) || addresses[0];
                    if (address) { applySavedAddress(address); setSelectedSavedAddressId(address.id); }
                }
            } catch {
                if (active()) toast.error("Adressebogen kunne ikke hentes. Du kan indtaste adressen her.");
            } finally {
                if (active()) setSavedAddressesLoading(false);
            }
        };
        const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
            if (cancelled || currentUserId === (session?.user?.id || null)) return;
            // Defer database calls outside Supabase's auth callback lock.
            void Promise.resolve().then(() => { if (!cancelled) void hydrateCustomer(session?.user || null); });
        });
        void supabase.auth.getUser().then(({ data: { user } }) => {
            if (!cancelled && currentUserId === undefined) void hydrateCustomer(user);
        });
        return () => { cancelled = true; revision += 1; subscription.unsubscribe(); };
    }, []);

    useEffect(() => {
        if (useSeparateBillingAddress) return;
        setBillingName((prev) => prev || customerName);
        setBillingCompany((prev) => prev || customerCompany);
        setBillingAddress((prev) => prev || deliveryAddress);
        setBillingAddress2((prev) => prev || deliveryAddress2);
        setBillingCountry(deliveryCountry);
        setBillingZip((prev) => prev || deliveryZip);
        setBillingCity((prev) => prev || deliveryCity);
    }, [
        useSeparateBillingAddress,
        customerName,
        customerCompany,
        deliveryAddress,
        deliveryAddress2,
        deliveryCountry,
        deliveryZip,
        deliveryCity,
    ]);

    useEffect(() => {
        if (senderMode !== "custom") return;
        if (senderName.trim()) return;
        const defaultSender = customerCompany.trim() || customerName.trim();
        if (defaultSender) {
            setSenderName(defaultSender);
        }
    }, [senderMode, senderName, customerCompany, customerName]);

    useEffect(() => {
        const productKey = state?.productId;
        if (state.proofApprovalRequired) return;
        if (!productKey) return;
        if (!isSiteCheckoutDesignReady(productKey, state)) return;
        setProofingApproved(true);
        setProofingOpen(false);
    }, [state]);

    useEffect(() => {
        const tenantId = shopSettings.data?.id;
        if (!tenantId) return;

        const fetchPaymentStatus = async () => {
            setPaymentStatusLoaded(false);
            const { data } = await (supabase as any)
                .from("tenant_payment_settings")
                .select("status, charges_enabled, stripe_account_id")
                .eq("tenant_id", tenantId)
                .maybeSingle();

            if (data) {
                setTenantPaymentStatus(data);
            } else {
                setTenantPaymentStatus(null);
            }
            setPaymentStatusLoaded(true);
        };

        fetchPaymentStatus();
    }, [shopSettings.data?.id]);

    const calculateUpsells = (m: { columns: number[]; cells: Record<string, Record<number, number>> }, currentQty: number, row: string) => {
        if (state?.pricingQuote?.quantityTiers?.length) return;
        // Old checkout sessions must match the exact selected row and price.
        // Extra-cost configurations return to the full calculator instead.
        const cells = row ? m.cells[row] : null;
        if (!cells || Number(state?.extraPrice) > 0 || Math.round(Number(cells[currentQty])) !== initialOrderSubtotal) {
            setQuantityTiers([]);
            return;
        }
        setQuantityTiers(m.columns.map(quantity => ({ quantity: Number(quantity), price: Math.round(Number(cells[quantity])) })));
    };

    const handleUpgrade = (qty: number, price: number) => {
        if (!quantityValueOptions(quantityTiers, orderQuantity, orderPrice).some(option => option.quantity === qty && option.price === price)) return;
        setOrderQuantity(qty);
        setOrderPrice(price);
        toast.success(`Antal ændret til ${qty.toLocaleString('da-DK')} stk.`);
    };

    const handleEditProduct = () => {
        const path = getSafeInternalPath(state?.productReturnPath) || buildProductFallbackPath(state?.productSlug, locationSearchParams);
        if (!path) return handleBackToConfiguration();
        const url = new URL(path, window.location.origin);
        url.searchParams.set('editCheckout', '1');
        navigate(url.pathname + url.search + url.hash);
    };

    const resetProofingAdjustments = () => {
        setProofingScale(100);
        setProofingOffset({ x: 0, y: 0 });
    };

    const scanPdfContourSignals = async (file: File): Promise<PdfContourScanResult | null> => {
        if (file.type !== "application/pdf" && !file.name.toLowerCase().endsWith(".pdf")) {
            return null;
        }

        let cutContourNameDetected = false;
        let separationHintDetected = false;
        let overprintHintDetected = false;
        let tail = '';
        for (let offset = 0; offset < file.size; offset += 1024 * 1024) {
            const text = tail + new TextDecoder().decode(await file.slice(offset, offset + 1024 * 1024).arrayBuffer());
            cutContourNameDetected ||= /\bCutContour\b/i.test(text);
            separationHintDetected ||= /\/Separation\s*\/CutContour\b/i.test(text) || /\/DeviceN\s*\[[^\]]*\/CutContour\b/i.test(text);
            overprintHintDetected ||= /\/[Oo][Pp]\s+true\b/i.test(text) || /\/OPM\s+[12]\b/i.test(text);
            tail = text.slice(-4096);
        }

        const summary = cutContourNameDetected
            ? "CutContour-navn fundet i PDF-data"
            : "CutContour-navn blev ikke fundet i PDF-data";

        const note = cutContourNameDetected
            ? "Scannen er vejledende. Brug fuld designer eller professionel preflight for at bekræfte spotfarve og overprint."
            : "Scannen er vejledende. Komprimerede eller tredjeparts-PDF'er kan skjule konturdata, så brug fuld designer hvis produktet kræver konturskæring.";

        return {
            cutContourNameDetected,
            separationHintDetected,
            overprintHintDetected,
            summary,
            note,
        };
    };

    const prepareImageProofingPreview = async (file: File, specs: TechnicalSpecs): Promise<ProofingPreviewData> => {
        const objectUrl = URL.createObjectURL(file);
        const img = new Image();
        img.src = objectUrl;
        await new Promise((resolve, reject) => {
            img.onload = resolve;
            img.onerror = reject;
        });

        return {
            fileType: "image",
            previewUrl: objectUrl,
            physicalWidthMm: (img.width / recommendedDpi) * 25.4,
            physicalHeightMm: (img.height / recommendedDpi) * 25.4,
            sourceWidthPx: img.width,
            sourceHeightPx: img.height,
        };
    };

    const preparePdfProofingPreview = async (file: File, specs: TechnicalSpecs): Promise<ProofingPreviewData> => {
        const pdf = await openLocalPdf(file);
        try {
        if (state?.designerMode === 'brochure') {
            if (!validBrochurePageCount(state.brochurePageCount || 0)) throw new Error('Trykfilen kræver et gyldigt valgt brochuresidetal.');
            validateBrochurePdfPageCount(pdf.numPages, state.brochurePageCount!);
            for (let index = 1; index <= pdf.numPages; index++) {
                const candidate = await pdf.getPage(index);
                const viewport = candidate.getViewport({ scale: 1 });
                if (Math.abs(ptToMm(viewport.width) - specs.width_mm - specs.bleed_mm * 2) > .15
                    || Math.abs(ptToMm(viewport.height) - specs.height_mm - specs.bleed_mm * 2) > .15) {
                    throw new Error(`Trykfilens side ${index} skal være ${specs.width_mm + specs.bleed_mm * 2} × ${specs.height_mm + specs.bleed_mm * 2} mm inklusive udfald.`);
                }
            }
        }
        const page = await pdf.getPage(1);
        const baseViewport = page.getViewport({ scale: 1 });
        const widthMm = ptToMm(baseViewport.width);
        const heightMm = ptToMm(baseViewport.height);
        const printableSize = resolvePdfPrintableSize(widthMm, heightMm, specs);

        const previewMaxSize = 1400;
        const renderScale = Math.min(previewMaxSize / baseViewport.width, previewMaxSize / baseViewport.height, 2.5);
        const viewport = page.getViewport({ scale: renderScale });

        const canvas = document.createElement("canvas");
        canvas.width = Math.round(viewport.width);
        canvas.height = Math.round(viewport.height);
        const context = canvas.getContext("2d");
        if (!context) {
            throw new Error("Kunne ikke oprette PDF-preview");
        }
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);

        await page.render({
            canvasContext: context,
            viewport,
        }).promise;

        return {
            fileType: "pdf",
            previewUrl: canvas.toDataURL("image/png"),
            physicalWidthMm: printableSize.displayWidthMm,
            physicalHeightMm: printableSize.displayHeightMm,
            sourceWidthPx: canvas.width,
            sourceHeightPx: canvas.height,
            pageCount: pdf.numPages,
        };
        } finally { await pdf.destroy(); }
    };

    const prepareProofingPreview = async (file: File, specs: TechnicalSpecs) => {
        if (file.type.startsWith("image/")) {
            return prepareImageProofingPreview(file, specs);
        }
        return preparePdfProofingPreview(file, specs);
    };

    const processUploadFile = async (file: File | null | undefined) => {
        if (!file || uploadBusyRef.current || proofExportBusyRef.current) return;

        if (state?.designerMode === 'brochure' && file.type !== 'application/pdf') {
            toast.error('Upload brochuren som en samlet PDF, eller brug sidedesigneren til billeder.');
            return;
        }

        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png', 'image/tiff'];
        if (!allowedTypes.includes(file.type)) {
            toast.error("Venligst upload en PDF eller et billede (JPG, PNG, TIFF)");
            return;
        }
        if (!file.size || file.size > MAX_CHECKOUT_UPLOAD_BYTES) {
            toast.error(`Trykfiler over ${CHECKOUT_UPLOAD_LIMIT_LABEL} skal aftales med butikken.`);
            return;
        }

        uploadBusyRef.current = true;
        setUploading(true);
        setUploadProgress({phase: "preparing", loaded: 0, total: file.size});
        setPreflightResults(null);
        setPlatformPreflight(null);
        setProofingApproved(false);
        setProofingOpen(false);
        setProofingPreview(null);
        setPdfContourScan(null);
        resetProofingAdjustments();
        if (state?.productId) {
            clearSiteCheckoutDesignReady(state.productId);
        }

        try {
            const specs = getResolvedSpecs();
            if (!specs) {
                toast.error("Kunne ikke finde tekniske specifikationer for produktet.");
                return;
            }

            const fileExt = file.name.split('.').pop();
            const productRef = state.productId || state.productSlug || 'unknown';
            const fileName = `${productRef}-order-${Date.now()}.${fileExt}`;
            const filePath = `order-files/${fileName}`;

            const brochurePreview = state?.designerMode === 'brochure' ? await preparePdfProofingPreview(file, specs) : null;
            const upload = await uploadCheckoutFile(supabase, shopSettings.data?.id || '', file, file.name, filePath, setUploadProgress);
            const publicUrl = upload.url;

            const preparedPreview = brochurePreview || await prepareProofingPreview(file, specs);
            const contourScan = await scanPdfContourSignals(file);
            setUploadedFile(upload);
            setPreviewUrl(preparedPreview.previewUrl);
            setProofingPreview(preparedPreview);
            setPdfContourScan(contourScan);

            const existingSession = readSiteCheckoutSession();
            if (existingSession?.designerExport) {
                writeSiteCheckoutSession({
                    ...existingSession,
                    designerExport: null,
                });
            }

            await runPreflight(file, { filePath: upload.path, publicUrl });
            // The preview and warnings can be reviewed and accepted on this page.
            setProofingOpen(false);

            toast.success("Fil uploadet og tjekket");
        } catch (err) {
            console.error("Error uploading file:", err);
            const message = err instanceof Error ? err.message : "";
            toast.error(/^(Trykfilen|Trykfiler|Uploaden|Shoppen|Adgangen)/.test(message)
                ? message
                : "Kunne ikke uploade filen. Prøv igen, eller kontakt butikken hvis fejlen fortsætter.");
        } finally {
            setUploading(false);
            uploadBusyRef.current = false;
            setUploadDropActive(false);
        }
    };

    const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        await processUploadFile(event.target.files?.[0]);
        event.target.value = "";
    };

    const handleUploadDragOver = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        if (!uploadDropActive) setUploadDropActive(true);
    };

    const handleUploadDragLeave = (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        const nextTarget = event.relatedTarget as Node | null;
        if (nextTarget && event.currentTarget.contains(nextTarget)) return;
        setUploadDropActive(false);
    };

    const handleUploadDrop = async (event: React.DragEvent<HTMLDivElement>) => {
        event.preventDefault();
        setUploadDropActive(false);
        await processUploadFile(event.dataTransfer?.files?.[0]);
    };

    const runPreflight = async (
        file: File,
        uploadInfo?: { filePath: string; publicUrl: string }
    ): Promise<CheckoutPreflightResult | null> => {
        const specs = getResolvedSpecs();
        if (!specs) return null;

        const issues: string[] = [];
        let dpi = 0;
        let width_px = 0;
        let height_px = 0;
        let aspectRatioMatch = true;
        let dpiOk = true;

        if (file.type.startsWith('image/')) {
            const img = new Image();
            img.src = URL.createObjectURL(file);
            await new Promise((resolve) => (img.onload = resolve));

            width_px = img.width;
            height_px = img.height;

            dpi = specs.min_dpi;
            dpiOk = true;
            aspectRatioMatch = true;
        } else if (file.type === 'application/pdf') {
            issues.push(PDF_COLOUR_REVIEW_NOTICE);
            try {
                const pdf = await openLocalPdf(file);
                const page = await pdf.getPage(1);
                const viewport = page.getViewport({ scale: 1 });

                const pdfWidthMm = ptToMm(viewport.width);
                const pdfHeightMm = ptToMm(viewport.height);
                const trimWidthMm = specs.width_mm;
                const trimHeightMm = specs.height_mm;
                const targetWidthMm = specs.width_mm + (specs.bleed_mm * 2);
                const targetHeightMm = specs.height_mm + (specs.bleed_mm * 2);
                const printableSize = resolvePdfPrintableSize(pdfWidthMm, pdfHeightMm, specs);

                if (!printableSize.matchesExpected) {
                    aspectRatioMatch = false;
                    issues.push(`PDF-formatet er ${Math.round(pdfWidthMm)} × ${Math.round(pdfHeightMm)} mm og matcher hverken trimformatet ${Math.round(trimWidthMm)} × ${Math.round(trimHeightMm)} mm eller formatet med bleed ${Math.round(targetWidthMm)} × ${Math.round(targetHeightMm)} mm.`);
                }

                await pdf.destroy();
            } catch (pdfError) {
                console.error("PDF dimension check failed:", pdfError);
                issues.push("Kunne ikke læse PDF-dimensioner automatisk. Kontroller filformatet manuelt.");
            }

            if (isPodProduct && podPreflightEnabled && uploadInfo?.filePath && product?.id) {
                await runPlatformPreflight({
                    productId: product.id,
                    filePath: uploadInfo.filePath,
                    specs,
                    autoFix: podPreflightAutoFix,
                });
            }
        }

        const result = {
            dpi: Math.round(dpi),
            width_px,
            height_px,
            aspectRatioMatch,
            dpiOk,
            issues
        } satisfies CheckoutPreflightResult;

        setPreflightResults(result);
        return result;
    };

    const runPlatformPreflight = async (params: {
        productId: string;
        filePath: string;
        specs: TechnicalSpecs;
        autoFix: boolean;
    }) => {
        setPlatformPreflightLoading(true);
        try {
            const { data, error } = await supabase.functions.invoke("pod2-pdf-preflight", {
                body: {
                    productId: params.productId,
                    storageBucket: "order-files",
                    filePath: params.filePath,
                    fileAccess: checkoutUploadAccess(params.filePath),
                    specs: params.specs,
                    autoFix: params.autoFix,
                },
            });

            if (error) throw error;
            if (data?.error) throw new Error(data.error);

            const result = {
                status: data.status as "PROCESSING" | "PROCESSED" | "FAILED",
                errors: data.errors || [],
                warnings: data.warnings || [],
                fixes: data.fixes || [],
                jobId: data.jobId,
                updatedFileUrl: data.updatedFileUrl,
                message: data.message,
            };

            setPlatformPreflight(result);

            if (data.updatedFileUrl) {
                // A processor output is a new version. Never approve it using the old preview.
                setUploadedFile((prev) => prev ? { ...prev, url: data.updatedFileUrl } : prev);
                setProofingApproved(false);
                setApprovedProofIdentity(null);
                setProofingPreview(null);
                setPreviewUrl(null);
                toast.info("Filkontrollen har lavet en ny version. Download og upload den rettede fil til ny korrektur.");
            }
        } catch (err: any) {
            console.error("Teknisk kontrol fejlede:", err);
            setPlatformPreflight({
                status: "FAILED",
                errors: ["Filen kunne ikke valideres. Prøv igen, eller kontakt os hvis problemet fortsætter."],
                warnings: [],
                fixes: [],
            });
        } finally {
            setPlatformPreflightLoading(false);
        }
    };

    if (!paymentSuccess && (productError || tenantConflict)) {
        const returnPath = checkoutProductReturnPath(state);
        return <StorefrontThemeFrame branding={branding} orderDesign={checkoutDesign} tenantName={tenantName}>
            <main className="container mx-auto max-w-xl px-4 py-12">
                <Card><CardHeader><CardTitle>Bestillingen kunne ikke åbnes</CardTitle></CardHeader><CardContent className="space-y-4">
                    <p role="alert">{productError || 'Denne bestilling tilhører en anden butik. Din gemte bestilling er bevaret.'}</p>
                    <div className="flex flex-wrap gap-3">
                        {returnPath && <Button onClick={() => navigate(returnPath)}>Tilbage til produktet</Button>}
                        {!tenantConflict && <Button variant="outline" onClick={() => setProductRetry(value => value + 1)}>Prøv igen</Button>}
                    </div>
                    {!tenantConflict && hasCheckoutRecovery && <Button variant="outline" disabled={finalizingPayment || paymentLoading} onClick={() => void handlePaymentSuccess()}>Kontrollér betaling og ordre</Button>}
                    {!tenantConflict && orderPersistWarning && <p role="status">{orderPersistWarning}</p>}
                </CardContent></Card>
            </main>
        </StorefrontThemeFrame>;
    }

    if (loading || !hasCheckoutState) {
        return (
            <div className="min-h-screen flex items-center justify-center">
                <Loader2 className="h-12 w-12 animate-spin text-primary" />
            </div>
        );
    }

    const beginProofingDrag = (clientX: number, clientY: number) => {
        proofingDragStartRef.current = {
            x: clientX,
            y: clientY,
            startX: proofingOffset.x,
            startY: proofingOffset.y,
        };
        setProofingDragging(true);
    };

    const handleProofingPointerDown = (event: React.MouseEvent<HTMLDivElement>) => {
        event.preventDefault();
        event.stopPropagation();
        beginProofingDrag(event.clientX, event.clientY);
    };

    const handleProofingArtboardPointerDown = (event: React.MouseEvent<HTMLDivElement>) => {
        if (!proofingPreview) return;
        const target = event.target as HTMLElement | null;
        if (target?.closest("button")) return;
        event.preventDefault();
        event.stopPropagation();
        beginProofingDrag(event.clientX, event.clientY);
    };

    const handleProofingResizeStart = (event: React.MouseEvent<HTMLButtonElement>) => {
        event.preventDefault();
        event.stopPropagation();
        const rect = proofingArtworkRef.current?.getBoundingClientRect();
        if (!rect) return;
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        const startDistance = Math.max(1, Math.hypot(event.clientX - centerX, event.clientY - centerY));
        proofingResizeStartRef.current = {
            centerX,
            centerY,
            startDistance,
            startScale: proofingScale,
        };
        setProofingResizing(true);
    };

    const handleContinueToCheckout = () => {
        const summary = checkoutSummaryRef.current;
        if (!summary) return;
        summary.focus({ preventScroll: true });
        summary.scrollIntoView({
            behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
            block: 'start',
        });
    };

    const handleApproveProofing = async () => {
        if (proofExportBusyRef.current) return;
        if (!proofAvailability.canReview) {
            toast.error(uploading || platformPreflightLoading
                ? "Vent, mens filen uploades og tjekkes."
                : "Upload en fil, før du godkender korrekturen.");
            return;
        }
        if (!currentProofArtifact) {
            toast.error("Upload filen igen, så korrekturen viser den aktuelle produktionsfil.");
            return;
        }
        if (!printWarningsAccepted) {
            toast.error("Acceptér bemærkningerne og ansvaret for den viste korrektur, før du godkender.");
            return;
        }
        if (proofNeedsExport) {
            if (!canExportImageHere || !uploadedFile || !specs) {
                toast.error("Upload en færdig tryk-PDF i produktets mål inklusive bleed, eller ret filen i designeren.");
                return;
            }
            proofExportBusyRef.current = true;
            setExportingProof(true);
            const sourceIdentity = currentProofIdentity;
            try {
                const source = await readCheckoutUpload(supabase, uploadedFile.path);
                if (await hashCheckoutArtifact(source) !== uploadedFile.sha256) throw new Error('Trykfilen er ændret. Upload og godkend filen igen.');
                const { createImageProofPdf } = await import('@/lib/checkout/imageProofPdf');
                const bytes = await createImageProofPdf(new Uint8Array(await source.arrayBuffer()), {
                    ...currentProofArtifact, bleedMm: specs.bleed_mm,
                });
                const name = uploadedFile.name.replace(/\.[^.]+$/, '') + '-tryk.pdf';
                const file = new File([bytes as BlobPart], name, { type: 'application/pdf' });
                const preview = await preparePdfProofingPreview(file, specs);
                const upload = await uploadCheckoutFile(supabase, shopSettings.data?.id || '', file, name,
                    `order-files/proof-${crypto.randomUUID()}.pdf`, setUploadProgress);
                if (latestProofIdentityRef.current !== sourceIdentity) throw new Error('Korrekturen er ændret. Kontrollér den aktuelle fil igen.');
                const identity = proofArtifactFingerprint({ ...currentProofArtifact,
                    fileUrl: upload.url, filePath: upload.path, sha256: upload.sha256,
                    fileType: 'pdf', designerExport: false, physicalWidthMm: targetWidth, physicalHeightMm: targetHeight,
                    scale: 100, offsetX: 0, offsetY: 0,
                });
                setApprovedPrintWarnings(makePrintWarningApproval(upload.sha256));
                setUploadedFile(upload);
                setProofingPreview(preview);
                setPreviewUrl(preview.previewUrl);
                resetProofingAdjustments();
                setApprovedProofIdentity(identity);
                setProofingApproved(true);
                returnToCheckoutAfterProofRef.current = proofingOpen;
                setProofingOpen(false);
                if (!proofingOpen) requestAnimationFrame(handleContinueToCheckout);
                toast.success('Trykfilen er klargjort og godkendt.');
            } catch (error) {
                toast.error(error instanceof Error ? error.message : 'Trykfilen kunne ikke klargøres. Prøv igen.');
            } finally {
                proofExportBusyRef.current = false;
                setExportingProof(false);
            }
            return;
        }
        setApprovedPrintWarnings(makePrintWarningApproval(uploadedFile!.sha256));
        setApprovedProofIdentity(currentProofIdentity);
        setProofingApproved(true);
        // Let Radix finish closing before moving focus out of the Corrector.
        returnToCheckoutAfterProofRef.current = proofingOpen;
        setProofingOpen(false);
        if (!proofingOpen) requestAnimationFrame(handleContinueToCheckout);
        toast.success("Fil godkendt. Du kan nu færdiggøre din bestilling.");
    };

    const handleOpenFullDesigner = () => {
        if (professionalPdfUploadOnly) {
            toast.error(
                checkoutTemplateArtworkModeReasonDa
                || "Denne efterbehandling kræver en professionel tryk-PDF. Download skabelonen og upload den færdige fil her.",
            );
            return;
        }

        const existingSession = readSiteCheckoutSession();
        if (existingSession?.siteUpload) {
            writeSiteCheckoutSession({
                ...existingSession,
                siteUpload: {
                    ...existingSession.siteUpload,
                    proofingScalePercent: proofingScale,
                    proofingOffsetXPercent: proofingOffset.x,
                    proofingOffsetYPercent: proofingOffset.y,
                },
            });
        }

        const params = new URLSearchParams(location.search);
        if (shopSettings.data?.id) params.set("tenantId", shopSettings.data.id);
        if (state?.productId) params.set("productId", String(state.productId));
        if (state?.designerMode) params.set("designerMode", String(state.designerMode));
        try { applyBrochureDocumentParams(params, state?.designerMode, state?.brochurePageCount); }
        catch (error) { toast.error((error as Error).message); return; }
        if (state?.pricingModel) params.set("pricingModel", String(state.pricingModel));
        if (state?.linkedTemplateId) params.set("templateId", String(state.linkedTemplateId));
        if (checkoutTemplatePdfUrl) {
            params.set("templatePdfUrl", checkoutTemplatePdfUrl);
            params.set("templatePdfName", checkoutTemplatePdfName);
            if (checkoutTemplatePdfSha256) {
                params.set("templatePdfSha256", checkoutTemplatePdfSha256);
            }
        }
        applyDesignerDocumentParams(params, {
            formatLabel: resolvedFormatLabel,
            widthMm: specs?.width_mm,
            heightMm: specs?.height_mm,
            bleedMm: specs?.bleed_mm,
            safeMm: safeAreaMm,
        });
        params.set("order", "1");
        const checkoutPath = buildCurrentInternalPath(location.pathname, location.search);
        if (checkoutPath) {
            params.set("returnTo", checkoutPath);
            params.set("backTo", checkoutPath);
        }
        navigate(`/designer?${params.toString()}`);
    };

    const receipt: OrderReceiptData = {
        productName: displayProductName, imageUrl: product?.image_url,
        format: resolvedFormatLabel, variant: state?.selectedVariant,
        quantity: orderQuantity, fileName: uploadedFile?.name,
        subtotal: orderPrice, shipping: shippingCost, total: checkoutTotal, tax: checkoutTax || undefined,
    };
    const deliveryForm = (<>
                                    {activeDeliveryMethods.length > 0 && (
                                        <div className="space-y-2 pt-2 border-t border-black/5">
                                            <div className="flex items-center gap-2">
                                                <Truck className="h-4 w-4 text-primary" />
                                                <h4 className="text-sm font-semibold text-slate-900">Leveringsmetode</h4>
                                            </div>
                                            <RadioGroup value={shippingSelected} onValueChange={setShippingSelected} className="space-y-1.5">
                                                {activeDeliveryMethods.map((method) => {
                                                    const methodCost = resolveDeliveryMethodCost(orderPrice, method);
                                                    const deadline = getNextCutoffDate(method, deliveryNow);
                                                    const countdown = deadline ? formatCountdown(deadline.getTime() - deliveryNow.getTime()) : null;
                                                    const estimatedDelivery = getEstimatedDeliveryDate(method, deliveryNow);
                                                    const isSelected = shippingSelected === method.id;
                                                    return (
                                                        <label
                                                            key={method.id}
                                                            {...sharedSelection}
                                                            data-state={isSelected ? "checked" : "unchecked"}
                                                            htmlFor={`cfg-delivery-${method.id}`}
                                                            className={`block cursor-pointer rounded-lg border px-3 py-2.5 transition-colors ${isSelected ? "border-primary bg-primary/5" : "border-slate-200 bg-white hover:border-primary/40"}`}
                                                        >
                                                            <div className="flex items-start gap-2.5">
                                                                <RadioGroupItem id={`cfg-delivery-${method.id}`} value={method.id} className="mt-0.5" />
                                                                <div className="flex-1 min-w-0">
                                                                    <div className="flex items-start justify-between gap-2">
                                                                        <p className="text-sm font-medium text-slate-900 truncate">{method.name}</p>
                                                                        <p className="text-sm font-semibold text-slate-900 whitespace-nowrap">{methodCost} kr</p>
                                                                    </div>
                                                                    <div className="mt-0.5 flex flex-wrap items-center gap-x-2 text-[11px] text-muted-foreground">
                                                                        {estimatedDelivery && (
                                                                            <span>Levering {deliveryDateFormatter.format(estimatedDelivery)}</span>
                                                                        )}
                                                                        {countdown && (
                                                                            <span className="inline-flex items-center gap-1 text-primary">
                                                                                <Clock3 className="h-3 w-3" />
                                                                                {countdown}
                                                                            </span>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </label>
                                                    );
                                                })}
                                            </RadioGroup>
                                        </div>
                                    )}

    </>);
    const orderSummary = (<Card ref={checkoutSummaryRef} tabIndex={-1} role="region" aria-labelledby="checkout-summary-heading" data-branding-id="colors.card" className="order-summary-card scroll-mt-24 shadow-sm focus-visible:outline-primary">
                                <CardHeader className="pb-2">
                                    <div className="flex items-center justify-between">
                                        <CardTitle id="checkout-summary-heading">Din bestilling</CardTitle>
                                        <Package className="h-5 w-5 text-slate-400" />
                                    </div>
                                </CardHeader>
                                <CardContent className="space-y-4">
                                    <div className="order-checkout-product pb-4 border-b border-black/5">
                                        {product?.image_url && <img src={product.image_url} alt={displayProductName} className="order-checkout-product-image" />}
                                        <h4 className="font-bold text-lg">{displayProductName}</h4>
                                        <p className="text-sm text-muted-foreground">{String(state.summary || "").replace(/[\d., ]+\s*stk\.?/i, ` ${orderQuantity.toLocaleString("da-DK")} stk.`)}</p>
                                            <div className="mt-2 space-y-1">
<details className="order-flow-help"><summary>Om fil og produktion</summary>                                            <div className="mb-3 flex flex-wrap items-center gap-2">
                                                <Badge variant="secondary" className="rounded-sm">
                                                    {productFlowLabel}
                                                </Badge>
                                            {productFlowHelpText ? (
                                                <span className="text-xs text-muted-foreground">
                                                    {productFlowHelpText}
                                                </span>
                                            ) : null}
                                        </div>
                                        <div className={`mb-3 rounded-lg border px-3 py-3 text-sm ${checkoutFlowNoticeClasses[checkoutFlowNotice.tone]}`}>
                                            <div className="flex items-start gap-2">
                                                <Info className="mt-0.5 h-4 w-4 shrink-0" />
                                                <div className="space-y-2">
                                                    <div>
                                                        <p className="font-semibold">{checkoutFlowNotice.title}</p>
                                                        <p className="text-xs opacity-80">{checkoutFlowNotice.body}</p>
                                                    </div>
                                                    <div className="grid gap-1 text-xs opacity-85 md:grid-cols-3">
                                                        {checkoutFlowNotice.checklist.map((item) => (
                                                            <span key={item} className="flex items-start gap-1.5">
                                                                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                                                                {item}
                                                            </span>
                                                        ))}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
</details>                                            {Object.values(nonSizeOptionSelections).map((opt: CheckoutOptionSelection, idx: number) => (
                                                <p key={idx} className="text-xs text-slate-500 flex items-center gap-1">
                                                    <span className="w-1.5 h-1.5 bg-primary/40 rounded-full" />
                                                    {opt.name}
                                                </p>
                                            ))}
                                        </div>

                                        {sizeDistributionConfig && (
                                            <div className="mt-3 rounded-lg border border-primary/20 bg-primary/5 p-3 shadow-sm space-y-2">
                                                <div>
                                                    <p className="text-xs font-semibold text-primary">{sizeDistributionConfig.title}</p>
                                                    <p className="text-[11px] text-muted-foreground">
                                                        Fordel størrelserne. Dette påvirker ikke prisen.
                                                    </p>
                                                </div>
                                                <div className="grid grid-cols-2 gap-2">
                                                    {sizeDistributionFields.map((field) => (
                                                        <label key={field.key} className="space-y-1">
                                                            <span className="text-[11px] text-muted-foreground">{field.label}</span>
                                                            <Input
                                                                type="number"
                                                                min={0}
                                                                step={1}
                                                                value={sizeDistributionValues[field.key] ?? 0}
                                                                onChange={(event) => handleSizeDistributionChange(field.key, event.target.value)}
                                                                className="h-8 bg-white"
                                                            />
                                                        </label>
                                                    ))}
                                                </div>
                                                <p className={`text-[11px] ${sizeDistributionMismatch ? "text-destructive" : "text-muted-foreground"}`}>
                                                    Sum: {sizeDistributionTotal} / {orderQuantity} stk
                                                    {sizeDistributionMismatch ? " (matcher ikke antal)" : ""}
                                                </p>
                                            </div>
                                        )}
                                    </div>

                                    <div className="space-y-2">
                                        <div className="flex justify-between text-sm">
                                            <span className="text-muted-foreground">Antal:</span>
                                            <span className="font-medium">{orderQuantity} stk</span>
                                        </div>
                                        <div className="flex justify-between text-sm">
                                            <span className="text-muted-foreground">Pris ex. moms:</span>
                                            <span className="font-medium">{orderPrice} kr</span>
                                        </div>
                                    </div>

                                    {checkoutDesign === 4 ? deliveryForm : <div className="order-selected-delivery"><span>Levering ({activeDeliveryMethods.find(method => method.id === shippingSelected)?.name || 'valgt'})</span><strong>{shippingCost} kr</strong></div>}

                                    <div className="pt-3 border-t-2 border-primary/10 flex justify-between items-end">
                                        <span className="font-bold">{checkoutTax ? 'Total (inkl. moms):' : 'Beløb ekskl. moms:'}</span>
                                        <span className="text-2xl font-bold text-primary">{checkoutTotal.toLocaleString('da-DK', {minimumFractionDigits: 2, maximumFractionDigits: 2})} kr</span>
                                    </div>
                                    {checkoutTax && <p className="flex justify-between text-sm"><span>Moms (25 %)</span><span>{(checkoutTax.vatAmountOre / 100).toLocaleString('da-DK', {minimumFractionDigits: 2, maximumFractionDigits: 2})} kr</span></p>}
                                    {checkoutTaxMessage && <p role="alert" className="text-sm text-destructive">{checkoutTaxMessage}</p>}

                                    {paymentStatusLoaded &&
                                        !shopSettings.data?.is_platform_owned &&
                                        (!tenantPaymentStatus ||
                                            !tenantPaymentStatus.stripe_account_id ||
                                            !tenantPaymentStatus.charges_enabled ||
                                            tenantPaymentStatus.status === "disabled") && (
                                            <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800 flex items-start gap-2 shadow-sm">
                                                <AlertCircle className="h-4 w-4 mt-0.5" />
                                                <div>
                                                    <p className="font-medium">Betaling går til platformen</p>
                                                    <p className="text-xs text-amber-700">
                                                        Denne shop er ikke forbundet til Stripe endnu. For at modtage betalinger direkte, skal shop-ejeren forbinde Stripe i admin.
                                                    </p>
                                                </div>
                                            </div>
                                        )}

                                    {sizeDistributionMismatch && (
                                        <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 flex items-start gap-2 shadow-sm">
                                            <AlertCircle className="h-4 w-4 mt-0.5" />
                                            <div>
                                                <p className="font-medium">Størrelsesfordeling mangler</p>
                                                <p className="text-xs text-red-700">
                                                    Summen af størrelser skal være {orderQuantity} stk før betaling.
                                                </p>
                                            </div>
                                        </div>
                                    )}

                                    {proofAvailability.canReview && proofingApprovalPending && proofingRequiresModalReview && (
                                        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-800 flex items-start gap-2 shadow-sm">
                                            <AlertCircle className="h-4 w-4 mt-0.5" />
                                            <div className="space-y-1">
                                                <p className="font-medium">Filkorrektur mangler godkendelse</p>
                                                <p className="text-xs text-amber-700">
                                                    Godkend filen ved previewet, eller åbn korrektur for at se nærmere på den.
                                                </p>
                                                <Button
                                                    type="button"
                                                    variant="outline"
                                                    size="sm"
                                                    className="h-8 bg-white"
                                                    onClick={() => setProofingOpen(true)}
                                                >
                                                    Åbn korrektur
                                                </Button>
                                            </div>
                                        </div>
                                    )}

                                    {quickApproveAvailable && (
                                        <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-900 flex items-start gap-2 shadow-sm">
                                            <CheckCircle2 className="h-4 w-4 mt-0.5" />
                                            <div className="space-y-2">
                                                <div>
                                                    <p className="font-medium">Filen ser klar ud</p>
                                                    <p className="text-xs text-emerald-800">
                                                        Du kan godkende filen direkte eller åbne korrekturvinduet for manuel kontrol.
                                                    </p>
                                                </div>
                                                <div className="flex flex-wrap gap-2">
                                                    <StorefrontPrimaryButton type="button" size="sm" className="h-8" onClick={handleApproveProofing}>
                                                        Godkend fil
                                                    </StorefrontPrimaryButton>
                                                    <Button
                                                        type="button"
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-8 bg-white"
                                                        onClick={() => setProofingOpen(true)}
                                                    >
                                                        Åbn korrektur
                                                    </Button>
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {proofArtifactApproved && (
                                        <p role="status" className="flex items-start gap-2 text-sm text-primary">
                                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0" aria-hidden="true" />
                                            Filen er godkendt. Kontrollér kontakt og levering, og gå videre til betaling.
                                        </p>
                                    )}

                                    <StorefrontPrimaryButton
                                        className="w-full h-12 text-lg font-bold mt-4 group shadow-md"
                                        onClick={handleProceedToPayment}
                                        disabled={draftFlow || !uploadedFile || paymentLoading || sizeDistributionMismatch || proofingApprovalPending || !!checkoutTaxMessage}
                                    >
                                        {paymentLoading ? (
                                            <>
                                                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                                                Forbereder betaling...
                                            </>
                                        ) : (
                                            <>
                                                {draftFlow ? "Testflow — ingen betaling" : "Gå til betaling"}
                                                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
                                            </>
                                        )}
                                    </StorefrontPrimaryButton>
                                </CardContent>
                            </Card>);
    const advancedForm = (<div className="order-advanced-form">
                                    {/* ──────────────────────────────────────────────────────────────
                                         Step 3 — Flere muligheder (collapsed by default)
                                         Afsender på pakken + separat faktureringsadresse.
                                         ────────────────────────────────────────────────────────────── */}
                                    <div className="rounded-lg border border-slate-200 bg-white shadow-sm overflow-hidden">
                                        <button
                                            type="button"
                                            className="w-full flex items-center justify-between gap-3 px-4 py-3 hover:bg-slate-50/60"
                                            onClick={() => setMoreOptionsOpen(!moreOptionsOpen)}
                                        >
                                            <div className="flex items-center gap-3 min-w-0">
                                                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-100 text-slate-600 shrink-0">
                                                    <span className="text-xs font-bold">3</span>
                                                </div>
                                                <div className="text-left">
                                                    <p className="text-sm font-semibold text-slate-900">Flere muligheder</p>
                                                    <p className="text-xs text-muted-foreground">Afsender, blind forsendelse, separat fakturering</p>
                                                </div>
                                            </div>
                                            <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform ${moreOptionsOpen ? "rotate-180" : ""}`} />
                                        </button>
                                        {moreOptionsOpen && (
                                            <div className="px-4 pb-4 pt-1 space-y-4 border-t border-slate-100">
                                                <div className="space-y-2">
                                                    <p className="text-xs font-semibold text-slate-700">Afsender på pakken</p>
                                                    <RadioGroup
                                                        value={senderMode}
                                                        onValueChange={(value) => {
                                                            const nextValue = value as CheckoutSenderMode;
                                                            setSenderMode(nextValue);
                                                            if (nextValue === "custom" && !senderName.trim()) {
                                                                setSenderName(customerCompany.trim() || customerName.trim());
                                                            }
                                                        }}
                                                        className="space-y-1.5"
                                                    >
                                                        <label className="flex items-start gap-3 rounded-md border border-slate-200 bg-white px-3 py-2.5">
                                                            <RadioGroupItem value="standard" id="sender-standard" className="mt-0.5" />
                                                            <div>
                                                                <p className="text-sm font-medium text-slate-900">Standard</p>
                                                                <p className="text-xs text-muted-foreground">WebPrinter står som normal afsender.</p>
                                                            </div>
                                                        </label>
                                                        <label className="flex items-start gap-3 rounded-md border border-slate-200 bg-white px-3 py-2.5">
                                                            <RadioGroupItem value="blind" id="sender-blind" className="mt-0.5" />
                                                            <div>
                                                                <p className="text-sm font-medium text-slate-900">Blind forsendelse</p>
                                                                <p className="text-xs text-muted-foreground">Modtageren ser ikke WebPrinter som afsender.</p>
                                                            </div>
                                                        </label>
                                                        <label className="flex items-start gap-3 rounded-md border border-slate-200 bg-white px-3 py-2.5">
                                                            <RadioGroupItem value="custom" id="sender-custom" className="mt-0.5" />
                                                            <div>
                                                                <p className="text-sm font-medium text-slate-900">Brug eget navn/firma</p>
                                                                <p className="text-xs text-muted-foreground">Pakken sendes med dit navn eller firmanavn som afsender.</p>
                                                            </div>
                                                        </label>
                                                    </RadioGroup>
                                                    {senderMode === "custom" && (
                                                        <div className="space-y-1.5">
                                                            <Label htmlFor="sender-name" className="text-xs">Afsendernavn</Label>
                                                            <Input
                                                                id="sender-name"
                                                                value={senderName}
                                                                onChange={(event) => setSenderName(event.target.value)}
                                                                placeholder="Dit navn eller firmanavn"
                                                            />
                                                        </div>
                                                    )}
                                                </div>

                                                <label className="flex items-start gap-3 rounded-md border border-slate-200 bg-slate-50/60 px-3 py-2.5">
                                                    <input
                                                        type="checkbox"
                                                        className="mt-1 h-4 w-4 rounded border-slate-300"
                                                        checked={useSeparateBillingAddress}
                                                        onChange={(event) => setUseSeparateBillingAddress(event.target.checked)}
                                                    />
                                                    <div>
                                                        <p className="text-sm font-medium text-slate-900">Brug separat faktureringsadresse</p>
                                                        <p className="text-xs text-muted-foreground">Hvis fakturaen skal gå til en anden adresse end leveringen.</p>
                                                    </div>
                                                </label>

                                                {useSeparateBillingAddress && (
                                                    <div className="space-y-3 pl-7">
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="billing-name" className="text-xs">Faktura navn</Label>
                                                                <Input id="billing-name" value={billingName} onChange={(event) => setBillingName(event.target.value)} />
                                                            </div>
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="billing-company" className="text-xs">Faktura firma</Label>
                                                                <Input id="billing-company" value={billingCompany} onChange={(event) => setBillingCompany(event.target.value)} />
                                                            </div>
                                                        </div>
                                                        <div className="space-y-1.5">
                                                            <Label htmlFor="billing-address" className="text-xs">Faktura adresse</Label>
                                                            <Input id="billing-address" value={billingAddress} onChange={(event) => setBillingAddress(event.target.value)} />
                                                <Label htmlFor="billing-address2" className="text-xs">Adresselinje 2 (valgfri)</Label>
                                                <Input id="billing-address2" value={billingAddress2} onChange={event => setBillingAddress2(event.target.value)} autoComplete="address-line2" />
                                                <Label htmlFor="billing-country" className="text-xs">Land (landekode, fx DK eller SE)</Label>
                                                <Input id="billing-country" value={billingCountry} onChange={event => setBillingCountry(event.target.value)} autoComplete="country" />
                                                        </div>
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="billing-zip" className="text-xs">Faktura postnr.</Label>
                                                                <Input id="billing-zip" value={billingZip} onChange={(event) => setBillingZip(event.target.value)} />
                                                            </div>
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="billing-city" className="text-xs">Faktura by</Label>
                                                                <Input id="billing-city" value={billingCity} onChange={(event) => setBillingCity(event.target.value)} />
                                                            </div>
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </div>

    </div>);
    const contactForm = (<Card onChangeCapture={event => {
        if ((event.target as HTMLInputElement).id?.startsWith("delivery-")) deliveryAddressEditedRef.current = true;
    }} data-branding-id="colors.card" className="order-contact-card overflow-hidden shadow-sm">
                                <CardHeader className="bg-primary/5">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <CardTitle>Kontakt & modtager</CardTitle>
                                            <CardDescription>Vi bruger dine oplysninger til bekræftelse og modtager-adressen til forsendelse.</CardDescription>
                                        </div>
                                        <User className="h-8 w-8 text-primary opacity-20" />
                                    </div>
                                </CardHeader>
                                <CardContent className="pt-6 space-y-4" onFocusCapture={(event) => { if (event.target instanceof HTMLInputElement) setYourDetailsOpen(true); }}>

                                    {/* ──────────────────────────────────────────────────────────────
                                         Step 1 — Dine oplysninger
                                         Collapsed-by-default summary chip when pre-filled from profile.
                                         Clicking the chip expands the 4 input fields. Guests see the
                                         form expanded automatically because there's nothing to summarise.
                                         ────────────────────────────────────────────────────────────── */}
                                    {(() => {
                                        const hasContactSummary = Boolean(customerName.trim() || customerEmail.trim());
                                        const contactExpanded = yourDetailsOpen || !hasContactSummary;
                                        return (
                                            <div className="rounded-lg border border-slate-200 bg-white shadow-sm overflow-hidden">
                                                <button
                                                    type="button"
                                                    className="w-full flex items-center justify-between gap-3 px-4 py-3 hover:bg-slate-50/60"
                                                    onClick={() => setYourDetailsOpen(!yourDetailsOpen)}
                                                >
                                                    <div className="flex items-center gap-3 min-w-0">
                                                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary shrink-0">
                                                            <span className="text-xs font-bold">1</span>
                                                        </div>
                                                        <div className="min-w-0 text-left">
                                                            <p className="text-sm font-semibold text-slate-900">Dine oplysninger</p>
                                                            {hasContactSummary && !contactExpanded ? (
                                                                <p className="text-xs text-muted-foreground truncate">
                                                                    {[customerName, customerEmail, customerCompany].filter(Boolean).join(" · ")}
                                                                </p>
                                                            ) : (
                                                                <p className="text-xs text-muted-foreground">
                                                                    {checkoutUserId ? "Udfyldt fra din profil — klik for at rette" : "Udfyld dine kontaktdetaljer"}
                                                                </p>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <ChevronDown className={`h-4 w-4 text-slate-400 transition-transform ${contactExpanded ? "rotate-180" : ""}`} />
                                                </button>
                                                {contactExpanded && (
                                                    <div className="px-4 pb-4 pt-1 space-y-4 border-t border-slate-100">
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="customer-name" className="text-xs">Bestiller</Label>
                                                                <Input id="customer-name" value={customerName} onChange={(event) => setCustomerName(event.target.value)} />
                                                            </div>
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="customer-email" className="text-xs">E-mail</Label>
                                                                <Input id="customer-email" type="email" value={customerEmail} onChange={(event) => setCustomerEmail(event.target.value)} />
                                                            </div>
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="customer-phone" className="text-xs">Telefon</Label>
                                                                <Input id="customer-phone" value={customerPhone} onChange={(event) => setCustomerPhone(event.target.value)} />
                                                            </div>
                                                            <div className="space-y-1.5">
                                                                <Label htmlFor="customer-company" className="text-xs">Firma</Label>
                                                                <Input id="customer-company" value={customerCompany} onChange={(event) => setCustomerCompany(event.target.value)} />
                                                            </div>
                                                        </div>

                                                        {/* Kundebank (agency/power-user feature) — tucked inside step 1 */}
                                                        {checkoutUserId && savedCustomerProfiles.length > 0 && (
                                                            <details className="rounded-md border border-slate-200 bg-slate-50/60 overflow-hidden">
                                                                <summary className="cursor-pointer px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-100/80">
                                                                    Kundebank — gem & genbrug kundeopsætninger
                                                                </summary>
                                                                <div className="space-y-3 px-3 py-3 border-t border-slate-200">
                                                                    <select
                                                                        value={selectedCustomerProfileId}
                                                                        onChange={async (event) => {
                                                                            const nextValue = event.target.value;
                                                                            setSelectedCustomerProfileId(nextValue);
                                                                            if (nextValue === "new") {
                                                                                setCustomerProfileLabel("");
                                                                                return;
                                                                            }
                                                                            const profile = savedCustomerProfiles.find((entry) => entry.id === nextValue);
                                                                            if (profile) {
                                                                                applyCustomerProfile(profile);
                                                                            }
                                                                        }}
                                                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm"
                                                                    >
                                                                        <option value="new">Ny kundeopsætning</option>
                                                                        {savedCustomerProfiles.map((profile) => (
                                                                            <option key={profile.id} value={profile.id}>
                                                                                {profile.label}
                                                                            </option>
                                                                        ))}
                                                                    </select>
                                                                    <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_auto] gap-2">
                                                                        <Input
                                                                            value={customerProfileLabel}
                                                                            onChange={(event) => setCustomerProfileLabel(event.target.value)}
                                                                            placeholder="Fx Kunde Nordhavn eller Designkunde 12"
                                                                        />
                                                                        <Button
                                                                            type="button"
                                                                            variant="outline"
                                                                            size="sm"
                                                                            onClick={async () => {
                                                                                if (!checkoutUserId) return;
                                                                                const label = customerProfileLabel.trim()
                                                                                    || deliveryCompany.trim()
                                                                                    || deliveryRecipientName.trim()
                                                                                    || customerCompany.trim()
                                                                                    || customerName.trim();
                                                                                if (!label) {
                                                                                    toast.error("Giv kundeprofilen et navn før du gemmer den.");
                                                                                    return;
                                                                                }
                                                                                const profile = await upsertCheckoutCustomerProfile(checkoutUserId, {
                                                                                    id: selectedCustomerProfileId !== "new" ? selectedCustomerProfileId : null,
                                                                                    label,
                                                                                    customerEmail,
                                                                                    customerName,
                                                                                    customerPhone,
                                                                                    customerCompany,
                                                                                    deliveryRecipientName,
                                                                                    deliveryCompany,
                                                                                    deliveryAddress,
                                                                                    deliveryAddress2,
                                                                                    deliveryCountry,
                                                                                    deliveryZip,
                                                                                    deliveryCity,
                                                                                    useSeparateBillingAddress,
                                                                                    billingName,
                                                                                    billingCompany,
                                                                                    billingAddress,
                                                                                    billingAddress2,
                                                                                    billingCountry,
                                                                                    billingZip,
                                                                                    billingCity,
                                                                                    senderMode,
                                                                                    senderName,
                                                                                });
                                                                                if (!profile) {
                                                                                    toast.error("Kundeprofilen kunne ikke gemmes.");
                                                                                    return;
                                                                                }
                                                                                const nextProfiles = await readCheckoutCustomerProfiles(checkoutUserId);
                                                                                setSavedCustomerProfiles(nextProfiles);
                                                                                setSelectedCustomerProfileId(profile.id);
                                                                                setCustomerProfileLabel(profile.label);
                                                                                toast.success("Kundeprofil gemt.");
                                                                            }}
                                                                        >
                                                                            Gem kunde
                                                                        </Button>
                                                                        <Button
                                                                            type="button"
                                                                            variant="ghost"
                                                                            size="sm"
                                                                            disabled={selectedCustomerProfileId === "new"}
                                                                            onClick={async () => {
                                                                                if (!checkoutUserId || selectedCustomerProfileId === "new") return;
                                                                                const ok = await deleteCheckoutCustomerProfile(checkoutUserId, selectedCustomerProfileId);
                                                                                if (!ok) {
                                                                                    toast.error("Kundeprofilen kunne ikke slettes.");
                                                                                    return;
                                                                                }
                                                                                setSavedCustomerProfiles(await readCheckoutCustomerProfiles(checkoutUserId));
                                                                                setSelectedCustomerProfileId("new");
                                                                                setCustomerProfileLabel("");
                                                                                toast.success("Kundeprofil slettet.");
                                                                            }}
                                                                        >
                                                                            Slet
                                                                        </Button>
                                                                    </div>
                                                                </div>
                                                            </details>
                                                        )}
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    })()}

                                    {/* ──────────────────────────────────────────────────────────────
                                         Step 2 — Modtager (main visible step)
                                         "Send til mig selv" toggle at the top. If off, address-book
                                         picker (logged-in) + recipient fields below.
                                         ────────────────────────────────────────────────────────────── */}
                                    <div className="rounded-lg border border-slate-200 bg-white shadow-sm overflow-hidden">
                                        <div className="flex items-center gap-3 px-4 py-3 border-b border-slate-100">
                                            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary shrink-0">
                                                <span className="text-xs font-bold">2</span>
                                            </div>
                                            <div>
                                                <p className="text-sm font-semibold text-slate-900">Modtager</p>
                                                <p className="text-xs text-muted-foreground">Hvor skal pakken sendes hen?</p>
                                            </div>
                                        </div>
                                        <div className="px-4 py-4 space-y-4">
                                            <label className="flex items-start gap-3 rounded-md border border-slate-200 bg-slate-50/60 px-3 py-2.5 cursor-pointer">
                                                <input
                                                    type="checkbox"
                                                    className="mt-1 h-4 w-4 rounded border-slate-300"
                                                    checked={sendToSelf}
                                                    onChange={(event) => handleSendToSelfToggle(event.target.checked)}
                                                />
                                                <div>
                                                    <p className="text-sm font-medium text-slate-900">Send til mig selv</p>
                                                    <p className="text-xs text-muted-foreground">Brug samme navn og firma som dig — du skal kun udfylde adressen.</p>
                                                </div>
                                            </label>

                                            {checkoutUserId && !sendToSelf && savedAddresses.length > 0 && (
                                                <div className="space-y-1.5">
                                                    <Label className="text-xs">Adressebog</Label>
                                                    <select
                                                        value={selectedSavedAddressId}
                                                        onChange={(event) => {
                                                            const nextValue = event.target.value;
                                                            setSelectedSavedAddressId(nextValue);
                                                            if (nextValue === "new") {
                                                                setDeliveryRecipientName("");
                                                                setDeliveryCompany("");
                                                                setDeliveryAddress("");
                                                                setDeliveryZip("");
                                                                setDeliveryCity("");
                                                                setAddressLabel("");
                                                                return;
                                                            }
                                                            const selectedAddress = savedAddresses.find((entry) => entry.id === nextValue);
                                                            if (selectedAddress) {
                                                                applySavedAddress(selectedAddress);
                                                            }
                                                        }}
                                                        className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm shadow-sm"
                                                        disabled={savedAddressesLoading}
                                                    >
                                                        <option value="new">Ny leveringsadresse</option>
                                                        {savedAddresses.map((address) => (
                                                            <option key={address.id} value={address.id}>
                                                                {formatSavedAddressLabel(address)}
                                                            </option>
                                                        ))}
                                                    </select>
                                                    {savedAddressesLoading && (
                                                        <p className="text-xs text-muted-foreground">Henter gemte adresser...</p>
                                                    )}
                                                </div>
                                            )}

                                            {!sendToSelf && (
                                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                    <div className="space-y-1.5">
                                                        <Label htmlFor="delivery-recipient-name" className="text-xs">Modtager navn</Label>
                                                        <Input
                                                            id="delivery-recipient-name"
                                                            value={deliveryRecipientName}
                                                            onChange={(event) => setDeliveryRecipientName(event.target.value)}
                                                        />
                                                    </div>
                                                    <div className="space-y-1.5">
                                                        <Label htmlFor="delivery-company" className="text-xs">Modtager firma</Label>
                                                        <Input
                                                            id="delivery-company"
                                                            value={deliveryCompany}
                                                            onChange={(event) => setDeliveryCompany(event.target.value)}
                                                        />
                                                    </div>
                                                </div>
                                            )}

                                            <div className="space-y-1.5">
                                                <Label htmlFor="delivery-address" className="text-xs">Leveringsadresse</Label>
                                                <Input id="delivery-address" value={deliveryAddress} onChange={(event) => setDeliveryAddress(event.target.value)} />
                                                <Label htmlFor="delivery-address2" className="text-xs">Adresselinje 2 (valgfri)</Label>
                                                <Input id="delivery-address2" value={deliveryAddress2} onChange={event => setDeliveryAddress2(event.target.value)} autoComplete="address-line2" />
                                                <Label htmlFor="delivery-country" className="text-xs">Leveringsland (DK — Danmark)</Label>
                                                <Input id="delivery-country" value={deliveryCountry} onChange={event => setDeliveryCountry(event.target.value)} autoComplete="country" />
                                                <p className="text-xs text-muted-foreground">Vi leverer i øjeblikket kun til Danmark. Prisen ved betaling inkluderer 25 % moms.</p>
                                            </div>

                                            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                                <div className="space-y-1.5">
                                                    <Label htmlFor="delivery-zip" className="text-xs">Postnr.</Label>
                                                    <Input id="delivery-zip" value={deliveryZip} onChange={(event) => setDeliveryZip(event.target.value)} />
                                                </div>
                                                <div className="space-y-1.5">
                                                    <Label htmlFor="delivery-city" className="text-xs">By</Label>
                                                    <Input id="delivery-city" value={deliveryCity} onChange={(event) => setDeliveryCity(event.target.value)} />
                                                </div>
                                            </div>

                                            {checkoutUserId && (
                                                <label className="flex items-start gap-3">
                                                    <input
                                                        type="checkbox"
                                                        className="mt-1 h-4 w-4 rounded border-slate-300"
                                                        checked={saveAddressForLater}
                                                        onChange={(event) => setSaveAddressForLater(event.target.checked)}
                                                    />
                                                    <div>
                                                        <p className="text-sm font-medium text-slate-900">Gem modtager i adressebog</p>
                                                        <p className="text-xs text-muted-foreground">Så kan du hurtigt vælge adressen igen næste gang.</p>
                                                    </div>
                                                </label>
                                            )}

                                            {checkoutUserId && saveAddressForLater && (
                                                <div className="space-y-1.5 pl-7">
                                                    <Label htmlFor="address-label" className="text-xs">Adresselabel</Label>
                                                    <Input
                                                        id="address-label"
                                                        value={addressLabel}
                                                        onChange={(event) => setAddressLabel(event.target.value)}
                                                        placeholder="Fx Kunde Aarhus eller Studio kunde 3"
                                                    />
                                                </div>
                                            )}
                                        </div>
                                    </div>

                                    {checkoutDesign === 4 && advancedForm}
                                </CardContent>
                            </Card>);
    const fileForm = (<Card data-branding-id="colors.card" className="order-file-card overflow-hidden shadow-sm">
                                <CardHeader className="bg-primary/5">
                                    <div className="flex items-center justify-between">
                                        <div>
                                            <CardTitle>{checkoutUploadTitle}</CardTitle>
                                            <CardDescription>{checkoutUploadHelpText}</CardDescription>
                                        </div>
                                        {uploading ? (
                                            <Loader2 className="h-8 w-8 animate-spin text-primary/70" />
                                        ) : (
                                            <FileText className="h-8 w-8 text-primary opacity-20" />
                                        )}
                                    </div>
                                </CardHeader>
                                <CardContent className="order-file-content pt-6 space-y-6">

<details className="order-flow-help"><summary>Filkrav og skabelon</summary>                                    <div className={`rounded-lg border px-4 py-3 text-sm ${checkoutFlowNoticeClasses[checkoutFlowNotice.tone]}`}>
                                        <div className="flex items-start gap-3">
                                            <Sparkles className="mt-0.5 h-4 w-4 shrink-0" />
                                            <div className="min-w-0 flex-1">
                                                <p className="font-semibold">{checkoutFlowNotice.title}</p>
                                                <p className="mt-1 text-xs leading-5 opacity-80">{checkoutFlowNotice.body}</p>
                                            </div>
                                            <div className="hidden shrink-0 flex-col gap-2 md:flex">
                                                {checkoutTemplatePdfUrl && (
                                                    <Button
                                                        asChild
                                                        type="button"
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-9 bg-white/80"
                                                    >
                                                        <a
                                                            href={checkoutTemplatePdfUrl}
                                                            download={checkoutTemplateDownloadName}
                                                            target="_blank"
                                                            rel="noopener noreferrer"
                                                            onClick={markTemplateDownloaded}
                                                        >
                                                            <Download className="mr-2 h-4 w-4" />
                                                            Download skabelon
                                                        </a>
                                                    </Button>
                                                )}
                                                {checkoutFlowNotice.showDesignerAction && (
                                                    <Button
                                                        type="button"
                                                        variant="outline"
                                                        size="sm"
                                                        className="h-9 bg-white/80"
                                                        onClick={handleOpenFullDesigner}
                                                    >
                                                        {checkoutFlowNotice.designerActionLabel}
                                                    </Button>
                                                )}
                                            </div>
                                        </div>
                                        <div className="mt-3 grid gap-2 md:hidden">
                                            {checkoutTemplatePdfUrl && (
                                                <Button
                                                    asChild
                                                    type="button"
                                                    variant="outline"
                                                    size="sm"
                                                    className="h-10 w-full bg-white/80"
                                                >
                                                    <a
                                                        href={checkoutTemplatePdfUrl}
                                                        download={checkoutTemplateDownloadName}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        onClick={markTemplateDownloaded}
                                                    >
                                                        <Download className="mr-2 h-4 w-4" />
                                                        Download skabelon
                                                    </a>
                                                </Button>
                                            )}
                                            {checkoutFlowNotice.showDesignerAction && (
                                                <Button
                                                    type="button"
                                                    variant="outline"
                                                    size="sm"
                                                    className="h-10 w-full bg-white/80"
                                                    onClick={handleOpenFullDesigner}
                                                >
                                                    {checkoutFlowNotice.designerActionLabel}
                                                </Button>
                                            )}
                                        </div>
                                    </div></details>

                                    {!uploadedFile ? (
                                        <div
                                            className={`cursor-pointer rounded-xl border-2 border-dashed px-6 py-8 text-center transition-all group shadow-sm ${
                                                uploadDropActive
                                                    ? "border-primary bg-primary/10 ring-2 ring-primary/20"
                                                    : "border-primary/20 hover:bg-primary/5"
                                            }`}
                                            onClick={() => { if (!uploading) fileInputRef.current?.click(); }}
                                            onDragOver={handleUploadDragOver}
                                            onDragEnter={handleUploadDragOver}
                                            onDragLeave={handleUploadDragLeave}
                                            onDrop={handleUploadDrop}
                                        >
                                            {uploading ? <FileUploadProgress progress={uploadProgress} /> : <div className="flex flex-col items-center">
                                                <div className={`mb-3 flex h-12 w-12 items-center justify-center rounded-full transition-transform ${
                                                    uploadDropActive ? "bg-primary/20 scale-110" : "bg-primary/10 group-hover:scale-110"
                                                }`}>
                                                    <Upload className="h-6 w-6 text-primary" />
                                                </div>
                                                <h3 className="mb-1 text-base font-semibold">
                                                    {uploadDropActive ? "Slip filen her" : "Klik eller træk fil hertil"}
                                                </h3>
                                                <p className="mx-auto max-w-xs text-xs text-muted-foreground">
                                                    PDF, JPG, PNG eller TIFF. Maksimal filstørrelse {CHECKOUT_UPLOAD_LIMIT_LABEL}. Brug PDF når produktet har foldelinjer, skabelon eller CutContour.
                                                </p>
                                                <StorefrontPrimaryButton type="button" disabled={uploading || exportingProof} className="mt-4" onClick={(event) => { event.stopPropagation(); fileInputRef.current?.click(); }}>Vælg fil</StorefrontPrimaryButton>
                                                {checkoutFlowNotice.showDesignerAction && <Button type="button" disabled={uploading || exportingProof} variant="link" className="mt-1" onClick={(event) => { event.stopPropagation(); handleOpenFullDesigner(); }}>Design online</Button>}

                                            </div>}
                                            <input
                                                type="file"
                                                ref={fileInputRef}
                                                disabled={uploading || exportingProof}
                                                className="hidden"
                                                onChange={handleFileUpload}
                                                accept=".pdf,.jpg,.jpeg,.png,.tiff"
                                            />
                                        </div>
                                    ) : (
                                        <div className="space-y-6">
                                            <div className="flex flex-col gap-3 rounded-lg border border-green-100 bg-green-50 p-4 shadow-sm sm:flex-row sm:items-center sm:justify-between">
                                                <div className="flex min-w-0 items-center gap-3">
                                                    <CheckCircle2 className="h-6 w-6 shrink-0 text-green-600" />
                                                    <div className="min-w-0">
                                                        <p className="break-words text-sm font-semibold text-green-900 sm:text-base">
                                                            {uploadedFile.name}
                                                        </p>
                                                        <p className="text-xs text-green-700">
                                                            {activeDesignerProductionFile
                                                                ? "Genereret i designeren og klar til ordre"
                                                                : proofArtifactApproved
                                                                    ? "Godkendt til ordre"
                                                                    : "Klar til korrektur"}
                                                        </p>
                                                    </div>
                                                </div>
                                                <div className="flex w-full flex-wrap items-center justify-between gap-x-3 gap-y-2 text-xs sm:w-auto sm:justify-end">
                                                    <span className="font-medium text-green-900">
                                                        {proofingApprovalLabel}
                                                    </span>
                                                    {(proofingPreview || activeDesignerProductionFile) && (
                                                        <span className="text-slate-600">
                                                            {proofingFileKindLabel}
                                                        </span>
                                                    )}
                                                    <Button
                                                        variant="ghost"
                                                        size="sm"
                                                        disabled={uploading || exportingProof}
                                                        onClick={() => {
                                                            if (state?.productId) {
                                                                clearSiteCheckoutDesignReady(state.productId);
                                                            }
                                                            const existingSession = readSiteCheckoutSession();
                                                            if (existingSession?.designerExport) {
                                                                writeSiteCheckoutSession({
                                                                    ...existingSession,
                                                                    designerExport: null,
                                                                });
                                                            }
                                                            setUploadedFile(null);
                                                            setPreviewUrl(null);
                                                            setProofingPreview(null);
                                                            setProofingApproved(false);
                                                            setProofingOpen(false);
                                                            setPreflightResults(null);
                                                            setPlatformPreflight(null);
                                                            resetProofingAdjustments();
                                                        }}
                                                    >
                                                        Skift fil
                                                    </Button>
                                                </div>
                                            </div>

                                            {previewUrl && (
                                                <div className="border border-slate-200 bg-white p-4 shadow-inner">
                                                    {approvedPrintModel && proofingPreview && uploadedFile && (
                                                        <div className="mb-3">
                                                            <PrintMockupButton key={currentProofIdentity || proofingPreview.previewUrl}
                                                                model={approvedPrintModel} brandingOverride={branding}
                                                                disabled={uploading || exportingProof}
                                                                getArtwork={async () => {
                                                                    const source = await readCheckoutUpload(supabase, uploadedFile.path);
                                                                    if (await hashCheckoutArtifact(source) !== uploadedFile.sha256)
                                                                        throw new Error('Trykfilen er ændret. Upload den aktuelle fil igen.');
                                                                    if (approvedPrintModel.kind === 'flat' && proofingPreview.fileType === 'image') {
                                                                        return { outside: await composeFolderArtwork(proofingPreview.previewUrl, {
                                                                            physicalWidthMm: proofingPreview.physicalWidthMm,
                                                                            physicalHeightMm: proofingPreview.physicalHeightMm,
                                                                            scale: proofingScaleFactor, offsetXPercent: proofingOffset.x, offsetYPercent: proofingOffset.y,
                                                                        }, approvedPrintModel.definition) };
                                                                    }
                                                                    const artwork = await preparePrintModelPdf(new File([source], uploadedFile.name, { type: source.type }), approvedPrintModel);
                                                                    return placePrintArtwork(artwork, {
                                                                        physicalWidthMm: proofingPreview.physicalWidthMm,
                                                                        physicalHeightMm: proofingPreview.physicalHeightMm,
                                                                        scale: proofingScaleFactor, offsetXPercent: proofingOffset.x, offsetYPercent: proofingOffset.y,
                                                                    }, approvedPrintModel);
                                                                }} />
                                                        </div>
                                                    )}
                                                    {folderMockupDefinition && proofingPreview && (
                                                        <div className="mb-3">
                                                            <FolderMockupButton
                                                                key={currentProofIdentity || proofingPreview.previewUrl}
                                                                definition={folderMockupDefinition}
                                                                disabled={uploading || exportingProof}
                                                                getArtwork={() => composeFolderArtwork(proofingPreview.previewUrl, {
                                                                    physicalWidthMm: proofingPreview.physicalWidthMm,
                                                                    physicalHeightMm: proofingPreview.physicalHeightMm,
                                                                    scale: proofingScaleFactor,
                                                                    offsetXPercent: proofingOffset.x,
                                                                    offsetYPercent: proofingOffset.y,
                                                                }, folderMockupDefinition)}
                                                            />
                                                        </div>
                                                    )}
                                                    <FileProofActions
                                                        key={currentProofIdentity || 'empty'}
                                                        approved={proofArtifactApproved}
                                                        canApprove={canApproveHere}
                                                        busy={exportingProof}
                                                        issues={outsideProofIssues}
                                                        warningsAccepted={printWarningsAccepted}
                                                        onWarningsAcceptedChange={acceptPrintWarnings}
                                                        acknowledgementLabel={printAcknowledgementLabel}
                                                        canReview={proofAvailability.canReview}
                                                        quickApproveAvailable={quickApproveAvailable}
                                                        onApprove={handleApproveProofing}
                                                        onReview={() => setProofingOpen(true)}
                                                        onContinue={handleContinueToCheckout}
                                                    />
                                                    <div className="mb-3 flex flex-wrap items-center justify-between gap-2 text-[11px] uppercase tracking-[0.12em] text-slate-500">
                                                        <span className="font-semibold text-slate-700">
                                                            Visuel preview
                                                        </span>
                                                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
                                                            <span className={proofArtifactApproved ? "text-green-700" : "text-amber-700"}>
                                                                {proofingApprovalLabel}
                                                            </span>
                                                            {proofingPreview && (
                                                                <span className="text-slate-500">
                                                                    {proofingFileKindLabel}
                                                                </span>
                                                            )}
                                                        </div>
                                                    </div>
                                                    <div className="mx-auto flex w-full max-w-md justify-center">
                                                        <div className="relative w-full">
                                                            <div
                                                                className="relative w-full overflow-hidden border border-slate-300 bg-white"
                                                                style={{ aspectRatio: targetWidth > 0 && targetHeight > 0 ? `${targetWidth} / ${targetHeight}` : "1 / 1" }}
                                                            >
                                                                {linkedTemplatePreview && (
                                                                    <div className="absolute inset-0">
                                                                        <img
                                                                            src={linkedTemplatePreview.previewUrl}
                                                                            alt="Template preview"
                                                                            className="h-full w-full object-contain select-none"
                                                                            draggable={false}
                                                                        />
                                                                    </div>
                                                                )}
                                                                {proofingPreview && (
                                                                    <div
                                                                        className="absolute"
                                                                        style={{
                                                                            width: `${proofingBaseWidthPercent}%`,
                                                                            height: `${proofingBaseHeightPercent}%`,
                                                                            left: `${50 + proofingOffset.x}%`,
                                                                            top: `${50 + proofingOffset.y}%`,
                                                                            transform: `translate(-50%, -50%) scale(${proofingScaleFactor})`,
                                                                            transformOrigin: "center center",
                                                                        }}
                                                                    >
                                                                        <img
                                                                            src={proofingPreview.previewUrl}
                                                                            alt="Preview"
                                                                            className="h-full w-full object-contain select-none"
                                                                            draggable={false}
                                                                        />
                                                                    </div>
                                                                )}
                                                                {specs && (
                                                                    <>
                                                                        <div
                                                                            className="absolute inset-0 z-20 border-2 border-dashed border-red-500/90 pointer-events-none"
                                                                            style={{
                                                                                top: `${bleedYPercent}%`,
                                                                                bottom: `${bleedYPercent}%`,
                                                                                left: `${bleedXPercent}%`,
                                                                                right: `${bleedXPercent}%`,
                                                                            }}
                                                                        />
                                                                        <div
                                                                            className="absolute inset-0 z-20 border border-emerald-500/90 pointer-events-none"
                                                                            style={{
                                                                                top: `${safeYPercent}%`,
                                                                                bottom: `${safeYPercent}%`,
                                                                                left: `${safeXPercent}%`,
                                                                                right: `${safeXPercent}%`,
                                                                            }}
                                                                        />
                                                                    </>
                                                                )}
                                                            </div>
                                                            {specs && (
                                                                <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-600">
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 bg-red-500" />
                                                                        <span>Beskæringslinje ({specs?.bleed_mm || 0}mm)</span>
                                                                    </div>
                                                                    <div className="flex items-center gap-2">
                                                                        <span className="h-2 w-2 bg-emerald-500" />
                                                                        <span>Sikkerhedszone ({safeAreaMm}mm)</span>
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>
                                                    </div>
                                                    {requiresCutContour && (proofingPreview?.fileType === "pdf" || proofingPreview?.fileType === "image") && (
                                                        <div className={`mt-4 rounded-lg border px-3 py-3 text-sm ${
                                                            proofingPreview?.fileType === "pdf"
                                                                ? (pdfContourScan?.cutContourNameDetected ? "border-green-200 bg-green-50" : "border-slate-200 bg-slate-50")
                                                                : "border-amber-200 bg-amber-50"
                                                        }`}>
                                                            <p className="font-medium text-slate-900">
                                                                {proofingPreview?.fileType === "pdf" ? "PDF / CutContour scan" : "Rasterfil"}
                                                            </p>
                                                            {proofingPreview?.fileType === "pdf" ? (
                                                                <>
                                                                    <p className="mt-1 text-xs text-slate-700">
                                                                        {pdfContourScan?.summary || "PDF uploadet. CutContour-scannen kører."}
                                                                    </p>
                                                                    <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-slate-600">
                                                                        <span>
                                                                            Spotfarve: {pdfContourScan?.separationHintDetected ? "indikation fundet" : "ikke bekræftet"}
                                                                        </span>
                                                                        <span>
                                                                            Overprint: {pdfContourScan?.overprintHintDetected ? "indikation fundet" : "ikke bekræftet"}
                                                                        </span>
                                                                    </div>
                                                                    <p className="mt-2 text-xs text-slate-500">
                                                                        {pdfContourScan?.note}
                                                                    </p>
                                                                </>
                                                            ) : (
                                                                <p className="mt-1 text-xs text-amber-700">
                                                                    Rasterfiler kan ikke verificeres som ægte CutContour her. Brug fuld designer hvis produktet kræver konturskæring.
                                                                </p>
                                                            )}
                                                        </div>
                                                    )}
                                                </div>
                                            )}

                                            {preflightResults && (
                                                <div className={`rounded-xl border-2 p-6 shadow-sm ${preflightResults.issues.length === 0 ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}`}>
                                                    <div className="flex items-center gap-2 mb-4">
                                                        {preflightResults.issues.length === 0 ? (
                                                            <CheckCircle2 className="h-6 w-6 text-green-600" />
                                                        ) : (
                                                            <AlertCircle className="h-6 w-6 text-amber-600" />
                                                        )}
                                                        <h3 className="text-base font-semibold">
                                                            {preflightResults.issues.length === 0 ? 'Det automatiske filtjek er gennemført' : 'Din fil kræver gennemgang'}
                                                        </h3>
                                                    </div>

                                                    {preflightResults.issues.length > 0 && (
                                                        <ul className="space-y-2 mb-4">
                                                            {preflightResults.issues.map((issue, idx) => (
                                                                <li key={idx} className="flex gap-2 text-sm text-amber-900">
                                                                    <span className="shrink-0">•</span>
                                                                    <span>{issue}</span>
                                                                </li>
                                                            ))}
                                                        </ul>
                                                    )}

                                                    <div className="mt-4 grid grid-cols-1 gap-3">
                                                        <div className="rounded-lg border border-black/5 bg-white/50 p-3 shadow-sm">
                                                            <p className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Opløsning</p>
                                                            <p className={`text-sm font-semibold ${preflightResults.dpiOk ? 'text-green-600' : 'text-amber-600'}`}>
                                                                {proofingPreview?.fileType === "image"
                                                                    ? `Ca. ${proofingEffectiveDpi || specs?.min_dpi || 300} DPI ved nuværende størrelse`
                                                                    : 'PDF / vektorbaseret preview'}
                                                            </p>
                                                        </div>
                                                        <div className="rounded-lg border border-black/5 bg-white/50 p-3 shadow-sm">
                                                            <p className="text-xs text-muted-foreground uppercase tracking-wider font-bold">Target Størrelse</p>
                                                            <p className="text-sm font-semibold text-slate-700">
                                                                {targetWidth} x {targetHeight} mm
                                                            </p>
                                                        </div>
                                                    </div>

                                                    {preflightResults.issues.length > 0 && (
                                                        <div className="mt-5 flex flex-wrap items-center gap-2">
                                                            <Button
                                                                variant="outline"
                                                                size="sm"
                                                                className="bg-white px-3 text-xs sm:text-sm"
                                                                onClick={() => { if (!uploading) fileInputRef.current?.click(); }}
                                                            >
                                                                Upload ny fil
                                                            </Button>
                                                            <Button size="sm" className="px-3 text-xs sm:text-sm">
                                                                Fortsæt alligevel
                                                            </Button>
                                                        </div>
                                                    )}
                                                </div>
                                            )}

                                            {/*
                                                Server-side preflight (pod2-pdf-preflight) still runs in the background
                                                so its autoFix path can silently repair the uploaded PDF, but we no longer
                                                surface its messages to the customer. All visible feedback comes from our
                                                own local size checks above; source colour needs production preflight.
                                            */}
                                        </div>
                                    )}
                                    {checkoutFormatGuideData ? (
                                        <ProductFormatGuidePanel
                                            data={checkoutFormatGuideData}
                                            className="border-t border-slate-200 pt-6"
                                        />
                                    ) : null}
                                </CardContent>
                            </Card>);
    return (
        <StorefrontThemeFrame
            branding={branding}
            orderDesign={checkoutDesign}
            tenantName={tenantName}
        >
            <main
                className="storefront-order-flow storefront-checkout-flow flex-1 container mx-auto px-4 py-12"
                data-storefront-order-flow="checkout"
                data-branding-id="colors.background"
            >
                <OrderDesignPreviewSwitch page="checkout" value={checkoutDesign} />
                {draftFlow && <div role="status" className="mb-6 rounded-lg border bg-muted p-4 text-sm">{DRAFT_FLOW_MESSAGE}</div>}
                {!draftFlow && !paymentSuccess && (orderPersistWarning || hasCheckoutRecovery || recoverablePaymentId || finalizingPayment) && (
                    <div role="status" className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-950">
                        <p>{finalizingPayment ? "Kontrollerer betaling og gemt ordre…" : orderPersistWarning || "Du har en påbegyndt betaling. Kontrollér den, før du starter en ny."}</p>
                        <div className="mt-3 flex flex-wrap gap-2">
                            <Button type="button" variant="outline" disabled={finalizingPayment || paymentLoading} onClick={() => void handlePaymentSuccess()}>Kontrollér betaling og ordre</Button>
                            <Button type="button" variant="outline" disabled={finalizingPayment || paymentLoading} onClick={() => void cancelPendingPayment()}>Annuller påbegyndt betaling</Button>
                        </div>
                    </div>
                )}
                <OrderCheckoutLayout design={checkoutDesign} onBack={handleBackToConfiguration}
                    contactSummary={[customerName, customerEmail].filter(Boolean).join(' · ')}
                    contact={contactForm} file={fileForm} summary={orderSummary}
                    delivery={activeDeliveryMethods.length ? deliveryForm : null}
                    deliverySummary={`${activeDeliveryMethods.find(method => method.id === shippingSelected)?.name || 'Levering'} · ${shippingCost} kr`}
                    advanced={advancedForm}
                    extras={<CheckoutProductValue name={displayProductName} imageUrl={product?.image_url}
                        settings={String(state?.summary || '').split('•').map((part: string) => part.trim()).filter((part: string) => part && part !== displayProductName && !/^[\d., ]+\s*stk\.?$/i.test(part))}
                        quantity={orderQuantity} price={orderPrice} tiers={quantityTiers}
                        onEdit={handleEditProduct} onSelect={handleUpgrade} />}

                />
            </main>
            <Dialog open={proofingOpen} onOpenChange={setProofingOpen}>
                <PrintJourneyDialogContent className="order-proof-dialog max-w-6xl p-0 overflow-hidden" data-order-design={proofDesign}
                    onCloseAutoFocus={event => {
                        if (!returnToCheckoutAfterProofRef.current) return;
                        event.preventDefault();
                        returnToCheckoutAfterProofRef.current = false;
                        handleContinueToCheckout();
                    }}>
                    <DialogHeader className="border-b border-slate-200 px-6 py-4">
                        <DialogTitle>Filkorrektur</DialogTitle>
                        <DialogDescription>
                            Kontrollér filens størrelse, bleed og placering før du fortsætter til betaling.
                        </DialogDescription>
                    </DialogHeader>

                    <OrderDesignPreviewSwitch page="proof" value={proofDesign} />
                    <ProofReviewLayout design={proofDesign}
                        canvas={                        <div className="order-proof-canvas bg-white p-6">
                            <div className="mb-4 flex flex-wrap items-center justify-between gap-3 text-white/80">
                                <div>
                                    <p className="text-sm font-semibold text-slate-900">
                                        {proofingPreview?.fileType === "pdf" ? "PDF korrektur" : "Billedkorrektur"}
                                    </p>
                                    <p className="text-xs text-slate-500">
                                        Træk motivet for at justere placering. Brug hjørnehåndtagene til at tilpasse størrelsen.
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Button type="button" variant="secondary" size="sm" onClick={resetProofingAdjustments}>
                                        <RotateCcw className="mr-2 h-4 w-4" />
                                        Nulstil
                                    </Button>
                                </div>
                            </div>

                            <div className="mx-auto flex w-full max-w-3xl justify-center">
                                <div className="relative w-full">
                                    <div
                                        ref={proofingArtboardRef}
                                        className={`relative w-full overflow-hidden border border-slate-300 bg-white shadow-2xl ${proofingPreview ? "cursor-grab active:cursor-grabbing" : ""}`}
                                        onMouseDown={handleProofingArtboardPointerDown}
                                        style={{ aspectRatio: targetWidth > 0 && targetHeight > 0 ? `${targetWidth} / ${targetHeight}` : "1 / 1" }}
                                    >
                                        {linkedTemplatePreview && (
                                            <div className="absolute inset-0">
                                                <img
                                                    src={linkedTemplatePreview.previewUrl}
                                                    alt="Template preview"
                                                    className="h-full w-full object-contain select-none"
                                                    draggable={false}
                                                />
                                            </div>
                                        )}
                                        {proofingPreview && (
                                            <div
                                                ref={proofingArtworkRef}
                                                className="absolute"
                                                onMouseDown={handleProofingPointerDown}
                                                style={{
                                                    left: `${50 + proofingOffset.x}%`,
                                                    top: `${50 + proofingOffset.y}%`,
                                                    width: `${proofingBaseWidthPercent}%`,
                                                    height: `${proofingBaseHeightPercent}%`,
                                                    transform: `translate(-50%, -50%) scale(${proofingScaleFactor})`,
                                                    transformOrigin: "center center",
                                                }}
                                            >
                                                    <img
                                                        src={proofingPreview.previewUrl}
                                                        alt="Korrektur preview"
                                                        className="h-full w-full select-none object-contain"
                                                        draggable={false}
                                                    />
                                                    {PROOFING_HANDLE_POSITIONS.map((handle, index) => (
                                                        <div
                                                            key={handle.key}
                                                            className="absolute"
                                                            style={{
                                                                left: handle.left,
                                                                right: handle.right,
                                                                top: handle.top,
                                                                bottom: handle.bottom,
                                                                transform: handle.translate,
                                                            }}
                                                        >
                                                            <button
                                                                type="button"
                                                                aria-label={`Skaler motiv ${index + 1}`}
                                                                onMouseDown={handleProofingResizeStart}
                                                                className="h-4 w-4 border border-white bg-primary shadow-sm"
                                                                style={{
                                                                    transform: `scale(${1 / Math.max(proofingScaleFactor, 0.01)})`,
                                                                    transformOrigin: "center center",
                                                                    cursor: handle.cursor,
                                                                }}
                                                            />
                                                        </div>
                                                    ))}
                                                </div>
                                        )}

                                        <div
                                            className="absolute inset-0 border-2 border-dashed border-red-400/90 pointer-events-none z-20"
                                            style={{
                                                top: `${bleedYPercent}%`,
                                                bottom: `${bleedYPercent}%`,
                                                left: `${bleedXPercent}%`,
                                                right: `${bleedXPercent}%`,
                                            }}
                                        />
                                        <div
                                            className="absolute inset-0 border border-emerald-300/95 pointer-events-none z-20"
                                            style={{
                                                top: `${safeYPercent}%`,
                                                bottom: `${safeYPercent}%`,
                                                left: `${safeXPercent}%`,
                                                right: `${safeXPercent}%`,
                                            }}
                                        />
                                    </div>
                                    <div className="mt-3 flex flex-wrap items-center justify-between gap-3 text-[11px] font-semibold uppercase tracking-[0.08em] text-slate-600">
                                        <div className="flex items-center gap-2">
                                            <span className="h-2 w-2 bg-red-500" />
                                            <span>Beskæringslinje ({specs?.bleed_mm || 0}mm)</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="h-2 w-2 bg-emerald-500" />
                                            <span>Sikkerhedszone ({safeAreaMm}mm)</span>
                                        </div>
                                        <div className="text-slate-500">
                                            Artboard: {Math.round(targetWidth)} × {Math.round(targetHeight)} mm
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>}
                        status={<div className="order-proof-status space-y-5 bg-white p-6">
                            <div className="space-y-2">
                                <p className="text-sm font-semibold text-slate-900">Filstatus</p>
                                <div className={`rounded-lg border px-3 py-3 text-sm ${!preflightResults && !activeDesignerProductionFile ? "border-slate-200 bg-slate-50 text-slate-700" : originalFilePrimaryIssue ? "border-amber-200 bg-amber-50 text-amber-900" : "border-green-200 bg-green-50 text-green-900"}`}>
                                    <p className="font-medium">
                                        {!preflightResults && !activeDesignerProductionFile ? "Originalfil: ikke tjekket i denne session" : originalFilePrimaryIssue ? "Originalfil: tjek" : "Originalfil: ok"}
                                    </p>
                                    <p className="mt-1 text-xs">
                                        {!preflightResults && !activeDesignerProductionFile
                                            ? "Kontrollér den gemte fil manuelt, eller upload den igen for et nyt filtjek."
                                            : originalFilePrimaryIssue || `${proofingFileKindLabel}. Filformatet ser korrekt ud.`}
                                    </p>
                                </div>
                                {proofingDpiWarning && (
                                    <p className="text-xs text-amber-700">
                                        Rasterfilen er under {specs?.min_dpi} DPI ved den nuværende størrelse.
                                    </p>
                                )}
                                {proofingPhysicalMismatch && (
                                    <p className="text-xs text-amber-700">
                                        Filen er fysisk mindre end det bestilte layout. Den vises proportionelt i artboardet, så du kan se den reelle dækning.
                                    </p>
                                )}
                                <div className={`rounded-lg border px-3 py-3 text-sm ${proofingPlacementPrimaryIssue ? "border-amber-200 bg-amber-50 text-amber-900" : "border-green-200 bg-green-50 text-green-900"}`}>
                                    <p className="font-medium">
                                        {proofingPlacementPrimaryIssue ? "Placering: kontrollér og godkend" : "Placering: ok"}
                                    </p>
                                    <p className="mt-1 text-xs">
                                        {proofingPlacementPrimaryIssue || "Placeringen ser korrekt ud i previewet."}
                                    </p>
                                </div>
                                {requiresCutContour && proofingPreview?.fileType === "pdf" && (
                                    <div className={`rounded-lg border px-3 py-3 text-sm ${
                                        pdfContourScan?.cutContourNameDetected
                                            ? "border-green-200 bg-green-50 text-green-900"
                                            : "border-slate-200 bg-slate-50 text-slate-900"
                                    }`}>
                                        <p className="font-medium">
                                            {pdfContourScan?.cutContourNameDetected ? "CutContour: fundet" : "CutContour: ikke bekræftet"}
                                        </p>
                                        <p className="mt-1 text-xs">
                                            {pdfContourScan?.summary || "PDF uploadet. CutContour-scannen kører."}
                                        </p>
                                        <div className="mt-2 grid grid-cols-1 gap-1 text-xs">
                                            <p>Spotfarve/separation: {pdfContourScan?.separationHintDetected ? "indikation fundet" : "ikke bekræftet"}</p>
                                            <p>Overprint: {pdfContourScan?.overprintHintDetected ? "indikation fundet" : "ikke bekræftet"}</p>
                                        </div>
                                        <p className="mt-2 text-xs text-slate-500">
                                            {pdfContourScan?.note}
                                        </p>
                                    </div>
                                )}
                                {requiresCutContour && proofingPreview?.fileType === "image" && (
                                    <div className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-3 text-sm text-amber-900">
                                        <p className="font-medium">Rasterfil</p>
                                        <p className="mt-1 text-xs">
                                            Rasterfiler kan ikke verificeres som ægte CutContour her. Brug fuld designer hvis produktet kræver konturskæring.
                                        </p>
                                    </div>
                                )}
                            </div>

                            <div className="space-y-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-4 shadow-sm">
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Produktformat</p>
                                    <p className="text-sm font-medium text-slate-900">{Math.round(targetWidth)} × {Math.round(targetHeight)} mm inkl. bleed</p>
                                </div>
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Uploadet fil</p>
                                    <p className="text-sm font-medium text-slate-900">
                                        {proofingPreview ? `${Math.round(proofingPreview.physicalWidthMm)} × ${Math.round(proofingPreview.physicalHeightMm)} mm` : "Beregnede mål"}
                                    </p>
                                    <p className="text-xs text-slate-500">{proofingFileKindLabel}</p>
                                    {proofingPreview?.pageCount && (
                                        <p className="text-xs text-slate-500">PDF preview viser side 1 af {proofingPreview.pageCount}</p>
                                    )}
                                </div>
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Opløsning</p>
                                    <p className="text-sm font-medium text-slate-900">
                                        {proofingPreview?.fileType === "image"
                                            ? `${proofingEffectiveDpi || specs?.min_dpi || 300} DPI ved nuværende størrelse`
                                            : "PDF / vektorbaseret preview"}
                                    </p>
                                    {proofingEffectiveDpi && proofingScale !== 100 && (
                                        <p className="text-xs text-slate-500">
                                            Effektiv opløsning ved nuværende skalering: ca. {proofingEffectiveDpi} DPI
                                        </p>
                                    )}
                                </div>
                                <div>
                                    <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Sikkerhedszone</p>
                                    <p className="text-sm font-medium text-slate-900">
                                        {safeAreaMm} mm inden for beskæringslinjen
                                    </p>
                                </div>
                                <div>
                                    <p className="text-xs text-slate-500">
                                        {checkoutUploadHelpText} Denne korrektur viser størrelse, bleed og sikkerhedszone.
                                    </p>
                                </div>
                            </div>

                            {proofNeedsExport && !canExportImageHere && proofAvailability.canReview && (
                                <div role="status" className="rounded-lg border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950">
                                    <p className="font-medium">Filen kræver klargøring før ordre</p>
                                    <p className="mt-1">
                                        Den viste størrelse eller placering er ikke gemt i trykfilen. Nulstil eventuelle justeringer,
                                        eller upload en trykklar PDF i produktets mål inklusive bleed.
                                        {checkoutFlowNotice.showDesignerAction && " Du kan også selv vælge designeren nedenfor."}
                                    </p>
                                </div>
                            )}
                            <div className="flex flex-col gap-2 pt-2">
                                {proofNeedsExport && !canExportImageHere && proofAvailability.canReview ? (
                                    <Button type="button" variant="outline" onClick={() => { setProofingOpen(false); fileInputRef.current?.click(); }}>
                                        Upload ny trykfil
                                    </Button>
                                ) : (
                                    <PrintWarningAcknowledgement issues={outsideProofIssues} accepted={printWarningsAccepted}
                                        onChange={acceptPrintWarnings} label={printAcknowledgementLabel} />
                                )}
                                {!(proofNeedsExport && !canExportImageHere && proofAvailability.canReview) && (
                                    <StorefrontPrimaryButton type="button" disabled={!canApproveHere || exportingProof || !printWarningsAccepted} onClick={handleApproveProofing}>
                                        Godkend fil og fortsæt
                                    </StorefrontPrimaryButton>
                                )}
                                {checkoutFlowNotice.showDesignerAction && (
                                    <Button type="button" variant="outline" onClick={handleOpenFullDesigner}>
                                        {checkoutFlowNotice.designerActionLabel}
                                    </Button>
                                )}
                                <Button type="button" variant="outline" onClick={() => setProofingOpen(false)}>
                                    Luk korrektur
                                </Button>
                            </div>
                        </div>}
                    />
                </PrintJourneyDialogContent>
            </Dialog>

            {showPaymentModal && paymentClientSecret && (
                <OrderFlowDialog open onClose={handlePaymentCancel} title="Betaling" design={paymentDesign} shopName={tenantName}>
                    <OrderPaymentLayout design={paymentDesign} receipt={receipt} onBack={handlePaymentCancel}
                        form={                        <StripePaymentForm
                            clientSecret={paymentClientSecret}
                            amount={checkoutTotal}
                            currency="dkk"
                            onSuccess={handlePaymentSuccess}
                            onCancel={handlePaymentCancel}
                            connectedAccountId={paymentConnectedAccountId}
                        />} />
                </OrderFlowDialog>
            )}
            {paymentSuccess && (
                <OrderFlowDialog open onClose={() => navigate('/')} title="Ordrebekræftelse" design={confirmationDesign} shopName={tenantName}>
                    <OrderConfirmationLayout design={confirmationDesign} receipt={confirmedReceipt || receipt}
                        orderNumber={createdOrderNumber} message={orderSuccessMessage}
                        warning={Boolean(orderPersistWarning)} onHome={() => navigate('/')}
                        notices={<>                            {!confirmedReceipt && sizeDistributionSummary && (
                                <div className="mb-6 rounded-lg border border-primary/20 bg-primary/5 p-3 text-left">
                                    <p className="text-xs font-semibold text-primary">Størrelsesfordeling</p>
                                    <p className="text-sm text-muted-foreground">{sizeDistributionSummary}</p>
                                </div>
                            )}
                            {orderPersistWarning && (
                                <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-3 text-left">
                                    <p className="text-xs font-semibold text-amber-800">Bemærk</p>
                                    <p className="text-sm text-amber-700">{orderPersistWarning}</p>
                                </div>
                            )}
                            {orderNotificationWarning && (
                                <div className="mb-6 rounded-lg border border-amber-200 bg-amber-50 p-3 text-left">
                                    <p className="text-xs font-semibold text-amber-800">Email / notifikationer</p>
                                    <p className="text-sm text-amber-700">{orderNotificationWarning}</p>
                                </div>
                            )}
</>} />
                </OrderFlowDialog>
            )}
        </StorefrontThemeFrame>
    );
};

// Remount local form state when the resolved shop changes. Wait for resolution so
// a previous shop's checkout is never rendered while a new shop is being loaded.
const LocalWorkspaceCheckout = import.meta.env.DEV ? lazy(() => import('@/components/checkout/LocalWorkspaceCheckout')) : null;
const FileUploadConfiguration = () => {
    const location = useLocation();
    const shop = useShopSettings();
    const localCheckout = new URLSearchParams(location.search).get('workspaceCheckout');
    // Never let a local handoff fall through to the normal hosted checkout, even
    // when someone copies its URL to a production domain or adds payment params.
    if (new URLSearchParams(location.search).has('workspaceCheckout')) {
        const loopback = ['localhost', '127.0.0.1', '[::1]'].includes(window.location.hostname);
        if (!LocalWorkspaceCheckout || !loopback || !localCheckout) return <main className="container mx-auto p-8"><p role="alert">Denne checkout er kun til lokal afprøvning. Åbn den fra dine designs i den lokale butik.</p></main>;
        return <Suspense fallback={<p role="status" className="p-8">Åbner lokal checkout…</p>}><LocalWorkspaceCheckout id={localCheckout} /></Suspense>;
    }
    if (shop.isLoading) return <div className="min-h-screen flex items-center justify-center" role="status"><Loader2 className="h-12 w-12 animate-spin text-primary" /></div>;
    if (shop.isError || !shop.data?.id) return <main className="container mx-auto max-w-xl px-4 py-12"><p role="alert">Butikken kunne ikke bekræftes. Din gemte bestilling er bevaret.</p><Button className="mt-4" onClick={() => void shop.refetch()}>Prøv igen</Button></main>;
    return <FileUploadConfigurationContent key={shop.data.id} />;
};

export default FileUploadConfiguration;
