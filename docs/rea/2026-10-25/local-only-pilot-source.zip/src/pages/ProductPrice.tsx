import { localDesignWorkspaceEnabled } from '@/lib/designer/localDesignWorkspace';
import { readFeaturedMatrixSelection, resolveFeaturedMatrixSelection } from "@/lib/storefront/featuredMatrixNavigation";
import { resolveBrochurePageCount } from '@/lib/designer/brochureProduct';
import type { BrochureFreeMatrixMeta } from '@/lib/pricing/brochureFreePricing';
import type { BrochureSavedPreview } from '@/dev/brochureSavedPreview';
import { wideFormatTemplateLaunch, readWideFormatShapeBindings } from "@/lib/designer/wideFormatGeometry";
import { productArtworkDimensions } from "@/lib/designer/productArtworkDefaults";
import { approvedPrintTemplateLaunch } from '@/lib/mockup/approvedPrintModels';
import { ProductPrintMedia } from '@/components/mockup/ProductPrintMedia';
import { useApprovedPrintModel } from '@/components/mockup/useApprovedPrintModel';
import { ProductPresentationCard } from '@/components/storefront/ProductPresentation';
import { resolveProductPresentation } from '@/lib/branding/productPresentations';
import { useStorefrontCatalog } from '@/hooks/useStorefrontCatalog';
import { galleryMatrixSelections, readProductGallery } from '@/lib/products/productGallery';
import { ProductMediaGallery } from '@/components/product-price-page/ProductMediaGallery';
import { ProductFolderMedia, type ProductFolderUpload } from '@/components/mockup/ProductFolderMedia';
import { resolveProductFolderPreview, hasProductFolderPreview } from '@/lib/mockup/productFolderPreview';
import { resolveFolderDefinition } from '@/lib/mockup/folderDefinition';
import { usePreviewBranding } from '@/contexts/PreviewBrandingContext';
import ProductGrid from '@/components/ProductGrid';
import { ProductCalculatorLayout } from "@/components/product-price-page/ProductCalculatorLayout";
import { useOrderFlowDesign } from "@/hooks/useOrderFlowDesign";
import { OrderDesignPreviewSwitch } from "@/components/checkout/OrderDesignPreviewSwitch";
import { useState, useEffect, useCallback, useMemo } from "react";
import { useLocation, useParams, useSearchParams } from "react-router-dom";
import { PriceMatrix } from "@/components/product-price-page/PriceMatrix";
import { MatrixLayoutV1Renderer } from "@/components/product-price-page/MatrixLayoutV1Renderer";
import { ProductPricePanel, type DeliveryMethod } from "@/components/product-price-page/ProductPricePanel";
import { RollLabelConfiguration } from '@/components/product-price-page/RollLabelConfiguration';
import { RollLabelPriceMatrix } from '@/components/product-price-page/RollLabelPriceMatrix';
import { useRollLabelGenericPrices } from '@/components/product-price-page/useRollLabelGenericPrices';
import { readRollLabelPriceMatrixContract } from '@/lib/products/rollLabelPriceMatrix';
import { rollLabelPriceForSelection, rollLabelPriceInitialSelection, rollLabelPriceSelectionKey } from '@/lib/products/rollLabelPricePreview';
import { useRollLabelSystemPreview } from '@/dev/rollLabelSystemPreview';
import { WorkspaceSourcesContext } from '@/components/product-price-page/workspacePreviewContext';
import { readRollLabelStockDisplay } from '@/lib/products/rollLabelStockDisplay';
import { readRollLabelProductContract, resolveRollLabelProductProfile, type RollLabelSelection } from '@/lib/products/rollLabelConfiguration';
import { rollLabelSelectionGuide } from '@/lib/products/rollLabelSizeGeometry';
import type { DesignerTemplateLaunch } from '@/lib/designer/productTemplateLinks';
import '@/styles/rollLabelReview.css';
import { ProductFilters } from "@/components/product-price-page/ProductFilters";
import { StaticProductInfo } from "@/components/product-price-page/StaticProductInfo";
import {
  type ProductFormatGuideData,
} from "@/components/product-price-page/ProductFormatGuide";
import { CustomDimensionsCalculator } from "@/components/product-price-page/CustomDimensionsCalculator";
import { StorformatConfigurator, type StorformatSelection } from "@/components/product-price-page/StorformatConfigurator";
import { DynamicProductOptions } from "@/components/product-price-page/DynamicProductOptions";
import { MachineConfigurator } from "@/components/product-price-page/MachineConfigurator";
import { Input } from "@/components/ui/input";
import { getProductBySlug } from "@/utils/productMetadata";
import { getProductImage } from "@/utils/productImages";
import { supabase } from "@/integrations/supabase/client";
import { SEO } from "@/components/SEO";
import { PVCBANNER_TENANT_ID } from "@/lib/branding/pvcbannerSettings";
import { ProductSchema, BreadcrumbSchema } from "@/components/ProductSchema";
import { useShopSettings } from "@/hooks/useShopSettings";
import {
  type MatrixData
} from "@/utils/productPricing";
import {
  calculateFoilPrice,
  getGenericMatrixDataFromDB
} from "@/utils/pricingDatabase";
import { getDimensionsFromVariant } from "@/utils/formatStandards";
import { readTransientString, writeTransientString } from "@/lib/storage/transientStorage";
import { fetchProductDetailRead } from "@/lib/api/productDetailRead";
import { resolveCanvaOffer } from "@/lib/canva/launch";
import { resolveMatrixLinkedTemplateId } from "@/lib/designer/linkedTemplates";
import {
  collectExactTemplateSelectionConstraints,
  resolveSelectedDesignerTemplateLaunch,
  selectionUsesFoldedLayout,
  templateHasSelectionConstraints,
  type ProductTemplateFile,
} from "@/lib/designer/productTemplateLinks";
import { StorefrontThemeFrame } from "@/components/storefront/StorefrontThemeFrame";
import {
  readSiteCheckoutSession,
  type SiteCheckoutState,
} from "@/lib/checkout/siteCheckoutSession";
import { resolveStorefrontProductFlow } from "@/lib/sites/storefrontProductFlow";

// Legacy product configurations removed on user request (2025-01-30)
// specificPricingProducts and productConfigs were deleted to unify on the generic pricing system.

const PRODUCT_DETAIL_CACHE_PREFIX = "product-price-detail-cache-v1";

type ProductDetailCachePayload = {
  at: number;
  tenantId: string;
  product: any;
  mpaConfig: any | null;
};

type SizeDistributionField = {
  key: string;
  label: string;
};

const isTransportError = (error: unknown): boolean => {
  const anyError = error as any;
  const message = String(anyError?.message || "").toLowerCase();
  const details = String(anyError?.details || "").toLowerCase();
  const status = Number(anyError?.status || 0);
  return (
    message.includes("failed to fetch")
    || message.includes("networkerror")
    || message.includes("aborterror")
    || details.includes("failed to fetch")
    || details.includes("aborterror")
    || status === 0
    || status === 522
    || status === 523
    || status === 524
    || status === 503
  );
};

const detailCacheKey = (tenantId: string, slug: string) => `${PRODUCT_DETAIL_CACHE_PREFIX}:${tenantId}:${slug}`;

const readDetailCache = (tenantId: string, slug: string): ProductDetailCachePayload | null => {
  if (typeof window === "undefined") return null;
  try {
    const raw = readTransientString(detailCacheKey(tenantId, slug));
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ProductDetailCachePayload;
    if (!parsed?.product || !parsed?.at) return null;
    return parsed;
  } catch {
    return null;
  }
};

const writeDetailCache = (tenantId: string, slug: string, payload: ProductDetailCachePayload) => {
  if (typeof window === "undefined") return;
  try {
    writeTransientString(detailCacheKey(tenantId, slug), JSON.stringify(payload));
  } catch {
    // Ignore storage errors.
  }
};

import { useUserRole } from "@/hooks/useUserRole";
import { DRAFT_FLOW_MESSAGE } from "@/lib/checkout/draftFlow";

const ProductPrice = ({ workspacePreview = false, previewSlug, cardPreview = false, localBrochurePreview }: { workspacePreview?: boolean; previewSlug?: string; cardPreview?: boolean; localBrochurePreview?: BrochureSavedPreview }) => {
  const savedBrochurePreview = import.meta.env.DEV ? localBrochurePreview : undefined;
  const { slug: routeSlug } = useParams<{ slug: string }>();
  const slug = previewSlug || routeSlug;
  const preview = usePreviewBranding();
  const previewCatalog = useStorefrontCatalog({ enabled: workspacePreview && cardPreview });
  const location = useLocation();
  const [searchParams] = useSearchParams();
  const trialRequested = searchParams.get("testFlow") === "1";
  const trialAccess = useUserRole();
  const localRollPreview = useRollLabelSystemPreview(searchParams);
  const shopSettings = useShopSettings();
  const MASTER_TENANT_ID = "00000000-0000-0000-0000-000000000000";
  const branding = preview.isPreviewMode && preview.branding ? preview.branding : shopSettings.data?.branding;
  const orderDesign = useOrderFlowDesign("calculator", branding);
  const tenantName = String(
    branding?.shop_name
    || shopSettings.data?.tenant_name
    || shopSettings.data?.company?.name
    || "Din Shop",
  ).trim() || "Din Shop";

  const staticProduct = slug ? getProductBySlug(slug) : null;
  const restoredCheckoutSelection = useMemo(() => {
    const localSelection = localDesignWorkspaceEnabled()
      ? (location.state as { localWorkspaceSelection?: SiteCheckoutState } | null)?.localWorkspaceSelection : null;
    const checkoutState = localSelection || readSiteCheckoutSession();
    if (!checkoutState || !slug || checkoutState.productSlug !== slug) return null;
    return checkoutState;
  }, [slug, location.state]);
  const companyContext = useMemo(() => {
    const state = (location.state || {}) as Partial<SiteCheckoutState>;
    if (!state.companyId || !state.companyCatalogItemId) return null;
    return {
      companyId: state.companyId,
      companyOfficeId: state.companyOfficeId || null,
      companyAddressId: state.companyAddressId || null,
      companyCatalogItemId: state.companyCatalogItemId,
      companyOrderRequestId: state.companyOrderRequestId || null,
      companyWorkingDesignId: state.companyWorkingDesignId || null,
    };
  }, [location.state]);

  // State
  const [folderUploadDraft, setFolderUploadDraft] = useState<ProductFolderUpload | null>(null);
  const [selectedFormat, setSelectedFormat] = useState<string>("");
  const [matrixSelectedSectionValues, setMatrixSelectedSectionValues] = useState<Record<string, string | null>>({});
  const [matrixPricingMeta, setMatrixPricingMeta] = useState<BrochureFreeMatrixMeta & {
    formatId?: string;
    materialId?: string;
    variantKey?: string;
    verticalValueId?: string;
  }>({});
  const [selectedExtraOption, setSelectedExtraOption] = useState<string>("");
  const [matrixData, setMatrixData] = useState<MatrixData>({ rows: [], columns: [], cells: {} });
  const [selectedCell, setSelectedCell] = useState<{ row: string; column: number } | null>(null);
  const [productPrice, setProductPrice] = useState<number>(0);
  const [shippingCost, setShippingCost] = useState<number>(0);
  const [customArea, setCustomArea] = useState<number>(1); // m² for area-based products
  const [customWidth, setCustomWidth] = useState<number>(100); // cm
  const [customHeight, setCustomHeight] = useState<number>(100); // cm
  const [basePricePerSqm, setBasePricePerSqm] = useState<Record<string, number>>({});
  const [matrixQuantityTiers, setMatrixQuantityTiers] = useState<Array<{ quantity: number; price: number }>>([]);
  const [optionExtraPrice, setOptionExtraPrice] = useState<number>(0);
  const [optionSelections, setOptionSelections] = useState<Record<string, { optionId: string; name: string; extraPrice: number; priceMode: "fixed" | "per_quantity" | "per_area" }>>({});
  const [sizeDistributionValues, setSizeDistributionValues] = useState<Record<string, number>>({});
  const [basePricingStructure, setPricingStructure] = useState<any>(null);
  const [valueNameById, setValueNameById] = useState<Record<string, string>>({});
  const [valueMetaById, setValueMetaById] = useState<Record<string, { width_mm?: number; height_mm?: number; bleed_mm?: number; safe_area_mm?: number; brochurePageCount?: number }>>({});
  const [matrixSelectionSummary, setMatrixSelectionSummary] = useState<string[]>([]);
  const [storformatSelection, setStorformatSelection] = useState<StorformatSelection | null>(null);
  const [podSelectionMeta, setPodSelectionMeta] = useState<{ variantKey?: string; verticalValueId?: string }>({});
  const [podShippingMethods, setPodShippingMethods] = useState<DeliveryMethod[]>([]);
  const [podShippingLoading, setPodShippingLoading] = useState(false);
  const [podShippingError, setPodShippingError] = useState<string | null>(null);
  const [orderDeliveryConfig, setOrderDeliveryConfig] = useState<any>(null);

  // Debug: Track productPrice state changes
  useEffect(() => {
    console.log('[ProductPrice] productPrice state changed to:', productPrice);
  }, [productPrice]);;
  const [dbProductId, setDbProductId] = useState<string | null>(null);
  const pricingStructure: any = (preview.isPreviewMode && dbProductId && preview.productPricingOverrides[dbProductId]) || basePricingStructure;
  const [rollLabelSelection,setRollLabelSelection] = useState<RollLabelSelection|null>(null);
  const [rollLabelSeed,setRollLabelSeed] = useState<RollLabelSelection|null>(null);
  const hasRollLabelContract = Boolean(pricingStructure?.rollLabelConfiguration);
  const rollLabelContract = useMemo(()=>readRollLabelProductContract(pricingStructure?.rollLabelConfiguration,dbProductId || ''),[pricingStructure,dbProductId]);
  const rollLabelPrices = useMemo(()=>readRollLabelPriceMatrixContract(pricingStructure?.rollLabelPricing,rollLabelContract),[pricingStructure,rollLabelContract]);
  // Stable exact combinations keep the existing matrix callbacks from feeding
  // identical quantity tiers back into a perpetual render/route-transition loop.
  const rollExactSelections = useMemo(() => rollLabelContract?.profiles.filter(p => !p.blockers.length).map(p => ({
    [rollLabelContract.sections.format]: p.formatValueId, [rollLabelContract.sections.material]: p.materialValueId,
  })) ?? null, [rollLabelContract]);
  const rollLabelProfile = useMemo(()=>rollLabelContract && dbProductId
    ? resolveRollLabelProductProfile(rollLabelContract,dbProductId,
      galleryMatrixSelections(matrixSelectedSectionValues,pricingStructure?.vertical_axis,selectedCell?.row,valueNameById)) : null,
    [rollLabelContract,dbProductId,matrixSelectedSectionValues,pricingStructure?.vertical_axis,selectedCell?.row,valueNameById]);
  const matchingRollLabelSelection = rollLabelProfile && rollLabelSelection?.profileKey===rollLabelProfile.key
    && rollLabelSelection.productId===dbProductId ? rollLabelSelection : null;
  const initialRollLabelSelection = rollLabelProfile
    ? rollLabelSeed?.profileKey===rollLabelProfile.key && rollLabelSeed.productId===dbProductId ? rollLabelSeed
      : restoredCheckoutSelection?.pricingQuote?.rollLabels?.profileKey===rollLabelProfile.key ? restoredCheckoutSelection.pricingQuote.rollLabels
        : rollLabelPriceInitialSelection(rollLabelPrices,rollLabelProfile.key,rollLabelProfile.optionStates?.initialStateId)
    : null;
  const chooseRollLabelPrice = useCallback((value:RollLabelSelection)=>{setRollLabelSeed(value);setRollLabelSelection(value);},[]);
  const rollStockDisplay = rollLabelProfile && rollLabelContract && dbProductId
    ? readRollLabelStockDisplay(rollLabelProfile,dbProductId,rollLabelContract.familyId) : null;
  const rollMatrixColumnUnit = rollLabelProfile?.customerArtworkRequired===false
    ? rollStockDisplay?.sourceQuantityUnit==='rolls' ? 'ruller' : 'kildeantal' : 'stk';
  const [genericVariantNames, setGenericVariantNames] = useState<string[]>([]);
  const [selectedVariantName, setSelectedVariantName] = useState<string>("");
  const [baseDbProduct, setDbProduct] = useState<{
    id: string;
    name: string;
    description: string;
    image_url: string | null;
    about_title?: string | null;
    about_description?: string | null;
    about_image_url?: string | null;
    technical_specs?: any;
    pricing_type?: string;
    category?: string | null;
    banner_config?: any;
    template_files?: ProductTemplateFile[] | null;
    slug?: string | null;
    tenant_id?: string | null;
    is_published?: boolean;
  } | null>(null);
  const dbProduct = useMemo(() => baseDbProduct ? { ...baseDbProduct, ...(pricingStructure as any)?.workspaceContent } : null, [baseDbProduct, pricingStructure]);
  const displayedRollLabelPrices = useRollLabelGenericPrices(rollLabelPrices,matchingRollLabelSelection,localRollPreview.packet?.genericPriceRows,dbProduct?.tenant_id);
  const rollLabelPrice = matchingRollLabelSelection && displayedRollLabelPrices ? rollLabelPriceForSelection(displayedRollLabelPrices,matchingRollLabelSelection) : null;
  const [mpaConfig, setMpaConfig] = useState<any>(null);
  const [fallbackNotice, setFallbackNotice] = useState<string | null>(null);
  const [productUnavailable, setProductUnavailable] = useState(false);
  const [loading, setLoading] = useState(true);

  const isUuid = useCallback((value: string) => {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
  }, []);

  // Use static product if available, otherwise fall back to database product
  const product = useMemo(() => productUnavailable ? null : (dbProduct ? {
    id: slug || '',
    name: dbProduct.name,
    slug: slug || '',
    description: dbProduct.description,
    hasMatrixPricing: false,
    pricingType: 'matrix' as const,
    category: 'tryksager' as const,
    image: dbProduct.image_url || '/placeholder.svg'
  } : staticProduct), [productUnavailable, staticProduct, dbProduct, slug]);

  // No legacy config fallback
  const config = null;
  // Always generic if database product exists (unless overridden by specific types below)
  const isGenericPricing = !!dbProduct;
  const isStorformat = !!dbProduct && dbProduct.pricing_type === "STORFORMAT";
  const selectedFormatId = useMemo(() => {
    if (selectedFormat && isUuid(selectedFormat)) return selectedFormat;
    if (selectedVariantName) {
      const candidates = selectedVariantName.split('|').filter(Boolean);
      for (const candidate of candidates) {
        if (isUuid(candidate)) {
          const meta = valueMetaById[candidate];
          if (meta?.width_mm && meta?.height_mm) return candidate;
        }
      }
      if (isUuid(selectedVariantName)) return selectedVariantName;
    }
    return "";
  }, [selectedFormat, selectedVariantName, valueMetaById, isUuid]);
  const optionPricingDimensions = useMemo(() => {
    if (matrixPricingMeta.brochureFree) return { widthMm: matrixPricingMeta.brochureFree.widthMm, heightMm: matrixPricingMeta.brochureFree.heightMm };
    if (isStorformat && storformatSelection) {
      return {widthMm: storformatSelection.widthCm * 10, heightMm: storformatSelection.heightCm * 10};
    }
    if (["bannere", "skilte", "folie"].includes(product?.id || "")) {
      return {widthMm: customWidth * 10, heightMm: customHeight * 10};
    }
    const dimensions = valueMetaById[matrixPricingMeta.formatId || selectedFormatId];
    return dimensions?.width_mm && dimensions?.height_mm
      ? {widthMm: dimensions.width_mm, heightMm: dimensions.height_mm} : null;
  }, [isStorformat, storformatSelection, product?.id, customWidth, customHeight, valueMetaById, matrixPricingMeta.formatId, matrixPricingMeta.brochureFree, selectedFormatId]);
  const optionAreaM2 = optionPricingDimensions && optionPricingDimensions.widthMm > 0 && optionPricingDimensions.heightMm > 0
    ? optionPricingDimensions.widthMm * optionPricingDimensions.heightMm / 1_000_000 : null;
  const isPodProduct = !!dbProduct?.technical_specs?.is_pod;
  const podShippingEnabled = isPodProduct
    && pricingStructure?.mode === "matrix_layout_v1"
    && (orderDeliveryConfig?.delivery?.pod_settings?.enabled ?? true);
  const shippingCountry = "DK";

  const sizeDistributionConfig = useMemo(() => {
    const raw = (dbProduct?.technical_specs as any)?.size_distribution;
    if (!raw?.enabled) return null;

    const rawFields = Array.isArray(raw.fields) ? raw.fields : [];
    const fields: SizeDistributionField[] = rawFields
      .map((field: any, index: number) => {
        if (typeof field === "string") {
          const label = field.trim();
          if (!label) return null;
          return {
            key: label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || `field-${index + 1}`,
            label,
          };
        }

        if (field && typeof field === "object") {
          const label = String(field.label || field.name || field.key || "").trim();
          if (!label) return null;
          const key = String(field.key || "")
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "");
          return {
            key: key || label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || `field-${index + 1}`,
            label,
          };
        }

        return null;
      })
      .filter(Boolean) as SizeDistributionField[];

    if (fields.length === 0) return null;

    return {
      title: String(raw.title || "Størrelsesfordeling"),
      enforceQuantityMatch: raw.enforce_quantity_match !== false,
      fields,
    };
  }, [dbProduct?.technical_specs]);

  const sizeDistributionFields = sizeDistributionConfig?.fields || [];

  useEffect(() => {
    if (!sizeDistributionConfig) {
      setSizeDistributionValues((prev) => (Object.keys(prev).length > 0 ? {} : prev));
      return;
    }

    const allowedKeys = new Set(sizeDistributionFields.map((field) => field.key));
    setSizeDistributionValues((prev) => {
      const next: Record<string, number> = {};
      let changed = false;

      sizeDistributionFields.forEach((field) => {
        const current = Number(prev[field.key] || 0);
        next[field.key] = Number.isFinite(current) && current > 0 ? Math.floor(current) : 0;
      });

      Object.keys(prev).forEach((key) => {
        if (!allowedKeys.has(key)) changed = true;
      });

      if (!changed) {
        changed = sizeDistributionFields.some((field) => (prev[field.key] || 0) !== next[field.key]);
      }

      return changed ? next : prev;
    });
  }, [sizeDistributionConfig, sizeDistributionFields]);

  const sizeDistributionTotal = useMemo(() => {
    if (!sizeDistributionConfig) return 0;
    return sizeDistributionFields.reduce((sum, field) => sum + (Number(sizeDistributionValues[field.key] || 0) || 0), 0);
  }, [sizeDistributionConfig, sizeDistributionFields, sizeDistributionValues]);

  const sizeDistributionEntries = useMemo(() => {
    if (!sizeDistributionConfig) return [] as Array<{ key: string; label: string; value: number }>;
    return sizeDistributionFields
      .map((field) => ({
        key: field.key,
        label: field.label,
        value: Number(sizeDistributionValues[field.key] || 0) || 0,
      }))
      .filter((entry) => entry.value > 0);
  }, [sizeDistributionConfig, sizeDistributionFields, sizeDistributionValues]);

  const sizeDistributionSelectionQuantity = isStorformat
    ? (storformatSelection?.quantity || 0)
    : (selectedCell?.column || 0);

  const sizeDistributionMismatch = useMemo(() => {
    if (!sizeDistributionConfig?.enforceQuantityMatch) return false;
    if (!sizeDistributionSelectionQuantity || sizeDistributionSelectionQuantity <= 0) return false;
    return sizeDistributionTotal !== sizeDistributionSelectionQuantity;
  }, [
    sizeDistributionConfig?.enforceQuantityMatch,
    sizeDistributionSelectionQuantity,
    sizeDistributionTotal,
  ]);

  const orderValidationError = useMemo(() => {
    if(hasRollLabelContract) return rollLabelPrice
      ? `Prisforslag fra ${new Date(rollLabelPrice.capturedAt).toLocaleDateString('da-DK')}. Moms og levering afventer klargøring før bestilling.`
      : 'Der er endnu ikke en kontrolleret pris for præcis disse mål, antal og valg. Bestilling afventer klargøring.';
    if(savedBrochurePreview) return 'Forhåndsvisning – bestilling er endnu ikke åbnet.';
    if (Object.values(optionSelections).some(option => option.priceMode === "per_area") && !optionAreaM2) {
      return "Vælg et format med kendte mål, før tillæg pr. m² kan beregnes.";
    }
    if (!sizeDistributionMismatch) return null;
    return `Fordel størrelser så summen er ${sizeDistributionSelectionQuantity} stk (nu ${sizeDistributionTotal}).`;
  }, [sizeDistributionMismatch, sizeDistributionSelectionQuantity, sizeDistributionTotal, optionSelections, optionAreaM2, savedBrochurePreview,hasRollLabelContract,rollLabelPrice]);

  const sizeDistributionSummary = useMemo(() => {
    if (!sizeDistributionConfig || sizeDistributionEntries.length === 0) return "";
    const entries = sizeDistributionEntries.map((entry) => `${entry.label}: ${entry.value}`).join(", ");
    const totalPart = sizeDistributionSelectionQuantity > 0
      ? ` (sum ${sizeDistributionTotal}/${sizeDistributionSelectionQuantity})`
      : ` (sum ${sizeDistributionTotal})`;
    return `${sizeDistributionConfig.title}: ${entries}${totalPart}`;
  }, [
    sizeDistributionConfig,
    sizeDistributionEntries,
    sizeDistributionTotal,
    sizeDistributionSelectionQuantity,
  ]);

  // Fetch database product ID and data for dynamic options
  useEffect(() => {
    async function fetchDbProduct() {
      if (!slug) return;
      if (shopSettings.isLoading && !localRollPreview.requested) return;
      setLoading(true);
      setFallbackNotice(null);
      setProductUnavailable(false);
      setMpaConfig(null);
      console.log('[ProductPrice] Fetching product with slug:', slug);
      const productSelect = 'id, tenant_id, slug, name, description, image_url, about_title, about_description, about_image_url, category, technical_specs, pricing_structure, pricing_type, banner_config, template_files' as any;
      const tenantId = shopSettings.data?.id || MASTER_TENANT_ID;
      const applyProductData = (data: any) => {
        setDbProductId(data.id);
        setDbProduct(data);
        setProductUnavailable(false);
        setOrderDeliveryConfig((data as any).banner_config?.order_delivery || null);
        const rawStructure = (data as any).pricing_structure;
        let parsedStructure = rawStructure;
        if (typeof rawStructure === 'string') {
          try {
            parsedStructure = JSON.parse(rawStructure);
          } catch {
            parsedStructure = null;
          }
        }
        if (parsedStructure && !parsedStructure.mode && parsedStructure.vertical_axis && parsedStructure.layout_rows) {
          parsedStructure = { ...parsedStructure, mode: 'matrix_layout_v1' };
        }
        if (parsedStructure?.mode === 'matrix_layout_v1') {
          setPricingStructure(parsedStructure);
        } else {
          setPricingStructure(null);
        }
      };

      if(savedBrochurePreview?.product.slug===slug){
        applyProductData(savedBrochurePreview.product);setLoading(false);return;
      }
      if(localRollPreview.requested){
        if(localRollPreview.loading)return;
        if(!localRollPreview.packet || localRollPreview.packet.product.slug!==slug){setProductUnavailable(true);setLoading(false);return;}
        applyProductData(localRollPreview.packet.product);setLoading(false);return;
      }
      if (trialRequested) {
        if (trialAccess.loading) return;
        // Existing signed-in access and database RLS remain authoritative.
        if (!trialAccess.isAdmin || !trialAccess.userId) {
          setDbProduct(null); setDbProductId(null); setProductUnavailable(true); setLoading(false); return;
        }
        const { data, error } = await supabase.from('products').select('*')
          .eq('slug', slug).eq('tenant_id', tenantId).maybeSingle();
        if (error || !data) { setDbProduct(null); setDbProductId(null); setProductUnavailable(true); setLoading(false); return; }
        applyProductData(data); setLoading(false); return;
      }
      if ((workspacePreview || preview.isPreviewMode) && searchParams.get('tenantId')) {
        const previewTenant = searchParams.get('tenantId');
        if (!previewTenant) { setLoading(false); setProductUnavailable(true); return; }
        const { data, error } = await supabase.from('products').select('*').eq('slug', slug).eq('tenant_id', previewTenant).maybeSingle();
        if (error || !data) { setProductUnavailable(true); setLoading(false); return; }
        applyProductData(data); setLoading(false); return;
      }

      const mapApiProductToLocalShape = (apiProduct: Record<string, unknown> | null) => {
        if (!apiProduct || typeof apiProduct !== "object") return null;
        return {
          id: String(apiProduct.id || ""),
          name: typeof apiProduct.name === "string" ? apiProduct.name : "",
          description: typeof apiProduct.description === "string" ? apiProduct.description : "",
          image_url: typeof apiProduct.image_url === "string" ? apiProduct.image_url : null,
          about_title: typeof apiProduct.about_title === "string" ? apiProduct.about_title : null,
          about_description: typeof apiProduct.about_description === "string" ? apiProduct.about_description : null,
          about_image_url: typeof apiProduct.about_image_url === "string" ? apiProduct.about_image_url : null,
          category: typeof apiProduct.category === "string" ? apiProduct.category : null,
          technical_specs: (apiProduct.technical_specs && typeof apiProduct.technical_specs === "object") ? apiProduct.technical_specs : null,
          pricing_structure: apiProduct.pricing_structure ?? null,
          pricing_type: typeof apiProduct.pricing_type === "string" ? apiProduct.pricing_type : null,
          banner_config: (apiProduct.banner_config && typeof apiProduct.banner_config === "object") ? apiProduct.banner_config : null,
          template_files: Array.isArray(apiProduct.template_files) ? apiProduct.template_files : [],
          slug: typeof apiProduct.slug === "string" ? apiProduct.slug : null,
          tenant_id: typeof apiProduct.tenant_id === "string" ? apiProduct.tenant_id : null,
          is_published: apiProduct.is_published === true,
        };
      };

      const isVisibleStorefrontProduct = (data: any) => {
        if (!data?.id || data.is_published !== true) return false;
        if (data.tenant_id === tenantId) return true;
        return tenantId !== MASTER_TENANT_ID && data.tenant_id === MASTER_TENANT_ID;
      };

      const throwIfTransportError = (err: any, context: string) => {
        if (!err) return;
        if (!isTransportError(err)) return;
        const transportError = new Error(`Product transport failure (${context})`);
        (transportError as any).code = "PRODUCT_TRANSPORT";
        throw transportError;
      };

      try {
        try {
          const apiResult = await fetchProductDetailRead({
            tenantId,
            slug,
            hostname: typeof window !== "undefined" ? window.location.hostname : undefined,
            pathname: typeof window !== "undefined" ? window.location.pathname : undefined,
          });

          const apiProduct = mapApiProductToLocalShape(apiResult.product as Record<string, unknown> | null);
          if (apiResult.success && apiProduct?.id && isVisibleStorefrontProduct(apiProduct)) {
            console.log('[ProductPrice] product-detail-read result:', { data: apiProduct, source: apiResult.source });
            console.log('[ProductPrice] Setting dbProductId to:', apiProduct.id);
            applyProductData(apiProduct);

            const { data: cfg } = await supabase
              .from('product_pricing_configs')
              .select('*')
              .eq('product_id', apiProduct.id)
              .eq('pricing_type', 'MACHINE_PRICED')
              .maybeSingle();

            if (cfg) {
              setMpaConfig(cfg);
            }

            writeDetailCache(tenantId, slug, {
              at: Date.now(),
              tenantId,
              product: apiProduct,
              mpaConfig: cfg || null,
            });

            return;
          }
          if (apiResult.success && apiProduct?.id) {
            console.warn('[ProductPrice] Ignoring product-detail-read result outside storefront visibility rules:', {
              id: apiProduct.id,
              source: apiResult.source,
              tenant_id: apiProduct.tenant_id,
              is_published: apiProduct.is_published,
            });
          }
        } catch (apiError) {
          console.warn('[ProductPrice] product-detail-read failed, falling back to direct query:', apiError);
        }

        const { data: tenantScopedRows, error: tenantScopedError } = await supabase
          .from('products')
          .select(productSelect)
          .eq('slug', slug)
          .eq('tenant_id', tenantId)
          .eq('is_published', true)
          .limit(1);

        if (tenantScopedError) {
          console.warn('[ProductPrice] Tenant-scoped product query error:', tenantScopedError);
          throwIfTransportError(tenantScopedError, 'tenantScoped');
        }

        let data = (tenantScopedRows && tenantScopedRows.length > 0) ? (tenantScopedRows[0] as any) : null;

        if (!data && tenantId !== MASTER_TENANT_ID) {
          const { data: masterRows, error: masterError } = await supabase
            .from('products')
            .select(productSelect)
            .eq('slug', slug)
            .eq('tenant_id', MASTER_TENANT_ID)
            .eq('is_published', true)
            .limit(1);

          if (masterError) {
            console.warn('[ProductPrice] Master fallback product query error:', masterError);
            throwIfTransportError(masterError, 'masterFallback');
          }

          data = (masterRows && masterRows.length > 0) ? (masterRows[0] as any) : null;
        }

        if (!data) {
          const { data: publishedRows, error: publishedError } = await supabase
            .from('products')
            .select(productSelect)
            .eq('slug', slug)
            .eq('tenant_id', MASTER_TENANT_ID)
            .eq('is_published', true)
            .limit(1);

          if (publishedError) {
            console.warn('[ProductPrice] Published fallback product query error:', publishedError);
            throwIfTransportError(publishedError, 'publishedFallback');
          }

          data = (publishedRows && publishedRows.length > 0) ? (publishedRows[0] as any) : null;
        }

        console.log('[ProductPrice] Database result:', { data });

        if (data) {
          console.log('[ProductPrice] Setting dbProductId to:', data.id);
          applyProductData(data);

          // Fetch MPA Config if available
          const { data: cfg } = await supabase
            .from('product_pricing_configs')
            .select('*')
            .eq('product_id', data.id)
            .eq('pricing_type', 'MACHINE_PRICED')
            .maybeSingle();

          if (cfg) {
            setMpaConfig(cfg);
          }

          writeDetailCache(tenantId, slug, {
            at: Date.now(),
            tenantId,
            product: data,
            mpaConfig: cfg || null,
          });
        } else {
          console.warn('[ProductPrice] No product found for slug:', slug);
          setDbProductId(null);
          setDbProduct(null);
          setPricingStructure(null);
          setOrderDeliveryConfig(null);
          setProductUnavailable(tenantId !== MASTER_TENANT_ID);
        }
      } catch (error) {
        console.warn('[ProductPrice] Product fetch failed:', error);
        const isTransport = (error as any)?.code === "PRODUCT_TRANSPORT" || isTransportError(error);
        if (isTransport) {
          const cached = readDetailCache(tenantId, slug) || (tenantId === MASTER_TENANT_ID ? readDetailCache(MASTER_TENANT_ID, slug) : null);
          if (cached) {
            applyProductData(cached.product);
            if (cached.mpaConfig) setMpaConfig(cached.mpaConfig);
            setFallbackNotice('Viser senest gemte produktdata, fordi backend-forbindelsen fejler midlertidigt.');
          }
        }
      } finally {
        setLoading(false);
      }
    }
    fetchDbProduct();
  }, [trialRequested, trialAccess.loading, trialAccess.isAdmin, trialAccess.userId, slug, shopSettings.data?.id, shopSettings.isLoading, workspacePreview, preview.isPreviewMode, preview.productPricingRefreshVersion, savedBrochurePreview,localRollPreview.requested,localRollPreview.loading,localRollPreview.packet]);

  useEffect(() => {
    if (!dbProductId || !isGenericPricing) return;

    const fetchAttributeValues = async () => {
      const { data } = localRollPreview.packet ? {data:localRollPreview.packet.sourceGroups} : savedBrochurePreview ? {data:savedBrochurePreview.sourceGroups} : await supabase
        .from('product_attribute_groups')
        .select('id, values:product_attribute_values(id, name, width_mm, height_mm, meta)')
        .eq('product_id', dbProductId);

      const map: Record<string, string> = {};
      const metaMap: Record<string, { width_mm?: number; height_mm?: number; bleed_mm?: number; safe_area_mm?: number; brochurePageCount?: number }> = {};
      (data || []).forEach((group: any) => {
        (group.values || []).forEach((value: any) => {
          map[value.id] = value.name;
          let parsedMeta: any = value.meta || null;
          if (typeof parsedMeta === "string") {
            try {
              parsedMeta = JSON.parse(parsedMeta);
            } catch {
              parsedMeta = null;
            }
          }
          metaMap[value.id] = {
            width_mm: value.width_mm ?? undefined,
            height_mm: value.height_mm ?? undefined,
            bleed_mm: typeof parsedMeta?.bleed_mm === "number" ? parsedMeta.bleed_mm : undefined,
            brochurePageCount: typeof parsedMeta?.brochurePageCount === "number" ? parsedMeta.brochurePageCount : undefined,
            safe_area_mm: typeof parsedMeta?.safe_area_mm === "number" ? parsedMeta.safe_area_mm : undefined
          };
        });
      });
      setValueNameById(map);
      setValueMetaById(metaMap);
    };

    fetchAttributeValues();
  }, [dbProductId, isGenericPricing, savedBrochurePreview,localRollPreview.packet]);

  useEffect(() => {
    if (!isGenericPricing) return;

    const ids = new Set<string>();
    const addId = (id: string) => {
      if (isUuid(id)) ids.add(id);
    };

    genericVariantNames.forEach(name => {
      name.split('|').forEach(addId);
    });

    matrixData.rows.forEach(addId);

    const missingIds = Array.from(ids).filter(id => !valueNameById[id]);
    if (missingIds.length === 0) return;

    const fetchMissingValues = async () => {
      const { data } = await supabase
        .from('product_attribute_values')
        .select('id, name, width_mm, height_mm, meta')
        .in('id', missingIds);

      if (!data || data.length === 0) return;

      const map: Record<string, string> = {};
      const metaMap: Record<string, { width_mm?: number; height_mm?: number; bleed_mm?: number; safe_area_mm?: number; brochurePageCount?: number }> = {};
      (data || []).forEach((value: any) => {
        map[value.id] = value.name;
        let parsedMeta: any = value.meta || null;
        if (typeof parsedMeta === "string") {
          try {
            parsedMeta = JSON.parse(parsedMeta);
          } catch {
            parsedMeta = null;
          }
        }
        metaMap[value.id] = {
          width_mm: value.width_mm ?? undefined,
          height_mm: value.height_mm ?? undefined,
          bleed_mm: typeof parsedMeta?.bleed_mm === "number" ? parsedMeta.bleed_mm : undefined,
          brochurePageCount: typeof parsedMeta?.brochurePageCount === "number" ? parsedMeta.brochurePageCount : undefined,
            safe_area_mm: typeof parsedMeta?.safe_area_mm === "number" ? parsedMeta.safe_area_mm : undefined
        };
      });
      setValueNameById(prev => ({ ...prev, ...map }));
      setValueMetaById(prev => ({ ...prev, ...metaMap }));
    };

    fetchMissingValues();
  }, [genericVariantNames, matrixData.rows, isGenericPricing, valueNameById, isUuid]);

  const formatVariantLabel = useCallback((variantName: string) => {
    if (!variantName || variantName === 'none') return 'Standard';
    const parts = variantName.split('|').filter(Boolean);
    if (parts.length === 0) return 'Standard';
    return parts.map(id => valueNameById[id] || id).join(', ');
  }, [valueNameById]);

  // Scroll to top when landing on product page
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  // Initialize format and extra options
  useEffect(() => {
  }, [product?.id]);

  // Fetch variant names for generic products
  useEffect(() => {
    if (!isGenericPricing || !dbProductId) return;
    if (isStorformat) return;
    if (pricingStructure?.mode === 'matrix_layout_v1') return;

    const fetchVariantNames = async () => {
      const { matrixData, variantNames } = await getGenericMatrixDataFromDB(dbProductId, undefined);
      if (variantNames.length > 0) {
        setGenericVariantNames(variantNames);
        setSelectedVariantName(prev => prev || variantNames[0]);
      }
    };
    fetchVariantNames();
  }, [isGenericPricing, dbProductId, pricingStructure, isStorformat]);

  // Update matrix data
  useEffect(() => {
    if (!product) return;
    if (isStorformat) return;
    if (pricingStructure?.mode === 'matrix_layout_v1') return;

    // Skip for MPA products - MachineConfigurator handles pricing
    if (mpaConfig) return;

    if (isGenericPricing && (!dbProductId || !selectedVariantName)) return;
    if (!isGenericPricing && !selectedFormat) return;

    const loadMatrixData = async () => {
      let newMatrixData: MatrixData = { rows: [], columns: [], cells: {} };

      if (dbProductId && selectedVariantName) {
        console.log(`Loading generic matrix for product: ${product.id}, variant: ${selectedVariantName}`);
        const { matrixData } = await getGenericMatrixDataFromDB(dbProductId, selectedVariantName);
        newMatrixData = matrixData;
        if (Object.keys(valueNameById).length > 0 && matrixData.rows.length > 0) {
          const mappedRows = matrixData.rows.map(rowId => valueNameById[rowId] || rowId);
          const mappedCells: Record<string, Record<number, number>> = {};
          matrixData.rows.forEach((rowId, index) => {
            mappedCells[mappedRows[index]] = matrixData.cells[rowId] || {};
          });
          newMatrixData = { ...matrixData, rows: mappedRows, cells: mappedCells };
        }
      }

      console.log(`Matrix updated with ${newMatrixData.rows.length} rows and ${newMatrixData.columns.length} columns`);
      setMatrixData(newMatrixData);

      // Deep linking & Selection preservation logic
      const qtyParam = searchParams.get("qty");
      const variantParam = searchParams.get("variant");

      if (qtyParam && variantParam) {
        const qty = parseInt(qtyParam);
        const row = newMatrixData.rows.find(r => r.toLowerCase().includes(variantParam.toLowerCase()));

        if (row && newMatrixData.columns.includes(qty)) {
          const price = newMatrixData.cells[row]?.[qty] || 0;
          setSelectedCell({ row, column: qty });
          setProductPrice(price);
        }
      } else if (selectedCell) {
        const { row: previousRow, column: selectedQty } = selectedCell;
        if (newMatrixData.columns.includes(selectedQty)) {
          const targetRow = newMatrixData.rows.includes(previousRow) ? previousRow : newMatrixData.rows[0];
          const newPrice = newMatrixData.cells[targetRow]?.[selectedQty] || 0;
          setSelectedCell({ row: targetRow, column: selectedQty });
          setProductPrice(newPrice);
        } else {
          setSelectedCell(null);
          setProductPrice(0);
        }
      } else {
        // Default to 500
        if (newMatrixData.rows.length > 0) {
          const defaultRow = newMatrixData.rows[0];
          const defaultQty = newMatrixData.columns.includes(500) ? 500 : (newMatrixData.columns[0] || 0);
          if (defaultQty > 0) {
            const price = newMatrixData.cells[defaultRow]?.[defaultQty] || 0;
            setSelectedCell({ row: defaultRow, column: defaultQty });
            setProductPrice(price);
          }
        }
      }
    };

    loadMatrixData();
  }, [product, selectedFormat, selectedExtraOption, searchParams, dbProductId, selectedVariantName, isGenericPricing, pricingStructure, mpaConfig, valueNameById, isStorformat, selectedCell]);

  const computeOptionExtras = useCallback((selections: Record<string, { optionId: string; name: string; extraPrice: number; priceMode: "fixed" | "per_quantity" | "per_area" }>, quantity: number, area: number) => {
    return Object.values(selections).reduce((sum, sel) => {
      if (sel.priceMode === "per_quantity") {
        return sum + sel.extraPrice * quantity;
      }
      if (sel.priceMode === "per_area") {
        return sum + sel.extraPrice * area * quantity;
      }
      return sum + sel.extraPrice;
    }, 0);
  }, []);

  const handleCellClick = async (_row: string, column: number, basePrice: number, displayPrice: number) => {
    setSelectedCell({ row: _row, column });
    // For all m²-based products, trust the matrix value (already includes any volume-based discount)
    setProductPrice(basePrice);
    const totalExtra = computeOptionExtras(optionSelections, column, optionAreaM2 || 0);
    setOptionExtraPrice(totalExtra);
  };

  const handleAreaChange = useCallback(async (_area: number, width?: number, height?: number) => {
    // Keep matrix-selected price; do not reapply calculations in the side panel
    setCustomArea(_area);
    if (width !== undefined) setCustomWidth(width);
    if (height !== undefined) setCustomHeight(height);
  }, []);

  const handleShippingChange = (type: string | null, cost: number) => {
    setShippingCost(cost);
  };

  const handleOptionSelectionChange = useCallback((selections: Record<string, { optionId: string; name: string; extraPrice: number; priceMode: "fixed" | "per_quantity" | "per_area" }>) => {
    setOptionSelections(selections);
    const qty = isStorformat ? (storformatSelection?.quantity || 0) : (selectedCell?.column ?? 1);
    const area = optionAreaM2 || 0;
    const totalExtra = computeOptionExtras(selections, qty, area);
    setOptionExtraPrice(totalExtra);
  }, [selectedCell, computeOptionExtras, optionAreaM2, isStorformat, storformatSelection]);

  const handleSizeDistributionChange = useCallback((fieldKey: string, rawValue: string) => {
    const parsed = Number(rawValue);
    const nextValue = Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : 0;
    setSizeDistributionValues((prev) => ({
      ...prev,
      [fieldKey]: nextValue,
    }));
  }, []);

  const sizeDistributionOptionSelections = useMemo(() => {
    const selections: Record<string, { optionId: string; name: string; extraPrice: number; priceMode: "fixed" | "per_quantity" | "per_area" }> = {};
    sizeDistributionEntries.forEach((entry) => {
      const optionId = `size-dist-${entry.key}`;
      selections[optionId] = {
        optionId,
        name: `${entry.label}: ${entry.value}`,
        extraPrice: 0,
        priceMode: "fixed",
      };
    });
    return selections;
  }, [sizeDistributionEntries]);

  const combinedOptionSelections = useMemo(
    () => ({ ...optionSelections, ...sizeDistributionOptionSelections }),
    [optionSelections, sizeDistributionOptionSelections]
  );

  useEffect(() => {
    const qty = isStorformat ? (storformatSelection?.quantity || 0) : (selectedCell?.column ?? 1);
    const area = optionAreaM2 || 0;
    const totalExtra = computeOptionExtras(optionSelections, qty, area);
    setOptionExtraPrice(totalExtra);
  }, [selectedCell, optionSelections, computeOptionExtras, optionAreaM2, isStorformat, storformatSelection]);

  // Recalculate base price when area or selection changes for area-based products
  useEffect(() => {
    if (!selectedCell) return;
    if (isStorformat) return;
    // Skip for MPA products - MachineConfigurator handles pricing
    if (mpaConfig) return;
    if (pricingStructure?.mode === 'matrix_layout_v1') return;

    const isAreaBased = product?.id === "bannere" || product?.id === "skilte" || product?.id === "folie";
    const qty = selectedCell.column;
    let base = matrixData.cells[selectedCell.row]?.[qty] || 0;

    if (isAreaBased && basePricePerSqm[selectedCell.row]) {
      base = Math.round((customArea || 1) * qty * basePricePerSqm[selectedCell.row]);
    }

    setProductPrice(base);
    const extra = computeOptionExtras(optionSelections, qty, optionAreaM2 || 0);
    setOptionExtraPrice(extra);
  }, [selectedCell, customArea, basePricePerSqm, matrixData, product, computeOptionExtras, optionSelections, optionAreaM2, mpaConfig, isStorformat, pricingStructure]);

  // Memoized handler for MatrixLayoutV1 to avoid conditional hook errors
  const handleMatrixCellClick = useCallback((row: string, column: number, price: number) => {
    setSelectedCell({ row, column });
    setProductPrice(price);
  }, []);

  const podSelectedQuantity = useMemo(() => {
    if (!podShippingEnabled) return 0;
    return selectedCell?.column || 0;
  }, [podShippingEnabled, selectedCell]);

  // Stable selection handler prevents render loops that can break navigation
  const handleMatrixSelectionChange = useCallback((
    selections: Record<string, string | null>,
    formatId?: string,
    materialId?: string,
    meta?: BrochureFreeMatrixMeta,
  ) => {
    setMatrixSelectedSectionValues((prev) => {
      const prevEntries = Object.entries(prev);
      const nextEntries = Object.entries(selections || {});
      if (
        prevEntries.length === nextEntries.length
        && prevEntries.every(([key, value]) => selections[key] === value)
      ) {
        return prev;
      }
      return selections;
    });
    if (formatId) {
      setSelectedFormat(prev => (prev === formatId ? prev : formatId));
    }
    setMatrixPricingMeta((prev) => {
      const next = {
        formatId,
        materialId,
        variantKey: meta?.variantKey,
        verticalValueId: meta?.verticalValueId,
        brochureFree: meta?.brochureFree,
        brochureTemplate: meta?.brochureTemplate,
      };
      return (
        prev.formatId === next.formatId
        && prev.materialId === next.materialId
        && prev.variantKey === next.variantKey
        && prev.verticalValueId === next.verticalValueId
        && JSON.stringify(prev.brochureFree) === JSON.stringify(next.brochureFree)
        && JSON.stringify(prev.brochureTemplate) === JSON.stringify(next.brochureTemplate)
      ) ? prev : next;
    });
    if (meta?.variantKey || meta?.verticalValueId) {
      const nextVariantKey = meta?.variantKey;
      const nextVerticalValueId = meta?.verticalValueId;
      setPodSelectionMeta(prev => (
        prev?.variantKey === nextVariantKey && prev?.verticalValueId === nextVerticalValueId
          ? prev
          : { variantKey: nextVariantKey, verticalValueId: nextVerticalValueId }
      ));
    }
  }, []);

  const pricingQuote = useMemo<SiteCheckoutState["pricingQuote"]>(() => {
    if (!dbProductId) return null;
    const quantity = hasRollLabelContract ? (matchingRollLabelSelection?.quantity || 0) : isStorformat ? (storformatSelection?.quantity || 0) : (selectedCell?.column || 0);
    if (!quantity || quantity <= 0) return null;
    const selectedValues = Object.values(matrixSelectedSectionValues || {})
      .map((value) => String(value || ""))
      .filter((value) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value));

    return {
      productId: dbProductId,
      productSlug: slug || null,
      quantity,
      quantityTiers: !hasRollLabelContract && pricingStructure?.mode === 'matrix_layout_v1' ? matrixQuantityTiers.map(tier => ({
        quantity: tier.quantity, price: Math.round(tier.price + computeOptionExtras(optionSelections, tier.quantity, optionAreaM2 || 0)),
      })) : undefined,
      formatId: matrixPricingMeta.formatId || selectedFormat || null,
      materialId: matrixPricingMeta.materialId || null,
      verticalValueId: matrixPricingMeta.verticalValueId || null,
      variantKey: matrixPricingMeta.variantKey || selectedCell?.row || null,
      variantValueIds: selectedValues,
      variantDisplayLabels: matrixSelectionSummary,
      selectedSectionValues: matrixSelectedSectionValues,
      ...(matrixPricingMeta.brochureFree ? { brochureFree: matrixPricingMeta.brochureFree } : {}),
      ...(matchingRollLabelSelection ? {rollLabels:matchingRollLabelSelection} : {}),
      optionIds: Object.values(optionSelections)
        .map((option) => option.optionId)
        .filter((optionId) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(optionId || ""))),
      shippingSelected: null,
      areaM2: optionAreaM2,
      widthMm: optionPricingDimensions?.widthMm || null,
      heightMm: optionPricingDimensions?.heightMm || null,
      storformat: isStorformat && storformatSelection ? {
        widthMm: storformatSelection.widthCm * 10,
        heightMm: storformatSelection.heightCm * 10,
        materialId: storformatSelection.materialId,
        finishIds: storformatSelection.finishIds,
        productIds: storformatSelection.productIds,
        selectedSectionValues: storformatSelection.selectedSectionValues,
      } : null,
    };
  }, [
    hasRollLabelContract,
    matrixQuantityTiers, computeOptionExtras, pricingStructure,
    matchingRollLabelSelection,
    optionAreaM2,
    optionPricingDimensions,
    dbProductId,
    isStorformat,
    matrixPricingMeta,
    matrixSelectedSectionValues,
    matrixSelectionSummary,
    optionSelections,
    selectedCell?.column,
    selectedFormat,
    slug,
    storformatSelection,
  ]);


  useEffect(() => {
    if (!podShippingEnabled) {
      setPodShippingMethods([]);
      setPodShippingError(null);
      setPodShippingLoading(false);
      return;
    }
    if (!dbProductId) return;
    if (!podSelectedQuantity || podSelectedQuantity <= 0) return;
    if (!podSelectionMeta.variantKey || !podSelectionMeta.verticalValueId) return;
    if (!shippingCountry) return;

    let active = true;

    const fetchShipping = async () => {
      setPodShippingLoading(true);
      setPodShippingError(null);

      const { data, error } = await supabase.functions.invoke("pod-shipping-possibilities", {
        body: {
          productId: dbProductId,
          quantity: podSelectedQuantity,
          variantKey: podSelectionMeta.variantKey,
          verticalValueId: podSelectionMeta.verticalValueId,
          address: { country: shippingCountry },
        },
      });

      if (!active) return;

      const payload = data as any;
      if (error || payload?.error) {
        setPodShippingError(error?.message || payload?.error || "Kunne ikke hente levering.");
        setPodShippingMethods([]);
        setPodShippingLoading(false);
        return;
      }

      const options = payload?.options || [];
      const methods = options.map((option: any) => ({
        id: option.id || `${option.carrier || "carrier"}-${option.method || "method"}-${option.deliveryDate || ""}`,
        name: option.method || "Levering",
        description: "",
        price: Number.isFinite(option.price) ? Math.round(option.price) : 0,
        delivery_date: option.deliveryDate,
        submission: option.submission,
        pickup_date: option.pickupDate,
        carrier: option.carrier,
        method: option.method,
        urgency: option.urgency,
        reliability: option.reliability,
        transit_duration: option.transitDuration,
      })) as DeliveryMethod[];

      setPodShippingMethods(methods);
      setPodShippingLoading(false);
    };

    fetchShipping();
    return () => {
      active = false;
    };
  }, [
    podShippingEnabled,
    dbProductId,
    podSelectedQuantity,
    podSelectionMeta.variantKey,
    podSelectionMeta.verticalValueId,
    shippingCountry,
  ]);

  const handleStorformatSelection = useCallback((selection: StorformatSelection | null) => {
    setStorformatSelection(selection);
    setProductPrice(selection?.totalPrice || 0);
    if (selection?.areaM2) setCustomArea(selection.areaM2);
  }, []);

  // Loading State
  // Determine current dimensions based on selection
  const selectedFormatLabel = useMemo(() => {
    if (isStorformat && storformatSelection) {
      return `${storformatSelection.widthCm} × ${storformatSelection.heightCm} cm`;
    }
    if (selectedFormatId && valueNameById[selectedFormatId]) return valueNameById[selectedFormatId];
    return selectedFormat || selectedVariantName || "";
  }, [isStorformat, storformatSelection, selectedFormat, selectedFormatId, selectedVariantName, valueNameById]);
  const brochurePageCount = resolveBrochurePageCount(resolveStorefrontProductFlow(dbProduct || {}).designerMode, matrixSelectedSectionValues, valueMetaById);
  const availableProductTemplates = useMemo(() => {
    return Array.isArray(dbProduct?.template_files) ? dbProduct.template_files : [];
  }, [dbProduct?.template_files]);
  const exactTemplateCombinationSelections = useMemo(() => (
    collectExactTemplateSelectionConstraints(availableProductTemplates)
  ), [availableProductTemplates]);
  const rollDocumentKey = matchingRollLabelSelection ? JSON.stringify(matchingRollLabelSelection) : '';
  const [rollDocument, setRollDocument] = useState<{ key: string; contract: unknown; launch: DesignerTemplateLaunch } | null>(null);
  useEffect(() => {
    let active = true, downloadUrl: string | null = null;
    setRollDocument(null);
    if (matchingRollLabelSelection && dbProductId && rollLabelContract && dbProduct?.tenant_id) {
      void import('@/lib/designer/rollLabelGeneratedTemplate').then(async ({ prepareRollLabelGeneratedTemplate }) => {
        const generated = await prepareRollLabelGeneratedTemplate(matchingRollLabelSelection, dbProductId, rollLabelContract);
        if (!active || !generated) return;
        downloadUrl = URL.createObjectURL(new Blob([generated.bytes.slice().buffer], { type: 'application/pdf' }));
        setRollDocument({ key: rollDocumentKey, contract: rollLabelContract, launch: { pdfUrl: generated.descriptor,
          downloadUrl, tenantId: dbProduct.tenant_id, templatePdfSha256: generated.sha256,
          name: `Etiket ${generated.guide.formatLabel}`, widthMm: generated.guide.finishedWidthMm,
          heightMm: generated.guide.finishedHeightMm, bleedMm: generated.guide.bleedMm, safeMm: generated.guide.safeAreaMm,
          artworkMode: generated.designerAllowed ? 'online_designer' : 'professional_pdf_upload_only' } });
      }).catch(() => { if (active) setRollDocument(null); });
    }
    return () => { active = false; if (downloadUrl) URL.revokeObjectURL(downloadUrl); };
  }, [matchingRollLabelSelection, dbProductId, rollLabelContract, dbProduct?.tenant_id, rollDocumentKey]);
  const currentRollDocument = rollDocument?.key === rollDocumentKey && rollDocument.contract === rollLabelContract ? rollDocument.launch : null;
  const designerTemplateLaunch = useMemo(() => {
    if (hasRollLabelContract) return currentRollDocument;
    if (matrixPricingMeta.brochureFree) return matrixPricingMeta.brochureTemplate || null;
    if (isStorformat && storformatSelection?.templateShape) {
      return wideFormatTemplateLaunch(storformatSelection.templateShape, storformatSelection.widthCm * 10, storformatSelection.heightCm * 10);
    }
    return resolveSelectedDesignerTemplateLaunch({
      templates: availableProductTemplates,
      selectedFormat,
      selectedFormatLabel,
      selectedOptionLabels: isStorformat && storformatSelection
        ? [storformatSelection.productName, storformatSelection.materialName, storformatSelection.finishName].filter((label): label is string => Boolean(label))
        : matrixSelectionSummary,
      selectedSectionValues: isStorformat ? storformatSelection?.selectedSectionValues || {} : matrixSelectedSectionValues,
      ...(isStorformat ? { selectedDimensionsMm: storformatSelection
        ? { width: storformatSelection.widthCm * 10, height: storformatSelection.heightCm * 10 }
        : null } : {}),
    });
  }, [availableProductTemplates, isStorformat, storformatSelection, matrixSelectedSectionValues, matrixSelectionSummary, selectedFormat, selectedFormatLabel, matrixPricingMeta.brochureFree, matrixPricingMeta.brochureTemplate, hasRollLabelContract, currentRollDocument]);
  const approvedPrintModel = useApprovedPrintModel(designerTemplateLaunch, pricingStructure?.workspaceContent, matrixSelectedSectionValues);
  const approvedDesignerLaunch = useMemo(() => approvedPrintTemplateLaunch(designerTemplateLaunch, approvedPrintModel), [designerTemplateLaunch, approvedPrintModel]);
  const legacyLinkedTemplateId = useMemo(() => {
    if (pricingStructure?.mode === "matrix_layout_v1") {
      return resolveMatrixLinkedTemplateId(pricingStructure, matrixSelectedSectionValues);
    }
    return storformatSelection?.linkedTemplateId || null;
  }, [matrixSelectedSectionValues, pricingStructure, storformatSelection]);
  const hasConfigurationSpecificTemplates = useMemo(
    () => availableProductTemplates.some(templateHasSelectionConstraints),
    [availableProductTemplates],
  );
  const baseProductFlow = useMemo(() => resolveStorefrontProductFlow({
    name: dbProduct?.name || product?.name,
    category: dbProduct?.category || (product as any)?.category || null,
    pricing_type: dbProduct?.pricing_type || null,
    technical_specs: dbProduct?.technical_specs || null,
    template_files: dbProduct?.template_files || null,
  }), [dbProduct?.category, dbProduct?.name, dbProduct?.pricing_type, dbProduct?.technical_specs, dbProduct?.template_files, product]);
  const productFlow = useMemo(() => {
    if(hasRollLabelContract) return {...baseProductFlow,showDesignerButton:designerTemplateLaunch?.artworkMode === 'online_designer',
      showTemplateDownload:Boolean(designerTemplateLaunch), designerMode:'pdf_template' as const,
      designerCtaLabel:'Lav design', prefersTemplateOverlay:true,
      customerHelpText:'Du kan forberede designet. Pris og bestilling afventer godkendelse.'};
    if (baseProductFlow.designerMode === 'brochure' && selectedFormat === pricingStructure?.brochureFreeSize?.formatValueId && !matrixPricingMeta.brochureTemplate) {
      return { ...baseProductFlow, showDesignerButton: false, showTemplateDownload: false, customerHelpText: 'Vælg gyldige mål for at åbne brochurens sideskabelon.' };
    }
    if (isStorformat && storformatSelection?.templateShape?.kind === "freeform") return { ...baseProductFlow, designerMode: "storformat" as const, showDesignerButton: true, showTemplateDownload: false, prefersTemplateOverlay: false, requiresCutContour: true };
    if (isStorformat && designerTemplateLaunch) {
      return { ...baseProductFlow, showTemplateDownload: true, prefersTemplateOverlay: true, requiresCutContour: storformatSelection?.templateShape?.kind === "preset" || baseProductFlow.requiresCutContour };
    }
    if (isStorformat && storformatSelection?.templateShape) {
      return { ...baseProductFlow, showDesignerButton: false, showTemplateDownload: false, customerHelpText: "Vælg gyldige mål for at åbne skabelonen. Over 507,4 cm skal produktionsskalering aftales." };
    }
    const hasCompatibleLegacyTemplate = Boolean(legacyLinkedTemplateId) && !hasConfigurationSpecificTemplates;
    if (
      baseProductFlow.designerMode !== "pdf_template"
      || designerTemplateLaunch
      || hasCompatibleLegacyTemplate
    ) {
      return baseProductFlow;
    }

    return {
      ...baseProductFlow,
      badgeLabel: "Skabelon mangler for valget",
      customerHelpText: "Denne kombination kan bestilles med egen trykfil, men designeren åbnes først, når den korrekte PDF-skabelon er tilknyttet.",
      showDesignerButton: false,
      showTemplateDownload: false,
    };
  }, [baseProductFlow, designerTemplateLaunch, hasConfigurationSpecificTemplates, isStorformat, legacyLinkedTemplateId, storformatSelection?.templateShape, selectedFormat, pricingStructure?.brochureFreeSize?.formatValueId, matrixPricingMeta.brochureTemplate,hasRollLabelContract]);
  const currentDimensions = useMemo(() => {
    const techSpecs = dbProduct?.technical_specs;
    if(matchingRollLabelSelection?.widthMm && matchingRollLabelSelection.heightMm) return {
      width:matchingRollLabelSelection.widthMm,height:matchingRollLabelSelection.heightMm,
      bleed:rollLabelProfile?.sizeGeometry?.bleedMm ?? rollLabelProfile?.nativeGuide?.bleedMm ?? techSpecs?.bleed_mm ?? 3};
    const orient = <T extends { width: number; height: number }>(dimensions: T) => productArtworkDimensions(product, dimensions, matrixSelectionSummary);
    if (selectedFormatId) {
      const meta = valueMetaById[selectedFormatId];
      if (meta?.width_mm && meta?.height_mm) {
        return orient({
          width: meta.width_mm,
          height: meta.height_mm,
          bleed: typeof meta.bleed_mm === "number" ? meta.bleed_mm : (techSpecs?.bleed_mm || 3)
        });
      }
    }

    // 1. Try to get dimensions from the selected variant name (A4, A5, etc.)
    const fallbackLabel = selectedFormatId ? valueNameById[selectedFormatId] : "";
    const variantDims = getDimensionsFromVariant(
      fallbackLabel || selectedFormat || selectedVariantName || ""
    );
    if (variantDims) return orient({ ...variantDims, bleed: parseFloat(techSpecs?.bleed_mm) || 3 });

    // 2. Fall back to product-wide technical specs
    if (techSpecs) {
      return orient({
        width: techSpecs.width_mm || 210,
        height: techSpecs.height_mm || 297,
        bleed: techSpecs.bleed_mm || 3
      });
    }

    // 3. Ultimate default
    return orient({ width: 210, height: 297, bleed: 3 });
  }, [selectedFormatId, selectedFormat, selectedVariantName, dbProduct?.technical_specs, valueMetaById, valueNameById, product, matrixSelectionSummary,matchingRollLabelSelection,rollLabelProfile]);
  const designDimensions = useMemo(() => {
    if (baseProductFlow.designerMode === 'brochure' && selectedFormat === pricingStructure?.brochureFreeSize?.formatValueId) {
      return { width: matrixPricingMeta.brochureFree?.widthMm || 0, height: matrixPricingMeta.brochureFree?.heightMm || 0, bleed: 3 };
    }
    const isAreaBased = product?.id === "bannere" || product?.id === "skilte" || product?.id === "folie";
    if (isStorformat && storformatSelection) {
      return {
        width: storformatSelection.widthCm * 10,
        height: storformatSelection.heightCm * 10,
        bleed: currentDimensions.bleed
      };
    }
    if (isAreaBased) {
      return {
        width: customWidth * 10,
        height: customHeight * 10,
        bleed: currentDimensions.bleed
      };
    }
    return currentDimensions;
  }, [product?.id, isStorformat, storformatSelection, customWidth, customHeight, currentDimensions, baseProductFlow.designerMode, selectedFormat, pricingStructure?.brochureFreeSize?.formatValueId, matrixPricingMeta.brochureFree]);
  const designSafeAreaMm = useMemo(() => {
    if (hasRollLabelContract) return rollLabelProfile?.sizeGeometry?.safeMm ?? rollLabelProfile?.nativeGuide?.safeAreaMm;
    if (selectedFormatId) {
      const meta = valueMetaById[selectedFormatId];
      if (typeof meta?.safe_area_mm === "number") return meta.safe_area_mm;
    }
    if (typeof dbProduct?.technical_specs?.safe_area_mm === "number") {
      return dbProduct.technical_specs.safe_area_mm;
    }
    return undefined;
  }, [selectedFormatId, valueMetaById, dbProduct?.technical_specs,hasRollLabelContract,rollLabelProfile]);
  const formatGuideData = useMemo<ProductFormatGuideData | null>(() => {
    if (hasRollLabelContract) return rollLabelSelectionGuide(rollLabelProfile,matchingRollLabelSelection) || rollLabelProfile?.nativeGuide || null;
    if (!product || !selectedFormatLabel || designDimensions.width <= 0 || designDimensions.height <= 0) {
      return null;
    }

    const layoutKind = productFlow.designerMode === "brochure" ? "brochure" : selectionUsesFoldedLayout(product.name, selectedFormatLabel, ...matrixSelectionSummary)
      ? "folded"
      : "flat";
    const printSideLabel = matrixSelectionSummary.find((label) => (
      /4\+0|4\+4|en side|begge sider|enkeltsidet|dobbeltsidet/i.test(label)
    )) || null;
    const foldTypeLabel = matrixSelectionSummary.find((label) => /midterfals|rullefalset|zigzag/i.test(label)) || null;
    const pageCountLabel = matrixSelectionSummary.find((label) => /\d+\s*sider/i.test(label)) || null;
    const orientationLabel = matrixSelectionSummary.find((label) => /^(lodret|vandret)$/i.test(label)) || null;
    const swapFinishedDimensions = layoutKind === "folded"
      && /vandret/i.test(orientationLabel || "")
      && designDimensions.width !== designDimensions.height;
    const finishedWidthMm = swapFinishedDimensions ? designDimensions.height : designDimensions.width;
    const finishedHeightMm = swapFinishedDimensions ? designDimensions.width : designDimensions.height;

    return {
      productName: product.name,
      productImageUrl: dbProduct?.image_url || getProductImage(product.slug),
      formatLabel: selectedFormatLabel,
      finishedWidthMm: layoutKind === "folded"
        ? finishedWidthMm
        : (designerTemplateLaunch?.widthMm ?? designDimensions.width),
      finishedHeightMm: layoutKind === "folded"
        ? finishedHeightMm
        : (designerTemplateLaunch?.heightMm ?? designDimensions.height),
      dataWidthMm: layoutKind === "folded" ? designerTemplateLaunch?.widthMm : undefined,
      dataHeightMm: layoutKind === "folded" ? designerTemplateLaunch?.heightMm : undefined,
      bleedMm: designerTemplateLaunch?.bleedMm ?? designDimensions.bleed ?? 3,
      safeAreaMm: designerTemplateLaunch?.safeMm ?? designSafeAreaMm ?? 3,
      minDpi: Number(dbProduct?.technical_specs?.min_dpi || 300),
      layoutKind,
      brochurePageCount: brochurePageCount || undefined,
      printSideLabel,
      foldTypeLabel,
      pageCountLabel,
      foldGeometry: designerTemplateLaunch?.guideGeometry,
      template: designerTemplateLaunch
        ? {
            name: designerTemplateLaunch.name,
            url: designerTemplateLaunch.pdfUrl,
          }
        : null,
    };
  }, [
    hasRollLabelContract,
    rollLabelProfile,
    matchingRollLabelSelection,
    dbProduct?.image_url,
    dbProduct?.technical_specs?.min_dpi,
    designDimensions.bleed,
    designDimensions.height,
    designDimensions.width,
    designerTemplateLaunch,
    designSafeAreaMm,
    matrixSelectionSummary,
    product,
    selectedFormatLabel,
    productFlow.designerMode,
    brochurePageCount,
  ]);
  const linkedTemplateId = useMemo(() => {
    if (designerTemplateLaunch?.templateId) return designerTemplateLaunch.templateId;

    if (hasConfigurationSpecificTemplates && !designerTemplateLaunch) return null;

    return legacyLinkedTemplateId;
  }, [designerTemplateLaunch, hasConfigurationSpecificTemplates, legacyLinkedTemplateId]);
  const currentQuantity = useMemo(() => {
    if (isStorformat) return storformatSelection?.quantity || 0;
    return selectedCell?.column || 0;
  }, [isStorformat, selectedCell?.column, storformatSelection?.quantity]);
  const canvaReturnUrl = useMemo(() => {
    if (typeof window === "undefined") return null;

    const url = new URL("/canva-return", window.location.origin);
    const currentProductPath = `${window.location.pathname}${window.location.search}`;
    const computedTotalPrice = Math.round(
      Math.max(0, Number(productPrice || 0) + Number(optionExtraPrice || 0) + Number(shippingCost || 0)),
    );

    url.searchParams.set("backTo", currentProductPath);
    if (window.location.search) {
      url.searchParams.set("tenantQuery", window.location.search);
    }
    if (dbProduct?.id) {
      url.searchParams.set("productId", dbProduct.id);
    }
    if (slug) {
      url.searchParams.set("productSlug", slug);
    }
    if (dbProduct?.name || product?.name) {
      url.searchParams.set("productName", dbProduct?.name || product?.name || "");
    }
    if (currentQuantity > 0) {
      url.searchParams.set("quantity", String(currentQuantity));
    }
    if (selectedVariantName) {
      url.searchParams.set("selectedVariant", selectedVariantName);
    }
    if (selectedFormat) {
      url.searchParams.set("selectedFormat", selectedFormat);
    }
    if (typeof designDimensions.width === "number" && designDimensions.width > 0) {
      url.searchParams.set("widthMm", String(designDimensions.width));
    }
    if (typeof designDimensions.height === "number" && designDimensions.height > 0) {
      url.searchParams.set("heightMm", String(designDimensions.height));
    }
    if (typeof designDimensions.bleed === "number" && designDimensions.bleed >= 0) {
      url.searchParams.set("bleedMm", String(designDimensions.bleed));
    }
    if (typeof designSafeAreaMm === "number" && designSafeAreaMm >= 0) {
      url.searchParams.set("safeMm", String(designSafeAreaMm));
    }
    if (Number.isFinite(Number(productPrice)) && Number(productPrice) > 0) {
      url.searchParams.set("productPrice", String(Math.round(Number(productPrice))));
    }
    if (Number.isFinite(Number(optionExtraPrice)) && Number(optionExtraPrice) > 0) {
      url.searchParams.set("extraPrice", String(Math.round(Number(optionExtraPrice))));
    }
    if (Number.isFinite(Number(shippingCost)) && Number(shippingCost) > 0) {
      url.searchParams.set("shippingCost", String(Math.round(Number(shippingCost))));
    }
    if (computedTotalPrice > 0) {
      url.searchParams.set("totalPrice", String(computedTotalPrice));
    }

    return url.toString();
  }, [
    currentQuantity,
    dbProduct?.id,
    dbProduct?.name,
    designDimensions.bleed,
    designDimensions.height,
    designDimensions.width,
    designSafeAreaMm,
    optionExtraPrice,
    product?.name,
    productPrice,
    selectedFormat,
    selectedVariantName,
    shippingCost,
    slug,
  ]);
  const canvaOffer = useMemo(() => {
    const tenantCanva = (shopSettings.data as any)?.canva || null;
    const productCanva = (dbProduct?.technical_specs as any)?.canva || null;

    return resolveCanvaOffer(tenantCanva, productCanva, {
      productId: dbProduct?.id || null,
      productSlug: slug || null,
      productName: dbProduct?.name || product?.name || null,
      widthMm: designDimensions.width ?? null,
      heightMm: designDimensions.height ?? null,
      bleedMm: designDimensions.bleed ?? null,
      safeAreaMm: designSafeAreaMm ?? null,
      selectedFormat: selectedFormat || null,
      returnUrl: canvaReturnUrl,
    });
  }, [
    canvaReturnUrl,
    dbProduct?.id,
    dbProduct?.name,
    dbProduct?.technical_specs,
    designDimensions.bleed,
    designDimensions.height,
    designDimensions.width,
    designSafeAreaMm,
    product?.name,
    selectedFormat,
    shopSettings.data,
    slug,
  ]);
  const renderInStorefrontFrame = (content: any, mainClassName: string, topSlot?: any) => workspacePreview ? (
    <StorefrontThemeFrame branding={branding} orderDesign={orderDesign} tenantName={tenantName} contentOnly isPreviewMode><main data-tooltip-product={dbProductId} className="storefront-order-flow storefront-product-flow product-workspace-customer-preview">{content}</main></StorefrontThemeFrame>
  ) : (
    <StorefrontThemeFrame
      branding={branding}
      orderDesign={orderDesign}
      tenantName={tenantName}
      isPreviewMode={preview.isPreviewMode || Boolean(previewSlug)}
      topSlot={topSlot}
    >
      <main
        className={`${mainClassName} storefront-order-flow storefront-product-flow`}
        data-storefront-order-flow="product"
        data-tooltip-product={dbProductId}
      >
        <OrderDesignPreviewSwitch page="calculator" value={orderDesign} />
        {trialRequested && <div role="status" className="mb-6 rounded-lg border bg-muted p-4 text-sm">{DRAFT_FLOW_MESSAGE}</div>}
        {content}
      </main>
    </StorefrontThemeFrame>
  );
  if (loading) {
    return renderInStorefrontFrame(
      <div className="flex justify-center items-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>,
      "flex-1 container mx-auto px-4 py-16",
    );
  }

  // Not Found State
  if (!product) {
    return renderInStorefrontFrame(
      <h1 className="text-3xl font-heading font-bold text-center">Produkt ikke fundet</h1>,
      "flex-1 container mx-auto px-4 py-16",
    );
  }

  // Main Render
  const sizeDistributionBlock = sizeDistributionConfig ? (
    <div className="storefront-order-surface rounded-lg border border-border/60 bg-muted/20 p-4 space-y-3">
      <div>
        <p className="text-sm font-semibold">{sizeDistributionConfig.title}</p>
        <p className="text-xs text-muted-foreground">
          Ikke prispåvirkende. Brug felterne til at fordele størrelser på ordren.
        </p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {sizeDistributionFields.map((field) => (
          <label key={field.key} className="space-y-1">
            <span className="text-xs text-muted-foreground">{field.label}</span>
            <Input
              type="number"
              min={0}
              step={1}
              value={sizeDistributionValues[field.key] ?? 0}
              onChange={(event) => handleSizeDistributionChange(field.key, event.target.value)}
              className="h-9"
            />
          </label>
        ))}
      </div>
      <div className={`text-xs ${sizeDistributionMismatch ? "text-destructive" : "text-muted-foreground"}`}>
        Sum: {sizeDistributionTotal}
        {sizeDistributionSelectionQuantity > 0 ? ` / ${sizeDistributionSelectionQuantity}` : ""} stk
        {sizeDistributionMismatch ? " (matcher ikke valgt antal)" : ""}
      </div>
    </div>
  ) : null;

  const galleryImages = readProductGallery(pricingStructure?.workspaceContent);
  const gallerySelections = { ...galleryMatrixSelections(matrixSelectedSectionValues, pricingStructure?.vertical_axis, selectedCell?.row, valueNameById), _format: selectedFormat, _variant: selectedVariantName, _extra: selectedExtraOption };
  const folderPreviewSelection = { templateFiles: dbProduct?.template_files,
    workspaceContent: pricingStructure?.workspaceContent, selectedSectionValues: matrixSelectedSectionValues };
  const folderProductPreview = resolveProductFolderPreview(designerTemplateLaunch?.templatePdfSha256, folderPreviewSelection);
  const hasFolderProductMedia = hasProductFolderPreview(designerTemplateLaunch?.templatePdfSha256, folderPreviewSelection);
  const folderArtworkPreview = folderProductPreview?.print === '4+0' && designerTemplateLaunch
    && resolveFolderDefinition(designerTemplateLaunch.templatePdfSha256,
      (designerTemplateLaunch.widthMm ?? 0) + 2 * (designerTemplateLaunch.bleedMm ?? 0),
      (designerTemplateLaunch.heightMm ?? 0) + 2 * (designerTemplateLaunch.bleedMm ?? 0));
  const matchingFolderUpload = folderArtworkPreview && folderUploadDraft?.templateHash === designerTemplateLaunch?.templatePdfSha256
    ? folderUploadDraft.upload : approvedPrintModel && folderUploadDraft?.templateHash === approvedPrintModel.definition.templateHash
      ? folderUploadDraft.upload : undefined;
  // Image rules own photo changes; finish/material/price updates retain the mounted gallery.
  const productGallery = <ProductMediaGallery
    key={dbProductId} name={product.name}
    defaultImage={dbProduct?.image_url || getProductImage(product.slug)} images={galleryImages} selections={gallerySelections}
  />;
  const productMedia = approvedPrintModel || pricingStructure?.workspaceContent?.mediaFrame === 'folded-leaflet-v1' ? <ProductPrintMedia key={dbProductId}
    gallery={productGallery} preview={approvedPrintModel} color={branding?.colors?.primary}
    stablePhotoFrame={pricingStructure?.workspaceContent?.mediaFrame === 'folded-leaflet-v1'}
    artworkContext={approvedPrintModel && !preview.isPreviewMode ? { model: approvedPrintModel, templateHash: approvedPrintModel.definition.templateHash,
      tenantId: shopSettings.data?.id || "", productId: dbProductId! } : undefined}
    onArtworkUploaded={setFolderUploadDraft} /> : hasFolderProductMedia ? <ProductFolderMedia key={dbProductId}
    gallery={productGallery} preview={folderProductPreview} color={branding?.colors?.primary}
    artworkContext={folderArtworkPreview && !preview.isPreviewMode ? { definition: folderArtworkPreview, templateHash: designerTemplateLaunch!.templatePdfSha256!, tenantId: shopSettings.data?.id || "", productId: dbProductId! } : undefined}
    onArtworkUploaded={setFolderUploadDraft} />
    : pricingStructure?.workspaceGroups || galleryImages.length ? productGallery : undefined;
  const productIntro = (
        <div className="storefront-order-hero flex flex-col gap-5 sm:flex-row sm:items-start sm:justify-between sm:gap-8 mb-8" data-branding-id="productPage.heading">
          <div className="flex-1">
            {localRollPreview.requested && <p className="roll-label-status" role="status">Lokal produktprøve · bestilling er endnu ikke åbnet.</p>}
            {(() => {
              const ph = (branding as any)?.productPage?.heading;
              const headingText = ph?.customText?.trim() || product.name;
              const headingFont = ph?.font || 'inherit';
              const headingSize = ph?.sizePx ? `${ph.sizePx}px` : undefined;
              const headingColor = ph?.color || undefined;
              const subtext = ph?.subtext;
              const bodyFont = (branding as any)?.fonts?.body || 'inherit';
              const bodyColor = (branding as any)?.colors?.bodyText || undefined;
              return (
                <>
                  <h1
                    className="font-bold mb-2 leading-tight"
                    style={{
                      fontFamily: headingFont !== 'inherit' ? `'${headingFont}', sans-serif` : undefined,
                      fontSize: headingSize,
                      color: headingColor,
                    }}
                  >
                    {headingText}
                  </h1>
                  {subtext?.enabled && subtext?.text?.trim() && (
                    <p
                      className="font-bold mb-2"
                      style={{
                        fontFamily: subtext.font && subtext.font !== 'inherit' ? `'${subtext.font}', sans-serif` : undefined,
                        fontSize: subtext.sizePx ? `${subtext.sizePx}px` : undefined,
                        color: subtext.color || undefined,
                      }}
                    >
                      {subtext.text}
                    </p>
                  )}
                  {product.description && (
                    <p
                      className="text-muted-foreground"
                      style={{
                        fontFamily: bodyFont !== 'inherit' ? `'${bodyFont}', sans-serif` : undefined,
                        color: bodyColor,
                      }}
                    >
                      {product.description}
                    </p>
                  )}
                </>
              );
            })()}
          </div>
          {product && !productMedia && (
            <div className="storefront-order-product-image w-full h-40 flex-shrink-0 sm:w-48 sm:h-48">
              <img
                src={dbProduct?.image_url || getProductImage(product.slug)}
                alt={product.name}
                className="w-full h-full object-contain"
                style={{ filter: 'var(--product-filter)' }}
              />
            </div>
          )}
        </div>
  );

  const infoBelowCalculator = isStorformat && (product.slug === 'gulvfolie'
    || dbProduct?.technical_specs?.supplier_import_review?.runId === 'wmd-gulvfolie-2026-09-30');
  const staticProductInfo = <StaticProductInfo
    productId={dbProductId || product.slug || product.id}
    selectedFormat={selectedFormat}
    selectedFormatLabel={selectedFormatLabel}
    selectedOptionLabels={matrixSelectionSummary}
    selectedSectionValues={matrixSelectedSectionValues}
    showTemplateDownloads={false}
    formatGuide={formatGuideData}
    productData={dbProduct}
  />;

  const renderPricingInterface = () => {
    if (isStorformat && dbProductId) {
      const storformatDeliveryBusinessDayOffset = storformatSelection?.deliveryBusinessDayOffset ?? (/fast production/i.test(
        storformatSelection?.productName || ""
      )
        ? 2
        : 0);
      const summaryParts = [
        product?.name,
        storformatSelection ? `${storformatSelection.widthCm} x ${storformatSelection.heightCm} cm` : null,
        storformatSelection?.materialName,
        storformatSelection?.finishName || null,
        storformatSelection?.productName || null,
        storformatSelection ? `${storformatSelection.quantity} stk` : null,
        sizeDistributionSummary || null,
      ].filter(Boolean);

      return <StorformatConfigurator
        productId={dbProductId}
        fastProductionDayOffset={dbProduct?.banner_config?.production_timing?.fast_business_days_saved}
        initialState={restoredCheckoutSelection}
        sourceShapeBindings={readWideFormatShapeBindings(dbProduct?.technical_specs)}
        onSelectionChange={handleStorformatSelection}
        layout={{ design: orderDesign, intro: productIntro, media: productMedia,
          details: infoBelowCalculator ? staticProductInfo : undefined,
          extras: <><DynamicProductOptions productId={dbProductId} onSelectionChange={handleOptionSelectionChange} />{sizeDistributionBlock}</>,
          summary: (productionControls) => (
            <ProductPricePanel
              workspaceTenantId={dbProduct?.tenant_id || shopSettings.data?.id}
              localWorkspacePreview={Boolean(savedBrochurePreview)}
              productionControls={productionControls}
              productArtworkUpload={matchingFolderUpload}
              presentation="order-flow"
              productId={dbProductId}
              quantity={storformatSelection?.quantity || 0}
              productPrice={storformatSelection?.totalPrice || 0}
              extraPrice={optionExtraPrice}
              branding={shopSettings.data?.branding}
              deliveryBusinessDayOffset={storformatDeliveryBusinessDayOffset}
              orderValidationError={orderValidationError}
              onShippingChange={handleShippingChange}
              optionSelections={combinedOptionSelections}
              pricingQuote={pricingQuote}
              selectedVariant={storformatSelection?.materialName}
              productName={product?.name || ''}
              productSlug={slug || ''}
              selectedFormat={storformatSelection ? `${storformatSelection.widthCm} x ${storformatSelection.heightCm} cm` : undefined}
              linkedTemplateId={linkedTemplateId}
              orderDeliveryConfig={orderDeliveryConfig}
              designWidthMm={designDimensions.width}
              designHeightMm={designDimensions.height}
              designBleedMm={designDimensions.bleed}
              designSafeAreaMm={designSafeAreaMm}
              designerTemplateLaunch={approvedDesignerLaunch}
              stableArtworkLayout={pricingStructure?.workspaceContent?.mediaFrame === 'folded-leaflet-v1'}
              productFlow={productFlow}
              brochurePageCount={brochurePageCount}
              externalDeliveryEnabled={podShippingEnabled}
              externalDeliveryMethods={podShippingMethods}
              externalDeliveryLoading={podShippingLoading}
              externalDeliveryError={podShippingError}
              externalDeliveryConfig={orderDeliveryConfig?.delivery?.pod_settings}
              canvaOffer={canvaOffer}
              formatGuide={formatGuideData}
              summary={summaryParts.join(' • ')}
              companyContext={companyContext}
            />
          ),
        }}
      />;
    }

    if (pricingStructure?.mode === 'matrix_layout_v1' && dbProductId) {
      const featuredSelection = resolveFeaturedMatrixSelection(readFeaturedMatrixSelection(searchParams), pricingStructure);
      const initialSelection = featuredSelection?.selection || (!featuredSelection ? restoredCheckoutSelection?.pricingQuote?.selectedSectionValues : undefined);
      const calculator = (
        <MatrixLayoutV1Renderer
          rollLabelMatrix={hasRollLabelContract ? <RollLabelPriceMatrix packet={displayedRollLabelPrices} profile={rollLabelProfile}
            selection={matchingRollLabelSelection} materialLabel={rollLabelProfile ? valueNameById[rollLabelProfile.materialValueId] || 'Valgt materiale' : 'Materiale'} onChoose={chooseRollLabelPrice} /> : undefined}
          productId={dbProductId}
          columnUnit={rollMatrixColumnUnit}
          pricingStructure={pricingStructure}
          exactCombinationSelections={rollExactSelections ?? (productFlow?.designerMode === "brochure" && pricingStructure?.brochureCompatibility?.version === 1 ? pricingStructure.brochureCompatibility.selections : exactTemplateCombinationSelections)}
          key={`${dbProductId}:${searchParams.get('featuredVariant') || ''}:${searchParams.get('featuredRow') || ''}:${searchParams.get('qty') || ''}`}
          initialSelection={initialSelection}
          initialSelectedRow={featuredSelection ? featuredSelection.row : restoredCheckoutSelection?.selectedVariant || undefined}
          initialSelectedQuantity={featuredSelection ? featuredSelection.quantity : restoredCheckoutSelection?.quantity || undefined}
          featuredSelectionUnavailable={featuredSelection?.unavailable}
          isFeaturedSelection={Boolean(featuredSelection)}
          initialBrochureFree={featuredSelection ? undefined : restoredCheckoutSelection?.pricingQuote?.brochureFree}
          onCellClick={handleMatrixCellClick}
          onSelectionSummary={setMatrixSelectionSummary}
          onQuantityTiers={setMatrixQuantityTiers}
          onSelectionChange={handleMatrixSelectionChange}
          layout={{ design: orderDesign, intro: productIntro, media: productMedia,
            extras: <>
              {!hasRollLabelContract && <DynamicProductOptions
                productId={dbProductId}
                onSelectionChange={handleOptionSelectionChange}
              />}
              {sizeDistributionBlock}
              {hasRollLabelContract && (rollLabelContract && rollLabelProfile ? <RollLabelConfiguration key={dbProductId}
                profile={rollLabelProfile} productId={dbProductId} familyId={rollLabelContract.familyId}
                initialSelection={initialRollLabelSelection}
                onChange={setRollLabelSelection} pricePreview /> : <p role="status">Vælg en dokumenteret form og et materiale.</p>)}
            </>,
            summary: (
              <ProductPricePanel
              workspaceTenantId={dbProduct?.tenant_id || shopSettings.data?.id}
              localWorkspacePreview={Boolean(savedBrochurePreview)}
                productArtworkUpload={matchingFolderUpload}
                presentation="order-flow"
                productId={dbProductId}
                quantity={hasRollLabelContract ? matchingRollLabelSelection?.quantity || 0 : selectedCell?.column || 0}
                productPrice={hasRollLabelContract ? rollLabelPrice?.priceDkk || 0 : productPrice}
                priceIsProposal={hasRollLabelContract}
                extraPrice={hasRollLabelContract ? 0 : optionExtraPrice}
                branding={shopSettings.data?.branding}
                orderValidationError={orderValidationError}
                onShippingChange={handleShippingChange}
                optionSelections={combinedOptionSelections}
                pricingQuote={pricingQuote}
                selectedVariant={hasRollLabelContract ? rollLabelProfile ? valueNameById[rollLabelProfile.materialValueId] : undefined : selectedCell?.row}
                productName={product?.name || ''}
                productSlug={slug || ''}
                selectedFormat={selectedFormat}
                linkedTemplateId={linkedTemplateId}
                orderDeliveryConfig={orderDeliveryConfig}
                designWidthMm={designDimensions.width}
                designHeightMm={designDimensions.height}
                designBleedMm={designDimensions.bleed}
                designSafeAreaMm={designSafeAreaMm}
                designerTemplateLaunch={approvedDesignerLaunch}
              stableArtworkLayout={pricingStructure?.workspaceContent?.mediaFrame === 'folded-leaflet-v1'}
                productFlow={productFlow}
              brochurePageCount={brochurePageCount}
                externalDeliveryEnabled={hasRollLabelContract || podShippingEnabled}
                externalDeliveryMethods={hasRollLabelContract ? [] : podShippingMethods}
                externalDeliveryLoading={podShippingLoading}
                externalDeliveryError={podShippingError}
                externalDeliveryConfig={orderDeliveryConfig?.delivery?.pod_settings}
                canvaOffer={canvaOffer}
                formatGuide={formatGuideData}
                summary={[
                  product?.name,
                  ...matrixSelectionSummary,
                  selectedCell?.row,
                  selectedCell ? `${selectedCell.column} stk` : '',
                  sizeDistributionSummary || '',
                ].filter(Boolean).join(' • ')}
                companyContext={companyContext}
              />
            ),
          }}
        />
      );
      return localRollPreview.packet ? <WorkspaceSourcesContext.Provider value={{productId:dbProductId,sourceGroups:localRollPreview.packet.sourceGroups}}>{calculator}</WorkspaceSourcesContext.Provider> : calculator;
    }

    const isAreaBased = product.id === "bannere" || product.id === "skilte" || product.id === "folie";
    const optionsBlock = dbProductId ? (
      <div className="mb-6">
        <DynamicProductOptions
          productId={dbProductId}
          onSelectionChange={handleOptionSelectionChange}
        />
      </div>
    ) : null;

    return (
      <ProductCalculatorLayout
        design={orderDesign}
        intro={productIntro}
        media={productMedia}
        controls={<>
          {/* For non-area products, keep options above */}
          {!isAreaBased && optionsBlock}

          {isGenericPricing && genericVariantNames.length > 1 && (
            <div>
              <label className="text-base font-semibold mb-3 block">Vælg produkttype</label>
              <div className="flex flex-wrap gap-2">
                {genericVariantNames.map((name) => (
                  <button
                    key={name}
                    onClick={() => setSelectedVariantName(name)}
                    className={`px-4 py-2 rounded-lg border-2 transition-all font-medium ${selectedVariantName === name
                      ? "border-primary bg-primary text-primary-foreground"
                      : "border-border hover:border-primary/50"
                      }`}
                  >
                    {formatVariantLabel(name)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {config && (
            <ProductFilters
              formats={config.formats}
              extraOptions={config.extraOptions}
              selectedFormat={selectedFormat}
              selectedExtraOption={selectedExtraOption}
              onFormatChange={setSelectedFormat}
              onExtraOptionChange={setSelectedExtraOption}
              extraOptionsLabel={config.extraOptionsLabel}
            />
          )}

          {isAreaBased && (
            <div className="storefront-order-surface">
              <CustomDimensionsCalculator onAreaChange={handleAreaChange} />
            </div>
          )}

          {/* For area-based products, show options below width/height calculator (e.g., lamination) */}
          {isAreaBased && optionsBlock}

          {sizeDistributionBlock}
        </>}
        matrix={
          mpaConfig ? (
            <MachineConfigurator
              productId={dbProductId || ""}
              width={0}
              height={0}
              engineVersion={(dbProduct?.technical_specs as any)?.machine_pricing?.engine === "v2_pilot" ? "v2_pilot" : "v1"}
              engineConfig={(dbProduct?.technical_specs as any)?.machine_pricing || undefined}
              onPriceUpdate={(data) => {
                console.log('[ProductPrice] Received from MachineConfigurator:', data);
                setProductPrice(data.totalPrice);
                // Update selected cell mock to satisfy ProductPricePanel
                setSelectedCell({ row: data.materialName || "Special", column: data.quantity });
              }}
            />
          ) : (
            <PriceMatrix
              rows={matrixData.rows}
              columns={matrixData.columns}
              cells={matrixData.cells}
              onCellClick={handleCellClick}
              selectedCell={selectedCell}
              columnUnit="stk"
              customArea={isAreaBased ? customArea : undefined}
              basePricePerSqm={isAreaBased ? basePricePerSqm : undefined}
              computeExtras={(qty, area) => computeOptionExtras(optionSelections, qty, area || 1)}
            />
          )
        }
        summary={
          <ProductPricePanel
              workspaceTenantId={dbProduct?.tenant_id || shopSettings.data?.id}
              localWorkspacePreview={Boolean(savedBrochurePreview)}
            productArtworkUpload={matchingFolderUpload}
            presentation="order-flow"
            productId={dbProductId || ""}
            quantity={selectedCell?.column || 0}
            productPrice={productPrice}
            extraPrice={optionExtraPrice}
            branding={shopSettings.data?.branding}
            orderValidationError={orderValidationError}
            onShippingChange={handleShippingChange}
            optionSelections={combinedOptionSelections}
            pricingQuote={pricingQuote}
            selectedVariant={selectedCell?.row}
            productName={product.name}
            productSlug={slug || ""}
            selectedFormat={selectedFormat}
            linkedTemplateId={linkedTemplateId}
            orderDeliveryConfig={orderDeliveryConfig}
            designWidthMm={designDimensions.width}
            designHeightMm={designDimensions.height}
            designBleedMm={designDimensions.bleed}
            designSafeAreaMm={designSafeAreaMm}
            designerTemplateLaunch={approvedDesignerLaunch}
              stableArtworkLayout={pricingStructure?.workspaceContent?.mediaFrame === 'folded-leaflet-v1'}
            productFlow={productFlow}
              brochurePageCount={brochurePageCount}
            externalDeliveryEnabled={podShippingEnabled}
            externalDeliveryMethods={podShippingMethods}
            externalDeliveryLoading={podShippingLoading}
            externalDeliveryError={podShippingError}
            externalDeliveryConfig={orderDeliveryConfig?.delivery?.pod_settings}
            canvaOffer={canvaOffer}
            formatGuide={formatGuideData}
            summary={[
              product.name,
              // For area-based products, show custom dimensions instead of format
              (product.id === "bannere" || product.id === "skilte" || product.id === "folie")
                ? `${customWidth} x ${customHeight} cm`
                : (selectedFormat ? config?.formats.find(f => f.id === selectedFormat)?.label : ""),
              selectedCell ? selectedCell.row : "",
              selectedExtraOption ? config?.extraOptions?.find(e => e.id === selectedExtraOption)?.label : "",
              selectedCell ? `${selectedCell.column} stk` : "",
              sizeDistributionSummary || "",
            ].filter(Boolean).join(" • ")}
            companyContext={companyContext}
          />
        }
      />
    );
  };

  if (workspacePreview && cardPreview && dbProduct) {
    const card = { ...previewCatalog.products.find(item => item.id === dbProduct.id), ...dbProduct, id: dbProduct.id, slug: slug || '', category: dbProduct.category || 'tryksager', categoryKey: dbProduct.category || 'tryksager', categoryLabel: '', pricing_type: dbProduct.pricing_type || 'matrix', default_variant: null, default_quantity: null, banner_config: dbProduct.banner_config || {}, tooltip_product: null, tooltip_price: null, displayPrice: dbProduct.banner_config?.price_from ? `Fra ${dbProduct.banner_config.price_from} kr` : previewCatalog.products.find(item => item.id === dbProduct.id)?.displayPrice };
    const cardPresentation = resolveProductPresentation(branding?.forside?.productsSection?.presentation);
    return <StorefrontThemeFrame branding={branding} tenantName={tenantName} contentOnly isPreviewMode><div className="product-workspace-card-preview" onClickCapture={event => { if ((event.target as HTMLElement).closest('a')) event.preventDefault(); }}>{cardPresentation !== "standard" ? <ProductPresentationCard product={card} branding={branding} layout={cardPresentation}/> : <ProductGrid category="__all__" products={[card]} loadingOverride={false} buttonConfig={branding?.forside?.productsSection?.button} layoutStyle={(branding?.forside?.productsSection as any)?.layoutStyle || "cards"} />}</div></StorefrontThemeFrame>;
  }

  return renderInStorefrontFrame(
    <>
        {fallbackNotice && (
          <div className="mb-6 rounded-md border border-yellow-200 bg-yellow-50 px-4 py-3 text-sm text-yellow-800">
            {fallbackNotice}
          </div>
        )}

        {renderPricingInterface()}

        {!infoBelowCalculator && staticProductInfo}

        {/* Debug Overlay */}
        {searchParams.get('debug') === 'true' && (
          <div className="fixed bottom-4 right-4 bg-black/80 text-white p-4 rounded text-xs z-50 max-w-sm overflow-auto max-h-screen">
            <h3 className="font-bold border-b border-gray-600 mb-2">Debug Info</h3>
            <div>Product ID: <span className="font-mono bg-gray-700 px-1">{dbProductId}</span></div>
            <div>Slug: {slug}</div>
            <div>Pricing Mode: {pricingStructure?.mode || 'generic'}</div>
            <div>Generic Variants: {genericVariantNames.length}</div>
            <div>Matrix Rows: {matrixData.rows.length}</div>
            <div>Matrix Cols: {matrixData.columns.length}</div>
          </div>
        )}
    </>,
    "flex-1 container mx-auto px-4 py-8",
    <>
      <SEO
        title={`${product.name} | ${tenantName}`}
        description={product.description}
        image={dbProduct?.tenant_id === PVCBANNER_TENANT_ID ? (dbProduct?.image_url || getProductImage(product.slug)) : undefined}
        forceRender
      />
      <ProductSchema
        name={product.name}
        description={product.description}
        price={productPrice || 99}
        omitOffers={dbProduct?.tenant_id === PVCBANNER_TENANT_ID}
        brand={dbProduct?.tenant_id === PVCBANNER_TENANT_ID ? "PVCbanner.dk" : undefined}
        image={dbProduct?.image_url || getProductImage(product.slug)}
      />
      <BreadcrumbSchema
        items={[
          { name: 'Forside', url: '/' },
          { name: 'Produkter', url: '/produkter' },
          { name: product.name, url: `/produkt/${slug}` }
        ]}
      />
    </>,
  );
};

export default ProductPrice;
