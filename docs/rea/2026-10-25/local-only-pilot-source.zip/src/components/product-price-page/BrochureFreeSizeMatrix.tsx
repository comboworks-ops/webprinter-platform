import { EditableNumberInput } from '@/components/ui/editable-number-input';
import { useEffect, useRef, useState, type ComponentProps } from 'react';
import { PriceMatrix } from './PriceMatrix';
import { generateWideFormatTemplate } from '@/lib/designer/generateWideFormatTemplate';
import { rectangleShape, wideFormatTemplateLaunch } from '@/lib/designer/wideFormatGeometry';
import { validBrochureFreeSize, type BrochureFreeMatrixMeta, type BrochureFreeSelection, type BrochureFreeSizeConfig } from '@/lib/pricing/brochureFreePricing';
import { brochureQuoteLoader, type BrochureQuotePrices } from '@/lib/storefront/brochureQuoteLoader';
import '@/styles/brochureProduct.css';

type Props = {
  config: BrochureFreeSizeConfig; selectedSectionValues: Record<string, string | null>;
  valueNames: Record<string, string>; initialSelection?: BrochureFreeSelection | null; initialQuantity?: number;
  matrixBox?: ComponentProps<typeof PriceMatrix>['matrixBox'];
  onSelectionChange?: (selections: Record<string, string | null>, formatId?: string, materialId?: string, meta?: BrochureFreeMatrixMeta) => void;
  onCellClick?: (row: string, quantity: number, price: number) => void;
  onQuantityTiers?: (tiers: Array<{ quantity: number; price: number }>) => void;
};
type RowState = { scope: string; quotes: Record<string, BrochureQuotePrices>; loading: Record<string, boolean>; errors: Record<string, string> };
const emptyRows = (scope: string): RowState => ({ scope, quotes: {}, loading: {}, errors: {} });
// Only the protocol's confirmed missing-price-table response removes a paper.
// Network failures remain visible and retryable; they do not prove unavailability.
const supplierUnavailableMessage = 'Papirkombinationen er midlertidigt utilgængelig.';

/** The normal branded matrix displays unchanged exact source quotes. Only their delivery is automatic. */
export default function BrochureFreeSizeMatrix(props: Props) {
  const { config, selectedSectionValues, valueNames } = props;
  const article = config.articles.find(value => value.pageCountValueId === selectedSectionValues[config.axisSections.pageCount]);
  const [width, setWidth] = useState(props.initialSelection?.widthMm ?? 148);
  const [height, setHeight] = useState(props.initialSelection?.heightMm ?? 210);
  const scope = `${article?.articleId}:${width}x${height}`;
  const [rowState, setRowState] = useState<RowState>(() => emptyRows(scope));
  const rows = rowState.scope === scope ? rowState : emptyRows(scope);
  const rowsRef = useRef(rows); rowsRef.current = rows;
  const [selected, setSelected] = useState<{ scope: string; materialId: string; quantity: number } | null>(null);
  const [error, setError] = useState('');
  const [retryVersion, setRetryVersion] = useState(0);
  const retries = useRef(new Set<string>());
  const callbacks = useRef(props); callbacks.current = props;
  const currentScope = useRef(scope); currentScope.current = scope;
  const template = useRef<BrochureFreeMatrixMeta['brochureTemplate']>(null);
  const pricedChoice = useRef<{ materialId: string; quantity: number; price: number; prices: BrochureQuotePrices } | null>(null);
  const manualSelection = useRef(false), initialRequote = useRef(false);
  const restore = useRef<{ scope: string; materialId: string; quantity: number } | null>(null);
  const valid = validBrochureFreeSize(width, height);
  const selectionFor = (nativePaperId: string): BrochureFreeSelection | null => article && valid
    ? { articleId: article.articleId, nativePaperId, pageCount: article.pageCount, widthMm: width, heightMm: height } : null;
  const emit = (materialId: string | null, quantity = 0, price = 0, prices: BrochureQuotePrices = []) => {
    const material = article?.materials.find(value => value.materialValueId === materialId);
    const selections = { ...selectedSectionValues, [config.axisSections.paperCover]: materialId };
    const variantKey = Object.entries(selections).filter(([key]) => key !== config.axisSections.paperCover)
      .map(([, value]) => value).filter(Boolean).sort().join('|');
    callbacks.current.onSelectionChange?.(selections, config.formatValueId, materialId || undefined,
      { variantKey, verticalValueId: materialId || undefined, brochureFree: material ? selectionFor(material.nativePaperId) : null,
        brochureTemplate: valid ? template.current : null });
    callbacks.current.onQuantityTiers?.(prices.map(([quantity, price]) => ({ quantity, price })));
    callbacks.current.onCellClick?.(materialId ? valueNames[materialId] || '' : '', quantity, price);
  };
  useEffect(() => {
    const expectedScope = scope;
    setRowState(emptyRows(scope)); setSelected(null); setError('');
    template.current = null; pricedChoice.current = null; manualSelection.current = false; restore.current = null;
    emit(null);
    if (!article || !valid) return;
    const launch = wideFormatTemplateLaunch(rectangleShape, width, height)!;
    void generateWideFormatTemplate(launch.pdfUrl).then(async bytes => {
      const hash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', bytes.slice().buffer)))
        .map(value => value.toString(16).padStart(2, '0')).join('');
      if (currentScope.current !== expectedScope) return;
      template.current = { ...launch, templatePdfSha256: hash };
      const choice = pricedChoice.current;
      if (choice) emit(choice.materialId, choice.quantity, choice.price, choice.prices);
      else emit(article.materials[0]?.materialValueId || null);
    }).catch(failure => { if (currentScope.current === expectedScope) setError((failure as Error).message); });
    // Callback refs avoid invalidating an exact quote when the parent accepts a selection.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope]);
  const materials = article?.materials || [];
  const shownMaterials = materials.filter(m => rows.errors[m.materialValueId] !== supplierUnavailableMessage);
  const materialIds = materials.map(m => m.materialValueId).join('|');
  useEffect(() => {
    if (!article || !valid) return;
    const controller = new AbortController(), expectedScope = scope;
    const timer = window.setTimeout(() => {
      const initial = callbacks.current.initialSelection;
      if (!initialRequote.current && initial && initial.articleId === article.articleId && initial.pageCount === article.pageCount
        && initial.widthMm === width && initial.heightMm === height) {
        initialRequote.current = true;
        const material = article.materials.find(m => m.nativePaperId === initial.nativePaperId);
        if (material && callbacks.current.initialQuantity) restore.current = { scope, materialId: material.materialValueId, quantity: callbacks.current.initialQuantity };
      }
      const ids = [...new Set([...(restore.current?.scope === scope ? [restore.current.materialId] : []), ...materialIds.split('|').filter(Boolean)])];
      const restoreSelection = (id: string, prices: BrochureQuotePrices) => {
        const target = restore.current;
        if (!target || target.scope !== scope || target.materialId !== id || manualSelection.current) return;
        const match = prices.find(([quantity]) => quantity === target.quantity);
        restore.current = null;
        if (match) { pricedChoice.current = { materialId: id, quantity: match[0], price: match[1], prices };
          setSelected({ scope, materialId: id, quantity: match[0] }); emit(id, match[0], match[1], prices); }
      };
      for (const id of ids) {
        const material = article.materials.find(m => m.materialValueId === id);
        if (!material) continue;
        const existing = rowsRef.current.quotes[id];
        if (existing) { restoreSelection(id, existing); continue; }
        if (rowsRef.current.errors[id] && !retries.current.has(id)) continue;
        retries.current.delete(id);
        const source = selectionFor(material.nativePaperId)!;
        setRowState(previous => ({ ...(previous.scope === scope ? previous : emptyRows(scope)),
          loading: { ...(previous.scope === scope ? previous.loading : {}), [id]: true },
          errors: { ...(previous.scope === scope ? previous.errors : {}), [id]: '' } }));
        void brochureQuoteLoader.load(config.quoteEndpoint, source, controller.signal).then(prices => {
          if (controller.signal.aborted || currentScope.current !== expectedScope) return;
          setRowState(previous => ({ ...previous, quotes: { ...previous.quotes, [id]: prices }, loading: { ...previous.loading, [id]: false } }));
          restoreSelection(id, prices);
        }).catch(failure => {
          if (controller.signal.aborted || currentScope.current !== expectedScope) return;
          setRowState(previous => ({ ...previous, loading: { ...previous.loading, [id]: false }, errors: { ...previous.errors, [id]: (failure as Error).message } }));
        });
      }
    }, 350);
    return () => { window.clearTimeout(timer); controller.abort(); };
    // Check every configured paper. Availability responses must not restart the queue.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scope, materialIds, retryVersion]);
  const quantities = [...new Set(Object.values(rows.quotes).flatMap(prices => prices.map(([quantity]) => quantity)))].sort((a, b) => a - b);
  const cells = Object.fromEntries(Object.entries(rows.quotes).map(([id, prices]) => [id, Object.fromEntries(prices)]));
  const loading = shownMaterials.some(m => !rows.quotes[m.materialValueId] && !rows.errors[m.materialValueId]);
  return <section className="brochure-native-free" aria-label="Fri størrelse, papir og antal">
    <div className="brochure-size-inputs">
      <label>Bredde, mm<EditableNumberInput type="number" min={98} max={297} step={.1} value={width} onChange={event => setWidth(Number(event.target.value))} /></label>
      <span aria-hidden="true">×</span>
      <label>Højde, mm<EditableNumberInput type="number" min={98} max={297} step={.1} value={height} onChange={event => setHeight(Number(event.target.value))} /></label>
    </div>
    <p>Begge mål skal være 98–297 mm. Priserne gælder de valgte mål og er ekskl. moms.</p>
    {!valid && <p role="alert">Vælg mål fra 98 til 297 mm i trin på 0,1 mm.</p>}
    {error && <p role="alert">{error}</p>}
    {valid && loading && <p role="status">Priserne hentes automatisk. Du kan vælge blandt de priser, der er klar.</p>}
    <PriceMatrix key={scope} rows={shownMaterials.map(m => m.materialValueId)} columns={quantities} cells={cells}
      rowHeaderLabel="Papir / Antal" matrixBox={props.matrixBox}
      getRowAccessibleLabel={id => (valueNames[id] || id).replace(/\|\|/g, ' / ')}
      renderRowLabel={id => <span className="block min-w-0 break-words">
        {(valueNames[id] || '').split('||').map((part, index) => <span key={index} className="block">{part.trim()}</span>)}
        {!rows.quotes[id] && !rows.errors[id] && valid && <span className="block text-xs font-normal text-muted-foreground">Henter priser…</span>}
        {rows.errors[id] && <span className="block text-xs font-normal text-muted-foreground">{rows.errors[id]}
          <button type="button" className="block underline" title={rows.errors[id]} aria-label={`Prøv igen: ${valueNames[id]}`}
            onClick={() => { retries.current.add(id); setRetryVersion(v => v + 1); }}>Prøv igen</button></span>}
      </span>}
      isCellUnavailable={(row, quantity) => cells[row]?.[quantity] == null}
      selectedCell={selected?.scope === scope ? { row: selected.materialId, column: selected.quantity } : null}
      onCellClick={(row, quantity) => {
        const prices = rows.quotes[row], price = prices?.find(([q]) => q === quantity)?.[1];
        if (!price || !valid) return;
        manualSelection.current = true; restore.current = null;
        pricedChoice.current = { materialId: row, quantity, price, prices };
        setSelected({ scope, materialId: row, quantity }); emit(row, quantity, price, prices);
      }} />
    {valid && !shownMaterials.length && !loading && <p role="status">Der er ingen tilgængelige papirkombinationer til de valgte mål og sidetal.</p>}
  </section>;
}
