import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { StorefrontThemeFrame } from '@/components/storefront/StorefrontThemeFrame';
import { useShopSettings } from '@/hooks/useShopSettings';
import { useOrderFlowDesign } from '@/hooks/useOrderFlowDesign';
import { OrderCheckoutLayout } from './OrderFlowLayouts';
import { readLocalWorkspaceCheckout, validateLocalWorkspaceCheckout } from '@/lib/designer/localWorkspaceCheckout';
import { workspacePath } from '@/lib/designer/localDesignWorkspace';
import { getSafeInternalPath } from '@/lib/designer/orderFlowNavigation';
import type { WorkspaceCheckoutBundle, WorkspaceCheckoutFile } from '@/lib/designer/workspaceCheckoutModel';
import type { BrochureSavedPreview } from '@/dev/brochureSavedPreview';
import { workspaceDeliveryPreview } from '@/lib/designer/workspaceDeliveryPreview';
import { resolveDeliveryMethodCost } from '@/lib/delivery/defaults';
import { deliveryAddressLines } from '@/lib/checkout/addressIntegrity';
import { emptyLocalCheckoutAddress, localCheckoutAddressErrors, localContactFields, type LocalContactKey } from '@/lib/designer/localCheckoutAddress';

const deliveryChoiceKey = (workspaceId: string) => `webprinter-local-delivery-v1:${workspaceId}`;
function readDeliveryChoice(workspaceId: string) {
  try {
    const stored = JSON.parse(localStorage.getItem(deliveryChoiceKey(workspaceId)) || 'null');
    return { methodId: typeof stored?.methodId === 'string' ? stored.methodId.slice(0, 100) : '',
      country: typeof stored?.country === 'string' ? stored.country.slice(0, 32) : 'DK' };
  } catch { return { methodId: '', country: 'DK' }; }
}

function DesignFile({ file }: { file: WorkspaceCheckoutFile }) {
  const [url, setUrl] = useState('');
  useEffect(() => { const next = URL.createObjectURL(file.pdf); setUrl(next); return () => URL.revokeObjectURL(next); }, [file.pdf]);
  return <article className="rounded-lg border p-4" aria-label={file.name}>
    <h3 className="font-semibold">{file.name}</h3><p>{file.quantity} stk · Version {file.revision} · Godkendt korrektur</p>
    {file.preview && <img className="my-3 max-h-40 max-w-full object-contain" src={file.preview} alt={`Korrektur af ${file.name}`} />}
    <a className="underline" href={url || undefined} download={`${file.name}.pdf`}>Hent godkendt tryk-PDF</a>
    {file.warnings.map((warning, index) => <p className="mt-3 rounded border-l-4 border-primary bg-muted p-3 text-sm" key={index}>{warning}</p>)}
  </article>;
}

/** Uses the real checkout route/layout, but cannot mount any payment/upload/order handlers. */
export default function LocalWorkspaceCheckout({ id }: { id: string }) {
  const location = useLocation(), navigate = useNavigate(), shop = useShopSettings();
  const design = useOrderFlowDesign('checkout', shop.data?.branding);
  const [bundle, setBundle] = useState<WorkspaceCheckoutBundle | null>(null);
  const [error, setError] = useState(''), [checking, setChecking] = useState(true);
  const [confirmed, setConfirmed] = useState(false), [reviewed, setReviewed] = useState(false);
  const [contact, setContact] = useState(emptyLocalCheckoutAddress);
  const [touched, setTouched] = useState<Partial<Record<LocalContactKey | 'deliveryCountry', boolean>>>({});
  const [showAddressErrors, setShowAddressErrors] = useState(false);
  const contactRef = useRef<HTMLElement>(null);
  const [deliveryChoice, setDeliveryChoice] = useState({ methodId: '', country: 'DK' });
  const [rawDeliveryMethods, setRawDeliveryMethods] = useState<unknown>();
  const [deliveryNotice, setDeliveryNotice] = useState('');
  useEffect(() => {
    let active = true, running = false;
    setBundle(null); setDeliveryChoice({ methodId: '', country: 'DK' });
    const load = async () => {
      if (running) return;
      running = true;
      if (active) { setChecking(true); setReviewed(false); setConfirmed(false); }
      try {
        const next = await readLocalWorkspaceCheckout(id);
        if (new URLSearchParams(location.search).get('tenantId') !== next.checkout.checkoutTenantId) throw new Error('Checkout tilhører en anden butik. Åbn den fra dine designs.');
        const response = await fetch('/brochure/saved-product.json');
        if (!response.ok) throw new Error('Det gemte brochureprodukt kunne ikke bekræftes. Dine designs er bevaret.');
        const saved = await response.json() as BrochureSavedPreview;
        if (saved.product.id !== next.checkout.productId || saved.product.tenant_id !== next.checkout.checkoutTenantId) throw new Error('Brochureproduktet matcher ikke dine designs.');
        const config = saved.product.banner_config as { order_delivery?: { delivery?: { methods?: unknown } } } | null;
        if (active) { setRawDeliveryMethods(config?.order_delivery?.delivery?.methods); setDeliveryChoice(readDeliveryChoice(next.workspaceId)); setBundle(next); setError(''); }
      } catch (failure) { if (active) setError((failure as Error).message); }
      finally { running = false; if (active) setChecking(false); }
    };
    void load();
    const visible = () => { if (document.visibilityState === 'visible') void load(); };
    window.addEventListener('focus', load); document.addEventListener('visibilitychange', visible);
    return () => { active = false; window.removeEventListener('focus', load); document.removeEventListener('visibilitychange', visible); };
  }, [id, location.search]);
  const delivery = bundle ? workspaceDeliveryPreview(bundle.checkout, rawDeliveryMethods,
    deliveryChoice.methodId || bundle.checkout.pricingQuote?.shippingSelected || '', deliveryChoice.country, shop.data?.id) : null;
  const addressErrors = localCheckoutAddressErrors(contact, deliveryChoice.country);
  const addressValid = Object.keys(addressErrors).length === 0;
  const changeContact = (key: LocalContactKey, value: string) => {
    setContact(current => ({ ...current, [key]: value })); setConfirmed(false); setReviewed(false);
  };
  const focusAddressErrors = () => {
    setShowAddressErrors(true);
    const section = contactRef.current;
    const details = section?.closest('details');
    if (details) details.open = true;
    requestAnimationFrame(() => section?.querySelector<HTMLInputElement>('[aria-invalid="true"]')?.focus());
  };
  useEffect(() => { setConfirmed(false); setReviewed(false); }, [id, delivery?.tax?.grossAmountOre, delivery?.tax?.policy, delivery?.method?.id]);
  const changeDelivery = (next: typeof deliveryChoice) => {
    if (!bundle) return;
    setDeliveryChoice(next); setConfirmed(false); setReviewed(false);
    try { localStorage.setItem(deliveryChoiceKey(bundle.workspaceId), JSON.stringify(next)); setDeliveryNotice(''); }
    catch { setDeliveryNotice('Leveringsvalget kunne ikke gemmes lokalt. Vælg det igen efter genindlæsning.'); }
  };
  const workspaceUrl = bundle ? workspacePath(bundle.workspaceId, `tenantId=${bundle.checkout.checkoutTenantId}`) : '/design-workspace';
  const backToProduct = () => {
    if (bundle) navigate(getSafeInternalPath(bundle.returnPath) || '/brochure-shop-preview', { state: { localWorkspaceSelection: bundle.checkout } });
  };
  const finishReview = async () => {
    if (!bundle || bundle.id !== id || checking || !confirmed || !delivery?.tax || !delivery.method || !addressValid) return;
    setChecking(true); setReviewed(false);
    try { await validateLocalWorkspaceCheckout(bundle); setError(''); setReviewed(true); }
    catch (failure) { setError((failure as Error).message); setConfirmed(false); }
    finally { setChecking(false); }
  };
  const money = (amount: number) => new Intl.NumberFormat('da-DK', { style: 'currency', currency: 'DKK' }).format(amount);
  const deliveryForm = delivery && <section className="rounded-lg border p-5" aria-label="Lokal levering">
    <fieldset disabled={checking} className="min-w-0 space-y-3"><legend className="mb-3 text-lg font-semibold">Vælg levering</legend>
      {delivery.methods.map(method => <label key={method.id} className={`grid min-h-11 cursor-pointer grid-cols-[1.25rem_minmax(0,1fr)] items-start gap-x-3 gap-y-1 rounded-lg border p-3 sm:grid-cols-[1.25rem_minmax(0,1fr)_auto] ${delivery.method?.id === method.id ? 'border-primary bg-primary/5' : ''}`}>
        <input type="radio" name="local-delivery-method" className="row-span-2 mt-1 h-5 w-5" checked={delivery.method?.id === method.id}
          onChange={() => changeDelivery({ ...deliveryChoice, methodId: method.id })} />
        <span className="min-w-0 flex-1"><span className="block font-semibold">{method.name}</span><span className="text-sm">{method.description}</span></span>
        <span className="col-start-2 text-sm sm:col-start-3 sm:row-span-2 sm:row-start-1">{money(resolveDeliveryMethodCost(delivery.orderPrice, method))} ekskl. moms</span>
      </label>)}
    </fieldset>
    <p className="mt-3 text-sm">Leveringsmetode og land gemmes kun i denne browser. Der bestilles ingen fragt.</p>
    {deliveryNotice && <p role="status" className="mt-3">{deliveryNotice}</p>}
    {delivery.message && <p role="alert" className="mt-3 text-destructive">{delivery.message}</p>}
  </section>;
  return <StorefrontThemeFrame branding={shop.data?.branding} orderDesign={design} tenantName={shop.data?.tenant_name || 'Webprinter'}>
    <main className="storefront-order-flow storefront-checkout-flow container mx-auto px-4 py-12" data-storefront-order-flow="checkout">
      <p className="mb-6 rounded-lg border bg-muted p-4" role="status">Lokal checkout · Ingen betaling, upload eller bestilling sendes. Navn, e-mail og adresse gemmes ikke.</p>
      {error && <div className="mb-6 rounded-lg border border-destructive p-4" role="alert"><p>{error}</p><Button asChild variant="outline" className="mt-3"><Link to={workspaceUrl}>Tilbage til dine designs</Link></Button></div>}
      {!bundle ? <p role="status">{checking ? 'Kontrollerer dine designs og trykfiler…' : 'Åbn lokal checkout fra dine designs.'}</p> :
        <OrderCheckoutLayout design={design} onBack={backToProduct}
          contact={<section ref={contactRef} className="min-w-0 rounded-lg border p-5" aria-label="Kontakt og leveringsadresse"><h2 className="mb-4 text-lg font-semibold">Kontakt og leveringsadresse · lokal afprøvning</h2>
            <fieldset disabled={checking} className="min-w-0"><legend className="sr-only">Kontakt og modtager</legend><div className="grid gap-4 md:grid-cols-2">
              {localContactFields.map(field => {
                const error = (showAddressErrors || touched[field.key]) && addressErrors[field.key];
                const fieldId = `local-address-${field.key}`;
                return <div key={field.key} className={`min-w-0 ${field.wide ? 'md:col-span-2' : ''}`}>
                  <Label htmlFor={fieldId}>{field.label}</Label><Input id={fieldId} type={field.type} value={contact[field.key]} required={field.required} maxLength={field.max}
                    autoComplete="off" aria-invalid={Boolean(error)} aria-describedby={error ? `${fieldId}-error` : undefined}
                    onChange={event => changeContact(field.key, event.target.value)} onBlur={() => setTouched(current => ({ ...current, [field.key]: true }))} />
                  {error && <p id={`${fieldId}-error`} className="mt-1 text-sm text-destructive">{error}</p>}
                </div>;
              })}
              <div className="min-w-0 md:col-span-2"><Label htmlFor="local-delivery-country">Leveringsland (DK — Danmark)</Label>
                <Input id="local-delivery-country" value={deliveryChoice.country} maxLength={32} required autoComplete="off"
                  onChange={event => changeDelivery({ ...deliveryChoice, country: event.target.value })}
                  onBlur={() => setTouched(current => ({ ...current, deliveryCountry: true }))}
                  aria-invalid={Boolean((showAddressErrors || touched.deliveryCountry) && (addressErrors.deliveryCountry || delivery?.message))}
                  aria-describedby="local-delivery-policy" />
                <p id="local-delivery-policy" className="mt-1 text-sm">{((showAddressErrors || touched.deliveryCountry) && addressErrors.deliveryCountry) || delivery?.message || 'Vi leverer i øjeblikket kun til Danmark.'}</p>
              </div>
            </div></fieldset>
            <p className="mt-3 text-sm">Alle felter uden “valgfrit” skal udfyldes. Navn, e-mail og adresse er kun i denne åbne side og ryddes ved genindlæsning. Land og leveringsmetode gemmes lokalt.</p>
          </section>}
          file={<section className="rounded-lg border p-5" aria-label="Dine godkendte designs"><div className="mb-4 flex flex-wrap items-center justify-between gap-4"><h2 className="text-lg font-semibold">Dine godkendte designs</h2><Button asChild variant="outline"><Link to={workspaceUrl}>Rediger designs og antal</Link></Button></div>
            <div className="grid gap-4 sm:grid-cols-2">{bundle.files.map(file => <DesignFile key={file.designId} file={file} />)}</div>
            <p className="mt-4">{bundle.files.reduce((sum, file) => sum + file.quantity, 0)} af {bundle.checkout.quantity} stk fordelt.</p>
          </section>}
          summary={<section className="rounded-lg border bg-card p-5" aria-label="Lokal ordreoversigt"><h2 className="text-lg font-semibold">Din bestilling</h2>
            <p className="my-3 font-semibold">{bundle.checkout.productName}</p><p>{bundle.checkout.summary}</p>
            <dl className="my-5 space-y-3"><div className="flex justify-between gap-3"><dt>Antal</dt><dd>{bundle.checkout.quantity} stk</dd></div>
              <div className="flex justify-between gap-3"><dt>Produkt ekskl. moms</dt><dd>{money(bundle.checkout.productPrice!)}</dd></div>
              {!!bundle.checkout.extraPrice && <div className="flex justify-between gap-3"><dt>Tilvalg ekskl. moms</dt><dd>{money(bundle.checkout.extraPrice)}</dd></div>}
              {delivery?.method && <div className="flex justify-between gap-3"><dt>Levering ekskl. moms<br /><span className="text-sm">{delivery.method.name}</span></dt><dd>{money(delivery.shippingCost)}</dd></div>}
              {delivery?.tax && <><div className="flex justify-between gap-3"><dt>I alt ekskl. moms</dt><dd>{money(delivery.tax.netAmountOre / 100)}</dd></div>
                <div className="flex justify-between gap-3"><dt>Moms (25 %)</dt><dd>{money(delivery.tax.vatAmountOre / 100)}</dd></div>
                <div className="flex justify-between gap-3 border-t pt-3 font-semibold" aria-live="polite"><dt>I alt inkl. moms</dt><dd>{money(delivery.tax.grossAmountOre / 100)}</dd></div></>}
            </dl>
            <p className="my-3 text-sm">Produktpris fra den eksisterende prismatrix. Levering og moms beregnes med checkoutens eksisterende logik.</p>
            {!addressValid ? <div className="my-3 rounded border p-3" role="status"><p>Udfyld eller ret kontakt- og leveringsoplysningerne, før du godkender.</p><Button variant="link" className="h-auto whitespace-normal px-0 text-left" onClick={focusAddressErrors}>Gå til kontakt og adresse</Button></div> :
              <address className="my-3 break-words rounded border p-3 not-italic [overflow-wrap:anywhere]" aria-label="Leveringsadresse til kontrol"><strong>{contact.deliveryRecipientName.trim()}</strong>
                {contact.deliveryCompany.trim() && <p>{contact.deliveryCompany.trim()}</p>}<p>{deliveryAddressLines(contact.deliveryAddress, contact.deliveryAddress2)}</p>
                <p>{contact.deliveryZip.trim()} {contact.deliveryCity.trim()} · {deliveryChoice.country.trim()}</p></address>}
            {!delivery?.tax && <p role="alert" className="my-3 text-destructive">{delivery?.message || 'Kontrollerer butik og moms…'}</p>}
            <label className="my-4 flex items-start gap-3"><input type="checkbox" className="mt-1 h-5 w-5 shrink-0" checked={confirmed} disabled={checking || !!error || !delivery?.tax || !delivery.method || !addressValid} onChange={event => setConfirmed(event.target.checked)} /><span>Jeg har kontrolleret designs, antal, adresse, levering og beløb inkl. moms.</span></label>
            <Button className="min-h-11 w-full" disabled={!confirmed || checking || !!error || !delivery?.tax || !delivery.method || !addressValid} onClick={() => void finishReview()}>{checking ? 'Kontrollerer trykfiler…' : 'Kontrollér lokal checkout'}</Button>
            {reviewed && delivery?.tax && addressValid && <p role="status" className="mt-4 rounded bg-muted p-3">Lokal checkout er kontrolleret med leveringsadressen, {delivery.method?.name} og {money(delivery.tax.grossAmountOre / 100)} inkl. moms. Designversionerne og antallet er bevaret. Ingen ordre eller betaling er oprettet.</p>}
            <Button className="mt-3 min-h-11 w-full" disabled variant="outline">Betaling er ikke åbnet</Button>
          </section>}
          delivery={deliveryForm} deliverySummary={delivery?.method ? `${delivery.method.name} · ${money(delivery.shippingCost)} ekskl. moms` : undefined}
          extras={design === 6 ? undefined : deliveryForm}
        />}
    </main>
  </StorefrontThemeFrame>;
}
