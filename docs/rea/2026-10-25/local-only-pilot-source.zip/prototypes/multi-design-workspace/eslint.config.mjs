import js from '@eslint/js';
import globals from 'globals';
export default [{files:['prototypes/multi-design-workspace/**/*.{js,mjs}'],languageOptions:{ecmaVersion:2022,sourceType:'module',globals:{...globals.browser,...globals.node}},rules:{...js.configs.recommended.rules}}];
