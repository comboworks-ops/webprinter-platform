import {defineConfig} from 'vite';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('./',import.meta.url));
export default defineConfig({root,envDir:false,server:{host:'127.0.0.1',port:8953,strictPort:true,fs:{allow:[fileURLToPath(new URL('../../',import.meta.url))]}},build:{outDir:fileURLToPath(new URL('../../output/multi-design-workspace-2026-10-21/build/',import.meta.url)),emptyOutDir:false},css:{postcss:{plugins:[]}}});
