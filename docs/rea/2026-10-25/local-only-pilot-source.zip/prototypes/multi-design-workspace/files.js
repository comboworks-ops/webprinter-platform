import * as pdfjs from 'pdfjs-dist';
import worker from 'pdfjs-dist/build/pdf.worker.min.js?url';
import {PDFDocument, rgb, StandardFonts} from 'pdf-lib';
import {safePdfDocumentOptions} from '../../src/lib/pdfDocumentOptions.ts';
import {hashCheckoutArtifact} from '../../src/lib/checkout/checkoutArtifact.ts';
pdfjs.GlobalWorkerOptions.workerSrc=worker;
export async function inspectPdf(file,spec) {
 if(file.size>25*1024*1024)throw Error('Vælg en PDF på højst 25 MB i denne prototype.');
 const bytes=new Uint8Array(await file.arrayBuffer());
 if(!new TextDecoder().decode(bytes.slice(0,5)).startsWith('%PDF-'))throw Error('Filen er ikke en gyldig PDF. Den nuværende version er bevaret.');
 const sha256=await hashCheckoutArtifact(file);
 const task=pdfjs.getDocument(safePdfDocumentOptions({data:bytes,disableAutoFetch:true,isOffscreenCanvasSupported:false}));
 task.onPassword=()=>{task.destroy();};
 let pdf;
 try{pdf=await task.promise;}catch{throw Error('PDF’en kunne ikke åbnes. Brug en PDF uden adgangskode. Din tidligere fil er bevaret.');}
 try{
  const dimensions=[],previews=[];
  for(let i=1;i<=Math.min(pdf.numPages,2);i++){
   const page=await pdf.getPage(i),base=page.getViewport({scale:1});
   dimensions.push({widthMm:Math.round(base.width*25.4/72*10)/10,heightMm:Math.round(base.height*25.4/72*10)/10});
   if(!Number.isFinite(base.width)||!Number.isFinite(base.height)||base.width<=0||base.height<=0)throw Error("PDF’en har en ugyldig sidestørrelse.");
   const viewport=page.getViewport({scale:Math.min(720/base.width,1100/base.height)});
   const canvas=document.createElement('canvas');canvas.width=Math.ceil(viewport.width);canvas.height=Math.ceil(viewport.height);
   await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;
   previews.push(canvas.toDataURL('image/png'));
  }
  const expected={widthMm:spec.widthMm+2*spec.bleedMm,heightMm:spec.heightMm+2*spec.bleedMm};
  const sizeOk=dimensions.length===2&&dimensions.every(d=>Math.abs(d.widthMm-expected.widthMm)<0.6&&Math.abs(d.heightMm-expected.heightMm)<0.6);
  return {id:crypto.randomUUID(),createdAt:new Date().toISOString(),fileName:file.name,blob:file,sha256,pageOrder:[0,1],previews,check:{ok:pdf.numPages===2&&sizeOk,pageCount:pdf.numPages,dimensions,expected,scope:'page-count-and-page-box-only',productionPreflight:false,issues:[...(pdf.numPages!==2?['Der skal være 2 sider: forside først, bagside sidst.']:[]),...(!sizeOk?['Begge sider skal være 154 × 216 mm (A5 med 3 mm beskæring).']:[])]}};
 }finally{await pdf.destroy();}
}
export async function sampleFile(name,variant=0) {
 const pdf=await PDFDocument.create();const font=await pdf.embedFont(StandardFonts.HelveticaBold),small=await pdf.embedFont(StandardFonts.Helvetica);
 const w=154/25.4*72,h=216/25.4*72;
 const navy=rgb(.07,.2,.28),teal=rgb(.12,.48,.49),coral=rgb(.9,.48,.34),cream=rgb(.97,.96,.92),accent=variant?coral:teal;
 for(let side=0;side<2;side++){
  const p=pdf.addPage([w,h]);p.drawRectangle({x:0,y:0,width:w,height:h,color:side?cream:navy});
  p.drawCircle({x:w*(side?.9:.82),y:h*.6,size:135,color:accent});
  p.drawRectangle({x:30,y:30,width:50,height:5,color:accent});
  const color=side?navy:cream;
  p.drawText('STUDIO / 26',{x:30,y:h-60,size:12,font,color});
  const lines=side?['Plads til','nye ideer.']:(variant?['Kom','indenfor.']:['Noget nyt','begynder.']);
  lines.forEach((line,i)=>p.drawText(line,{x:30,y:h-155-i*48,size:38,font,color}));
  p.drawText(side?'BAGSIDE / EKSEMPEL':'FORSIDE / EKSEMPEL',{x:30,y:86,size:10,font,color});
  p.drawText('Lokalt eksempel til gennemgang',{x:30,y:66,size:10,font:small,color});
 }
 return new File([await pdf.save()],name,{type:'application/pdf'});
}
const DB='wp-multi-design-review-v1';
function db(){return new Promise((resolve,reject)=>{const request=indexedDB.open(DB,1);request.onupgradeneeded=()=>request.result.createObjectStore('drafts');request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});}
export async function readDraft(){const d=await db();try{return await new Promise((resolve,reject)=>{const tx=d.transaction('drafts','readonly'),r=tx.objectStore('drafts').get('current');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});}finally{d.close();}}
export async function saveDraft(state){const d=await db();try{await new Promise((resolve,reject)=>{const tx=d.transaction('drafts','readwrite');tx.objectStore('drafts').put(state,'current');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});}finally{d.close();}}
