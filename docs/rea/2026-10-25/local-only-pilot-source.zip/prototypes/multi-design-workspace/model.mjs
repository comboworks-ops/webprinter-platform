export const SPEC = Object.freeze({key:'demo-flyer-a5-135g-4plus4-3mm-v1',product:'Flyers',format:'A5',widthMm:148,heightMm:210,bleedMm:3,paper:'135 g papir',print:'4+4 · tryk på begge sider',quantity:1000});
export const current = d => d.revisions.at(-1) || null;
export const active = state => state.designs.filter(d=>!d.archived);
export function allocation(state) {
 const designs=active(state), valid=designs.length>0&&designs.every(d=>Number.isSafeInteger(d.quantity)&&d.quantity>0);
 const total=designs.reduce((sum,d)=>sum+(Number.isFinite(d.quantity)?d.quantity:0),0);
 return {valid,total,remaining:state.spec.quantity-total,complete:valid&&total===state.spec.quantity};
}
export function approvalKey(state,design) {
 const rev=current(design);
 return JSON.stringify([state.spec.key,design.quantity,rev?.id,rev?.sha256,rev?.pageOrder]);
}
export function status(state,design) {
 const rev=current(design);
 if(!rev)return 'missing';
 if(!rev.check.ok)return 'correction';
 if(!Number.isSafeInteger(design.quantity)||design.quantity<=0)return 'quantity';
 return design.approval?.key===approvalKey(state,design)?'approved':'review';
}
export function canReviewComplete(state) {return allocation(state).complete&&active(state).every(d=>status(state,d)==='approved');}
export function editQuantity(state,id,quantity) {
 const d=state.designs.find(d=>d.id===id);if(!d)throw Error('Design missing');
 if(d.quantity!==quantity){d.quantity=quantity;d.approval=null;}
}
export function appendRevision(state,id,revision) {
 const d=state.designs.find(d=>d.id===id);if(!d)throw Error('Design missing');
 if(d.revisions.some(r=>r.id===revision.id))throw Error('Revision must be new');
 d.revisions.push(revision);d.approval=null;
}
export function approve(state,id) {
 const d=state.designs.find(d=>d.id===id);
 if(!d||d.archived||!['review','approved'].includes(status(state,d)))throw Error('Current file and valid quantity required');
 d.approval={key:approvalKey(state,d),at:new Date().toISOString(),scope:'local-visual-review-only'};
}
export function reviewSummary(state) {
 if(!canReviewComplete(state))throw Error('Allocation or approvals incomplete');
 return {schema:'webprinter-artwork-review-prototype/v1',productionAuthorized:false,quoteValidated:false,companyApprovalVerified:false,createdAt:new Date().toISOString(),spec:state.spec,designs:active(state).map(d=>{const r=current(d);return {id:d.id,name:d.name,quantity:d.quantity,revisionId:r.id,revision:d.revisions.length,fileName:r.fileName,sha256:r.sha256,frontPage:r.pageOrder[0]+1,backPage:r.pageOrder[1]+1,basicCheck:r.check,visualApproval:d.approval};})};
}
